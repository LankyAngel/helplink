// public/firebase-messaging-sw.js

// eslint-disable-next-line no-undef
importScripts("https://www.gstatic.com/firebasejs/9.15.0/firebase-app-compat.js");
// eslint-disable-next-line no-undef
importScripts("https://www.gstatic.com/firebasejs/9.15.0/firebase-messaging-compat.js");

const firebaseConfig = {
  apiKey: "AIzaSyCvHx_xzicdsYVFpuZXQlpp_osiOXTs8vI",
  authDomain: "helplink-d1358.firebaseapp.com",
  projectId: "helplink-d1358",
  storageBucket: "helplink-d1358.appspot.com",
  messagingSenderId: "656549067468",
  appId: "1:656549067468:web:61560023ff775809e72069",
  measurementId: "G-3L87G0FHFB"
};

firebase.initializeApp(firebaseConfig);

const messaging = firebase.messaging();

messaging.onBackgroundMessage(function(payload) {
  console.log('[firebase-messaging-sw.js] Mensaje en segundo plano recibido ', payload);

  const notificationTitle = payload.notification.title;
  const notificationOptions = {
    body: payload.notification.body,
    icon: '/logo192.png'
  };

  self.clients.matchAll({
    type: 'window',
    includeUncontrolled: true
  }).then((clients) => {
    if (clients && clients.length > 0) {
      clients.forEach((client) => {
        client.postMessage({
          type: 'new-notification',
          data: payload.notification
        });
      });
    }
  });

  //return self.registration.showNotification(notificationTitle, notificationOptions);
});