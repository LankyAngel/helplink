// import React from 'react';
// import './App.css';
// import Login from './pages/Login.js';
// import Home from './pages/Home.js';
// import Navigate from './Navigate.js';
// import { BrowserRouter } from "react-router-dom";
//
// function App() {
//   return (
//     <BrowserRouter>
//       <Navigate />
//     </BrowserRouter>
//   );
// }
//
// export default App;

import React from 'react';
import './App.css';
import Navigate from './Navigate.js';
import { BrowserRouter } from "react-router-dom";
import { NotificationProvider } from './contex/NotificationContext';

function App() {
  return (
    <NotificationProvider>
      <BrowserRouter>
        <Navigate />
      </BrowserRouter>
    </NotificationProvider>
  );
}

export default App;
