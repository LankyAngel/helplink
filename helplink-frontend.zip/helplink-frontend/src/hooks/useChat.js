import { useEffect, useState, useRef } from "react";

export default function useChat(channelId) {
    const [messages, setMessages] = useState([]);
    const [reactionMap, setReactionMap] = useState({});
    const socketRef = useRef(null);

    // Scroll automático cuando cambian los mensajes
    useEffect(() => {
        const chatContainer = document.querySelector(".chat-messages");
        if (chatContainer) {
            chatContainer.scrollTop = chatContainer.scrollHeight;
        }
    }, [messages]);

    useEffect(() => {
        if (!channelId) return;

        setMessages([]);
        setReactionMap({});

        // Cargar historial
        fetch(`${process.env.REACT_APP_API_URL}/channels/${channelId}/messages/`)
            .then((res) => res.json())
            .then((data) => {
                setMessages(data);

                // Mapear reacciones del historial
                const initialReactions = {};
                data.forEach((msg) => {
                    if (msg.reactions && msg.reactions.length > 0) {
                        initialReactions[msg.id] = msg.reactions;
                    }
                });
                setReactionMap(initialReactions);
            })
            .catch((err) => console.error("Error al cargar historial:", err));

        const token = localStorage.getItem("access_token");

        // Cerrar WS anterior si existe
        if (socketRef.current) {
            socketRef.current.close();
        }

        // Nueva conexión WS

        if (!token) {
            console.warn("❌ No hay token disponible. No se conectará al WebSocket.");
            return;
        }

        // URL real con token (NO imprimir nunca esta)
        const actualWsUrl = `${process.env.REACT_APP_WS_URL}/${channelId}/?token=${token}`;

        // URL fake para debug (sin mostrar el token real)
        const wsUrl = `${process.env.REACT_APP_WS_URL}/${channelId}/?token=REDACTED`;

        try {
            socketRef.current = new WebSocket(actualWsUrl);

            socketRef.current.onerror = () => {
                console.warn(`⚠️ Este evento ha finalizado o la conexión fue rechazada para el canal ${channelId}.`);
            };
        } catch (e) {
            console.error("❌ Error al conectar al WebSocket. Probablemente canal cerrado.");
        }

        socketRef.current.onmessage = (event) => {
            const data = JSON.parse(event.data);

            if (data.event === "new_message") {
                const normalizedMessage = {
                    id: String(data.id),
                    content: data.message,
                    attachment: data.attachment,
                    original_filename: data.original_filename || null,
                    timestamp: data.timestamp,
                    sender_id: data.sender_id,
                    sender_name: data.sender_name,
                    sender_profile: data.sender_profile || null,
                    reactions: [],
                    isOptimistic: false,
                    clientId: data.client_id || null,
                    reply_to: data.reply_to || null
                };

                setMessages((prev) => {
                    const updated = [...prev];

                    if (data.client_id) {
                        const index = prev.findIndex(
                            (m) => m.clientId === data.client_id
                        );
                        if (index !== -1) {
                            updated[index] = {
                                ...normalizedMessage,
                                isOptimistic: false,
                                clientId: data.client_id
                            };
                            return updated;
                        }
                    }

                    // Evitar duplicados por id
                    if (updated.some((m) => m.id === normalizedMessage.id)) {
                        return updated;
                    }

                    return [...updated, normalizedMessage];
                });
            }

            else if (data.event === "reaction_update") {
                const { message_id, emoji, user, action } = data;

                setReactionMap((prev) => {
                    const currentReactions = prev[message_id]
                        ? [...prev[message_id]]
                        : [];

                    if (action === "added") {
                        const filtered = currentReactions.filter(r => r.user !== user);
                        filtered.push({ user, emoji });
                        return { ...prev, [message_id]: filtered };
                    } else if (action === "removed") {
                        return {
                            ...prev,
                            [message_id]: currentReactions.filter(
                                (r) => !(r.user === user && r.emoji === emoji)
                            )
                        };
                    }
                    return prev;
                });
            }

            else if (data.event === "reaction_error") {
                console.error(`Error en reacción: ${data.message}`);
            }
        };

        socketRef.current.onerror = () => {
            console.warn(`⚠️ Este evento ha finalizado o la conexión fue rechazada para el canal ${channelId}.`);
        };

        return () => socketRef.current.close();
    }, [channelId]);

    // Enviar mensaje
    const sendMessage = (payload) => {
        if (socketRef.current && socketRef.current.readyState === WebSocket.OPEN) {
            socketRef.current.send(JSON.stringify(payload));
        } else {
            console.warn("⚠️ WebSocket no está listo");
        }
    };

    // Enviar reacción
    const sendReaction = (messageId, emoji) => {
        sendMessage({
            type: "reaction",
            message_id: String(messageId), // Enviar siempre como string
            emoji
        });
    };

    return {
        messages,
        setMessages,
        reactionMap,
        sendMessage,
        sendReaction
    };
}
