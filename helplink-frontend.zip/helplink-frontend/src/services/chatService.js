import axios from "axios";

const API_URL = process.env.REACT_APP_API_URL;

export const getChannelMessages = async (channelId) => {
    const token = localStorage.getItem("access_token");
    const url = `${API_URL}/channels/${channelId}/messages/`;

    try {
        const response = await axios.get(url, {
            headers: {
                Authorization: `Bearer ${token}`,
            },
        });
        return response.data; // Devuelve el array de mensajes
    } catch (error) {
        console.error("Error obteniendo mensajes del canal:", error);
        return [];
    }
};
