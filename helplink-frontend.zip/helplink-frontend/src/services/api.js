import axios from "axios";
import { getUserInfo } from "./authService";

const apiURL = process.env.REACT_APP_API_URL;
//console.log("API URL: ", apiURL);

// Puedes poner tu base URL aquí o usar variables de entorno
const api = axios.create({
  baseURL: apiURL,
  headers: {
    "Content-Type": "application/json",
  },
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem("access");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Funciones para usar en todo el proyecto
export const getData = async (endpoint) => {
  try {
    const response = await api.get(endpoint);
    //console.log(response);
    return response.data;
  } catch (error) {
    console.error("GET error:", error);
    throw error;
  }
};

export const postData = async (endpoint, data) => {
  try {
    const response = await api.post(endpoint, data);
    return response.data;
  } catch (error) {
    console.error("POST error:", error);
    throw error;
  }
};

export const putData = async (endpoint, data) => {
  try {
    const response = await api.put(endpoint, data);
    return response.data;
  } catch (error) {
    console.error("PUT error:", error);
    throw error;
  }
};

export const deleteData = async (endpoint) => {
  try {
    const response = await api.delete(endpoint);
    return response.data;
  } catch (error) {
    console.error("DELETE error:", error);
    throw error;
  }
};

export const rol = async () => {
  try {
    const data = await getUserInfo();
    const user = data.find(
      (u) => u.username === localStorage.getItem("username")
    );
    var rol = user.global_role.role;
    switch (rol) {
      case "volunteer":
        rol = 1;
        break;
      case "organization_staff":
        rol = 2;
        break;
      case "organization_admin":
        rol = 3;
        break;

      default:
        break;
    }
    return rol;
  } catch (error) {
    console.error("Get Rol error:", error);
    throw error;
  }
};

export const getAllUsers = async () => {
  try {
    const response = await fetch(`${apiURL}/users/`);
    if (!response.ok) {
      throw new Error("Error al obtener los usuarios");
    }
    return await response.json();
  } catch (error) {
    console.error(error);
    return [];
  }
};

export const getAllEvents = async () => {
  try {
    const response = await fetch(`${apiURL}/events/`);
    if (!response.ok) {
      throw new Error("Error al obtener los eventos");
    }
    return await response.json();
  } catch (error) {
    console.error(error);
    return [];
  }
};

export const getVolunteerEvents = async () => {
  try {
    const response = await fetch(`${apiURL}/voluntaries-events/`);
    if (!response.ok) {
      throw new Error("Error al obtener las participaciones");
    }
    return await response.json();
  } catch (error) {
    console.error(error);
    return [];
  }
};

export const getCategories = async () => {
  try {
    const response = await fetch(`${apiURL}/categories/`);
    if (!response.ok) {
      throw new Error("Error al obtener las participaciones");
    }
    return await response.json();
  } catch (error) {
    console.error(error);
    return [];
  }
};

export const getBranches = async () => {
  try {
    const response = await fetch(`${apiURL}/branches/`);
    if (!response.ok) {
      throw new Error("Error al obtener las participaciones");
    }
    return await response.json();
  } catch (error) {
    console.error(error);
    return [];
  }
};

export const getOrganizations = async () => {
  try {
    const response = await fetch(`${apiURL}/organizations/`);
    if (!response.ok) {
      throw new Error("Error al obtener las participaciones");
    }
    return await response.json();
  } catch (error) {
    console.error(error);
    return [];
  }
};

export const getBranchMembers = async () => {
  try {
    const response = await fetch(`${apiURL}/branch-memberships/`);
    if (!response.ok) {
      throw new Error("Error al obtener las participaciones");
    }
    return await response.json();
  } catch (error) {
    console.error(error);
    return [];
  }
};

export const getAchievements = async () => {
  try {
    const response = await fetch(`${apiURL}/achievements/`);
    if (!response.ok) {
      throw new Error("Error al obtener las participaciones");
    }
    return await response.json();
  } catch (error) {
    console.error(error);
    return [];
  }
};

// export const getOrganizationDashboard = async () => {
//   try {
//     console.log(localStorage.getItem("access"))
//     const response = await fetch(`${apiURL}/organization_dashboard/`);
//     if (!response.ok) {
//       throw new Error("Error al obtener la informacion de la organizacion");
//     }
//     return await response.json();
//   } catch (error) {
//     console.error(error);
//     return [];
//   }
// };

export const getOrganizationDashboard = async () => {
  try {
    const token = localStorage.getItem("access");
    const response = await fetch(`${apiURL}/organization_dashboard/`, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      throw new Error("Error al obtener la informacion de la organizacion");
    }

    return await response.json();
  } catch (error) {
    console.error(error);
    return [];
  }
};

export const getOrganizationEvents = async () => {
  try {
    const response = await fetch(`${apiURL}/events/`);
    if (!response.ok) {
      throw new Error("Error al obtener las participaciones");
    }
    return await response.json();
  } catch (error) {
    console.error(error);
    return [];
  }
};

export const getBranchEvents = async () => {
  try {
    const response = await fetch(`${apiURL}/events/`);
    if (!response.ok) {
      throw new Error("Error al obtener las participaciones");
    }
    return await response.json();
  } catch (error) {
    console.error(error);
    return [];
  }
};

export const deleteEvent = async () => {
  try {
    const response = await fetch(`${apiURL}/events/`);
    if (!response.ok) {
      throw new Error("Error al obtener las participaciones");
    }
    return await response.json();
  } catch (error) {
    console.error(error);
    return [];
  }
};

export const deleteBranch = async () => {
  try {
    const response = await fetch(`${apiURL}/events/`);
    if (!response.ok) {
      throw new Error("Error al obtener las participaciones");
    }
    return await response.json();
  } catch (error) {
    console.error(error);
    return [];
  }
};

export const deleteUser = async () => {
  try {
    const response = await fetch(`${apiURL}/events/`);
    if (!response.ok) {
      throw new Error("Error al obtener las participaciones");
    }
    return await response.json();
  } catch (error) {
    console.error(error);
    return [];
  }
};

export const validateAttendance = async (validationToken) => {
  try {
    const response = await api.put(`/attendance/evento/${validationToken}/`);
    return response.data;
  } catch (error) {
    console.error("PUT validateAttendance error:", error);
    throw error;
  }
};

export const getBranchDashboard = async () => {
  try {
    const token = localStorage.getItem("access");
    const response = await fetch(`${apiURL}/branch/dashboard/`, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      throw new Error("Error al obtener la información del branch dashboard");
    }

    return await response.json();
  } catch (error) {
    console.error("Error getBranchDashboard:", error);
    return null;
  }
};

export const getBranchDashboardEvents = async () => {
  try {
    const token = localStorage.getItem("access");
    const response = await fetch(`${apiURL}/branch/dashboard/events/`, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
    });

    if (!response.ok) {
      throw new Error("Error al obtener la información del branch dashboard");
    }

    return await response.json();
  } catch (error) {
    console.error("Error getBranchDashboard:", error);
    return null;
  }
};