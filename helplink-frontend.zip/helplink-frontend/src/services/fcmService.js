// src/services/fcmService.js
import { messaging } from "../firebase"; // tu archivo firebase.js
import { getToken } from "firebase/messaging";

export const requestNotificationPermission = async () => {
  const permission = await Notification.requestPermission();
  return permission === "granted";
};

export const getFcmToken = async () => {
  try {
    const currentToken = await getToken(messaging, {
      vapidKey: "BDMATUOa2InHe1KIMLD-w7XevGtQ5tYlFZyTrlXOK1ZjPv2ANikWJBi0dpy-jkQIkGENyh6b1d7DRiI3hCzQNP0"
    });

    localStorage.setItem('FCMToken', currentToken);


    if (currentToken) {
      console.log("Token FCM:", currentToken);
      return currentToken;
    } else {
      console.warn("No se obtuvo el token.");
      return null;
    }
  } catch (err) {
    console.error("Error al obtener token FCM:", err);
    return null;
  }
};
