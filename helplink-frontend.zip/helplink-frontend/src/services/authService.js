// src/services/authService.js
import axios from "axios";
import { getData, putData } from "./api";
import { requestNotificationPermission, getFcmToken } from './fcmService';
import { data } from "react-router-dom";


const apiURL = process.env.REACT_APP_API_URL;

export const login = async (username, password) => {
  const _apiURL = `${apiURL}/token/`;

  try {
    const response = await axios.post(_apiURL, {
      username: username,
      password: password,
    });
    localStorage.setItem("access_token", response.data.access);
    localStorage.setItem("refresh_token", response.data.refresh);
    localStorage.setItem("username", response.data.username);

    if (Array.isArray(response.data.server_roles)) {
      localStorage.setItem("server_roles", JSON.stringify(response.data.server_roles));

    }

    const permissionGranted = await requestNotificationPermission();

    if (permissionGranted) {
      const fcmToken = await getFcmToken();
      if (fcmToken) {
        try {
          await axios.post(apiURL + "/device-tokens/", {
            user: response.data.user_id,
            token: fcmToken
          }, {
            headers: { Authorization: `Bearer ${response.data.access}` }
          });
        } catch (error) {
          console.error("Error al registrar el FCM token:", error.response?.data || error.message);
        }
      }
    } else {
      console.log("Permiso de notificación denegado");
    }
    return response;
  } catch (error) {
    throw new Error(error.response?.data?.message || "Login fallido");
  }
};

export const register = async (
  username,
  email,
  password,
  firstname,
  lastName,
  phonNumber
) => {
  const _apiURL = `${apiURL}/register/`;
  try {
    const response = await axios.post(_apiURL, {
      first_name: firstname,
      last_name: lastName,
      email: email,
      username: username,
      password: password,
      phone_number: phonNumber,
    });

    return response;
  } catch (error) {
    throw new Error(error.response?.data?.message || "Register fallido");
  }
};

export const getUserInfo = async () => {
  try {
    const token = localStorage.getItem("access");
    if (!token) return null;
    const response = await getData(`/users`);
    return response;
  } catch (error) {
    throw new Error(error.message || "No se pudo obtener el perfil");
  }
};

export const getUserEvents = async () => {
  try {
    const response = await getData("/voluntaries-events");
    return response;
  } catch (error) {
    throw new Error(error.message || "No se pudo obtener el historial");
  }
};

export const getUserAchievements = async () => {
  try {
    const response = await getData("/user/achievements");
    return response;
  } catch (error) {
    throw new Error(error.message || "No se pudo obtener el historial");
  }
};

export const putUser = async (data) => {
  try {
    const response = await putData("/users/update/", data);
    return response;
  } catch (error) {
    throw new Error(error.message || "No se pudo cambiar los datos");
  }
};

export const putAddOrganization = async (data) => {
  try {
    const response = await putData("organizations/organization/", data);
    return response;
  } catch (error) {
    console.error("Get Rol error:", error);
    throw error;
  }
};

export const deleteUser = async () => {
  try {
    const response = await fetch(`${apiURL}/events/`);
    if (!response.ok) {
      throw new Error("Error al obtener las participaciones");
    }
    return await response.json();
  } catch (error) {
    console.error(error);
    return [];
  }
};
