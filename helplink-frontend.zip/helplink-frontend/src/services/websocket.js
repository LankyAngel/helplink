const chatSocket = new WebSocket("ws://localhost:8000/ws/chat/general/");

chatSocket.onmessage = function (e) {
    const data = JSON.parse(e.data);
    console.log("Mensaje recibido:", data.message);
};

export default chatSocket;
