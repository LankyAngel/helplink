import React from "react";
import { Link } from "react-router-dom";
import { FaArrowLeft, FaBuilding, FaEdit } from "react-icons/fa";
import { getUserInfo } from "../services/authService";
import { useAuth } from "../contex/AuthProvider";
import { useNavigate } from "react-router-dom";
import { getOrganizations } from "../services/api";

const ButtonVolver = ({ onClick, label, disabled = false }) => {
  const { access, isAuthenticated, org_code } = useAuth();
  const navigate = useNavigate();
  const rolForEvent = async (e) => {
    if (isAuthenticated) {
      const data = await getUserInfo();
      const user = data.find(
        (u) => u.username === localStorage.getItem("username")
      );
      const rol = user.global_role.role;
      //var ruta;
      switch (rol) {
        case "volunteer":
          navigate("/events");
          break;
        case "organization_staff":
          navigate("/events");
          break;

        case "organization_admin":
          navigate("/showEventsOrganization");
          break;

        default:
          navigate("/home");
          break;
      }
    } else {
      navigate("/events");
    }
  };

  const goBack = (e) => {
    e.preventDefault(); // Previene el comportamiento por defecto del enlace
    //navigate("/events"); // Navega a la ruta /events
    rolForEvent();
  };

  return (
    // <Link to="/Events" className="event-detail-back">
    //   <FaArrowLeft className="icon" />
    //   Volver a eventos
    // </Link>

    <a href="/" className="event-detail-back" onClick={goBack}>
      <FaArrowLeft className="icon" />
      Volver a eventos
    </a>
  );
};

export default ButtonVolver;

export const ButtonEditProfile = ({ onClick, label, disabled = false }) => {
  return (
    <a className="logout-link" href="/editprofile">
      <button className="edit-profile-btn">
        <FaEdit className="btn-icon" /> Editar Perfil
      </button>
    </a>
  );
};

export const ButtonGoOrganization = ({ organizationId }) => {
  if (!organizationId) return null;

  return (
    <Link to={`/organization/${organizationId}`}>
      <button className="button-go-organization">
        <FaBuilding className="btn-icon" /> Ver Organización
      </button>
    </Link>
  );
};
