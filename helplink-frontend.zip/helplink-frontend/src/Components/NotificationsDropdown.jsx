import React, { useState, useRef, useEffect } from 'react';
import { X, Info, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useNotifications } from '../contex/NotificationContext'; // Asegúrate de que esta ruta sea correcta

const GlobalStyles = () => (
  <style>{`
    @keyframes fadeInUp {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }
  `}</style>
);

const NotificationsDropdown = () => {
  const { notifications, removeNotification, clearAllNotifications } = useNotifications();
  const [isOpen, setIsOpen] = useState(false);
  const [isButtonHovered, setIsButtonHovered] = useState(false);
  const [hoveredItemId, setHoveredItemId] = useState(null);
  const dropdownRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleNotificationClick = (path) => {
    if (path) {
      navigate(path);
      setIsOpen(false);
    }
  };

  const handleKeyDown = (event, path) => {
    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      handleNotificationClick(path);
    }
  };

  const unreadCount = notifications.length;
  const toggleDropdown = () => setIsOpen(!isOpen);

  const styles = {
    navItemContainer: { position: 'relative', display: 'flex', alignItems: 'center' },
    toggleButton: { display: 'flex', flexDirection: 'column', alignItems: 'center', color: 'rgb(37, 99, 235)', backgroundColor: 'transparent', border: 'none', cursor: 'pointer', padding: '8px', borderRadius: '8px', fontFamily: 'inherit', fontSize: '12px', transition: 'background-color 150ms', position: 'relative' },
    toggleButtonHover: { backgroundColor: 'rgba(59, 130, 246, 0.1)' },
    navIcon: { width: '24px', height: '24px', marginBottom: '4px', fill: 'currentColor' },
    unreadBadge: { position: 'absolute', top: '6px', left: '28px', height: '9px', width: '9px', backgroundColor: '#ef4444', borderRadius: '50%', border: '2px solid white' },
    dropdownPanel: { position: 'absolute', right: 0, top: '100%', marginTop: '12px', width: '24rem', backgroundColor: 'white', borderRadius: '0.75rem', boxShadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1), 0 8px 10px -6px rgba(0, 0, 0, 0.1)', border: '1px solid #e5e7eb', zIndex: 50, overflow: 'hidden' },
    header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '1rem 1.25rem', borderBottom: '1px solid #e5e7eb' },
    headerTitle: { fontSize: '1rem', fontWeight: '600', color: '#1f2937' },
    clearAllButton: { background: 'transparent', border: 'none', color: '#6b7280', cursor: 'pointer', padding: '0.25rem', borderRadius: '0.25rem' },
    notificationList: { maxHeight: '22rem', overflowY: 'auto' },
    notificationItem: { display: 'flex', alignItems: 'flex-start', padding: '1rem 1.25rem', gap: '0.75rem', borderBottom: '1px solid #f3f4f6', outline: 'none' },
    notificationItemUnread: { backgroundColor: '#eff6ff' },
    iconContainer: { backgroundColor: '#dbeafe', borderRadius: '50%', width: '40px', height: '40px', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
    content: { flex: 1, minWidth: 0 },
    title: { fontWeight: '600', color: '#1f2937', marginBottom: '0.25rem', fontSize: '0.875rem' },
    message: { fontSize: '0.875rem', color: '#4b5563', lineHeight: 1.5 },
    removeButton: { backgroundColor: 'transparent', border: 'none', cursor: 'pointer', padding: '0.25rem', borderRadius: '50%', alignSelf: 'flex-start', marginLeft: '0.5rem', color: '#9ca3af', transition: 'opacity 150ms, color 150ms, background-color 150ms' },
  };

  return (
    <div style={styles.navItemContainer} ref={dropdownRef}>
      <GlobalStyles />
      <button onClick={toggleDropdown} style={{...styles.toggleButton, ...(isButtonHovered ? styles.toggleButtonHover : {})}} onMouseEnter={() => setIsButtonHovered(true)} onMouseLeave={() => setIsButtonHovered(false)} aria-haspopup="true" aria-expanded={isOpen}>
        <svg viewBox="0 0 24 24" style={styles.navIcon}><path d="M12 22C13.1 22 14 21.1 14 20H10C10 21.1 10.9 22 12 22ZM18 16V11C18 7.93 16.36 5.36 13.5 4.68V4C13.5 3.17 12.83 2.5 12 2.5C11.17 2.5 10.5 3.17 10.5 4V4.68C7.64 5.36 6 7.93 6 11V16L4 18V19H20V18L18 16Z"/></svg>
        {unreadCount > 0 && <span style={styles.unreadBadge}></span>}
        Notificaciones
      </button>

      {isOpen && (
        <div style={styles.dropdownPanel}>
          <div style={styles.header}>
            <h3 style={styles.headerTitle}>Notificaciones</h3>
            {notifications.length > 0 && <button onClick={clearAllNotifications} style={styles.clearAllButton} title="Borrar todas"><Trash2 size={16} /></button>}
          </div>
          <div style={styles.notificationList}>
            {notifications.length === 0 ? (<p style={{ padding: '2rem', textAlign: 'center', color: '#6b7280' }}>No tienes notificaciones nuevas.</p>) : (
              notifications.map((n, index) => (
                <div key={n.id} onClick={() => handleNotificationClick(n.path)} role="button" tabIndex={0} onKeyDown={(e) => handleKeyDown(e, n.path)} onMouseEnter={() => setHoveredItemId(n.id)} onMouseLeave={() => setHoveredItemId(null)} style={{ ...styles.notificationItem, cursor: n.path ? 'pointer' : 'default', ...(!n.read ? styles.notificationItemUnread : {}), animation: `fadeInUp 0.4s ease-out ${index * 50}ms backwards`}}>
                  <div style={styles.iconContainer}><Info style={{ color: '#3b82f6' }} /></div>
                  <div style={styles.content}>
                    <p style={styles.title}>{n.title}</p>
                    <p style={styles.message}>{n.body}</p>
                  </div>
                  <button onClick={(e) => { e.stopPropagation(); removeNotification(n.id); }} style={{...styles.removeButton, opacity: hoveredItemId === n.id ? 1 : 0}} title="Borrar notificación"><X size={16} /></button>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default NotificationsDropdown;