import React from 'react';
import '../assets/style/Home.css';

const Header = () => {
    return (
      <div className='header'>
        <div className="div-logo">
          <img className="logo" src="/logo.svg" alt="HelpLink Logo" />
        </div>
        <nav className="header-nav">
          <a href="#inicio" className="nav-item">
            {/* Icono de Inicio (Casa) */}
            <svg className="nav-icon" viewBox="0 0 24 24">
              <path d="M10 20V14H14V20H19V12H22L12 3L2 12H5V20H10Z"/>
            </svg>
            Inicio
          </a>
          <a href="#eventos" className="nav-item">
            {/* Icono de Eventos (Calendario) */}
            <svg className="nav-icon" viewBox="0 0 24 24">
              <path d="M19 3H18V1H16V3H8V1H6V3H5C3.89 3 3 3.9 3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 21 20.1 21 19V5C21 3.9 20.1 3 19 3ZM19 19H5V9H19V19ZM19 7H5V5H19V7Z"/>
            </svg>
            Eventos
          </a>
          <a href="#mensajes" className="nav-item">
            {/* Icono de Mensajes (Burbuja de diálogo) */}
            <svg className="nav-icon" viewBox="0 0 24 24">
              <path d="M20 2H4C2.9 2 2 2.9 2 4V22L6 18H20C21.1 18 22 17.1 22 16V4C22 2.9 21.1 2 20 2Z"/>
            </svg>
            Mensajes
          </a>
          <a href="#notificaciones" className="nav-item">
            {/* Icono de Notificaciones (Campana) */}
            <svg className="nav-icon" viewBox="0 0 24 24">
              <path d="M12 22C13.1 22 14 21.1 14 20H10C10 21.1 10.9 22 12 22ZM18 16V11C18 7.93 16.36 5.36 13.5 4.68V4C13.5 3.17 12.83 2.5 12 2.5C11.17 2.5 10.5 3.17 10.5 4V4.68C7.64 5.36 6 7.93 6 11V16L4 18V19H20V18L18 16Z"/>
            </svg>
            Notificaciones
          </a>
          <a href="#perfil" className="nav-item">
            {/* Icono de Perfil (Usuario) */}
            <svg className="nav-icon" viewBox="0 0 24 24">
              <path d="M12 2C14.21 2 16 3.79 16 6C16 8.21 14.21 10 12 10C9.79 10 8 8.21 8 6C8 3.79 9.79 2 12 2ZM12 12C16.42 12 20 13.79 20 16V18H4V16C4 13.79 7.58 12 12 12Z"/>
            </svg>
            Perfil
          </a>
        </nav>
      </div>
    );
};

export default Header;