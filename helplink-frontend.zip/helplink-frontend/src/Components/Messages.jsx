// ChatMensajes.jsx
import React from 'react';
import '../assets/style/Messages.css';
import NavarCompleto from './NavarCompleto';

const Messages = () => {
    return (
        <>
            <NavarCompleto />
            <div className="chat-container">
                {/* Lista de conversaciones */}
                <aside className="chat-sidebar">
                    {[1, 2, 3, 4].map((item, i) => (
                    <div key={i} className={`chat-item ${i === 1 ? 'active' : ''}`}>
                        <div className="chat-avatar" />
                        <div className="chat-details">
                        <div className="chat-name">Nombre de usuario</div>
                        <div className="chat-preview">Mensaje acordado por el tamaño</div>
                        </div>
                        <div className="chat-date">Fecha</div>
                    </div>
                    ))}
                </aside>
                {/* Panel de mensajes */}
                <section className="chat-main">
                    <div className="chat-header">
                    <div className="chat-user">
                        <div className="chat-avatar" />
                        <span>Nombre de usuario</span>
                    </div>
                    <div className="chat-options">&#x22EE;</div>
                    </div>

                    <div className="chat-body">
                    <div className="chat-message left">
                        <div className="bubble">Mensaje</div>
                        <div className="hora">Hora</div>
                    </div>
                    <div className="chat-message right">
                        <div className="bubble">Mensaje</div>
                        <div className="hora">Hora</div>
                    </div>
                    </div>

                    <div className="chat-input">
                    <input type="text" placeholder="Enviar mensaje..." />
                    <button>
                        <svg height="24" viewBox="0 0 24 24">
                        <path fill="#0277BD" d="M2,21L23,12L2,3V10L17,12L2,14V21Z" />
                        </svg>
                    </button>
                    </div>
                </section>
            </div>
        </>
    );
};

export default Messages;