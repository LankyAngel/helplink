import React from "react";

const GoogleMapEmbed = ({
  lat,
  lng,
  address = "",
  width = "100%",
  height = "300px",
}) => {
  if (!lat || !lng) {
    return null;
  }

  // URL dinámica para el mapa embebido.
  const mapSrc = `https://maps.google.com/maps?q=${lat},${lng}&hl=es&z=15&output=embed`;

  return (
    <div style={{ width: width, marginTop: "15px" }}>
      {address && (
        <div style={{ marginBottom: "10px", fontSize: "1.1em" }}>
          <strong> {address}</strong>
        </div>
      )}

      <iframe
        width="100%"
        height={height}
        src={mapSrc}
        title="Mapa de Ubicación"
        style={{ border: 0, borderRadius: "8px", display: "block" }}
        allowFullScreen=""
        loading="lazy"
        referrerPolicy="no-referrer-when-downgrade"
      ></iframe>
    </div>
  );
};

export default GoogleMapEmbed;
