import React, { useState } from "react";
import "../assets/style/Home.css";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../contex/AuthProvider";
import NotificationsDropdown from "./NotificationsDropdown";
import { getUserInfo } from "../services/authService";

const NavarCompleto = () => {
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const rol = async (e) => {
    if (isAuthenticated) {
      const data = await getUserInfo();
      const user = data.find(
        (u) => u.username === localStorage.getItem("username")
      );
      const rol = user.global_role.role;
      const statusOrg = user.organization?.status;
      switch (rol) {
        case "volunteer":
          navigate("/home");
          break;
        case "organization_staff":
          navigate("/branchAdminPanel");
          break;

        case "organization_admin":
          if (statusOrg === "approved") {
            navigate("/organizationAdminPanel");
          } else {
            //setErrorMsg("Tu organización no está aprobada aún.");
            navigate("/home");
          }
          break;

        default:
          navigate("/home");
          break;
      }
    } else {
      navigate("/home");
    }
  };

  const rolForEvent = async (e) => {
    if (isAuthenticated) {
      const data = await getUserInfo();
      const user = data.find(
        (u) => u.username === localStorage.getItem("username")
      );
      const rol = user.global_role.role;
      const statusOrg = user.organization?.status;
      switch (rol) {
        case "volunteer":
          navigate("/events");
          break;
        case "organization_staff":
          navigate("/events");
          break;

        case "organization_admin":
          if (statusOrg === "approved") {
            navigate("/showEventsOrganization");
          } else {
            //setErrorMsg("Tu organización no está aprobada aún.");
            navigate("/events");
          }
          break;

        default:
          navigate("/home");
          break;
      }
    } else {
      navigate("/events");
    }
  };

  //Redirecciona al Login
  const goLogin = (e) => {
    e.preventDefault(); // Previene el comportamiento por defecto del enlace
    navigate("/login"); // Navega a la ruta /login
  };

  const goEvents = (e) => {
    e.preventDefault(); // Previene el comportamiento por defecto del enlace
    //navigate("/events"); // Navega a la ruta /events
    rolForEvent();
  };

  const goHome = async (e) => {
    e.preventDefault(); // Previene el comportamiento por defecto del enlace
    rol();
  };

  const goProfile = (e) => {
    e.preventDefault(); // Previene el comportamiento por defecto del enlace
    navigate("/profile"); // Navega a la ruta /profile
  };

  const goRegister = (e) => {
    e.preventDefault(); // Previene el comportamiento por defecto del enlace
    navigate("/register"); // Navega a la ruta /profile
  };

  const goMessages = (e) => {
    e.preventDefault(); // Previene el comportamiento por defecto del enlace
    navigate("/messages"); // Navega a la ruta /messages
  };

  return (
    <>
      <header className="home-header">
        <a href="/" onClick={goHome}>
          <img src="/logo2.svg" alt="Logo" className="logo" />
        </a>

        {/* Botón hamburguesa para móviles */}
        <button
          className="mobile-menu-btn"
          aria-label="Abrir menú"
          onClick={() => setMobileMenuOpen((open) => !open)}
        >
          <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
            <rect y="4" width="24" height="2" rx="1" fill="#2563eb" />
            <rect y="11" width="24" height="2" rx="1" fill="#2563eb" />
            <rect y="18" width="24" height="2" rx="1" fill="#2563eb" />
          </svg>
        </button>

        <nav
          className={`header-nav ${isAuthenticated ? "nav-right" : "nav-center"} ${mobileMenuOpen ? "mobile-open" : ""}`}
        >
          <a
            href="#inicio"
            className="nav-item"
            onClick={(e) => {
              goHome(e);
              setMobileMenuOpen(false);
            }}
          >
            <svg className="nav-icon" viewBox="0 0 24 24">
              <path d="M10 20V14H14V20H19V12H22L12 3L2 12H5V20H10Z" />
            </svg>
            Inicio
          </a>

          <a
            href="#eventos"
            className="nav-item"
            onClick={(e) => {
              goEvents(e);
              setMobileMenuOpen(false);
            }}
          >
            <svg className="nav-icon" viewBox="0 0 24 24">
              <path d="M19 3H18V1H16V3H8V1H6V3H5C3.89 3 3 3.9 3 5V19C3 20.1 3.9 21 5 21H19C20.1 21 21 20.1 21 19V5C21 3.9 20.1 3 19 3ZM19 19H5V9H19V19ZM19 7H5V5H19V7Z" />
            </svg>
            Eventos
          </a>

          {isAuthenticated && (
            <>
              <a
                href="#mensajes"
                className="nav-item"
                onClick={(e) => {
                  goMessages(e);
                  setMobileMenuOpen(false);
                }}
              >
                <svg className="nav-icon" viewBox="0 0 24 24">
                  <path d="M20 2H4C2.9 2 2 2.9 2 4V22L6 18H20C21.1 18 22 17.1 22 16V4C22 2.9 21.1 2 20 2Z" />
                </svg>
                Mensajes
              </a>

              <NotificationsDropdown />

              <a
                href="#perfil"
                className="nav-item"
                onClick={(e) => {
                  goProfile(e);
                  setMobileMenuOpen(false);
                }}
              >
                <svg className="nav-icon" viewBox="0 0 24 24">
                  <path d="M12 2C14.21 2 16 3.79 16 6C16 8.21 14.21 10 12 10C9.79 10 8 8.21 8 6C8 3.79 9.79 2 12 2ZM12 12C16.42 12 20 13.79 20 16V18H4V16C4 13.79 7.58 12 12 12Z" />
                </svg>
                Perfil
              </a>
            </>
          )}
        </nav>

        <div className="header-actions">
          {!isAuthenticated && (
            <>
              <a
                href="#join"
                className="join-now"
                onClick={(e) => {
                  goRegister(e);
                  setMobileMenuOpen(false);
                }}
              >
                Únete ahora
              </a>
              <a
                href="#signin"
                className="sign-in"
                onClick={(e) => {
                  goLogin(e);
                  setMobileMenuOpen(false);
                }}
              >
                Iniciar sesión
              </a>
            </>
          )}
        </div>
      </header>
    </>
  );
};

export default NavarCompleto;
