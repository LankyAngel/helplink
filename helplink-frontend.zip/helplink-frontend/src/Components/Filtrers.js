const apiURL = process.env.REACT_APP_API_URL;

export const formatearFecha = (fechaStr) => {
  if (!fechaStr) return "";
  const [year, month, day] = fechaStr.split("-");
  const meses = [
    "enero",
    "febrero",
    "marzo",
    "abril",
    "mayo",
    "junio",
    "julio",
    "agosto",
    "septiembre",
    "octubre",
    "noviembre",
    "diciembre",
  ];
  return `${parseInt(day)} de ${meses[parseInt(month) - 1]} de ${year}`;
};

export const getCategorias = async () => {
  const res = await fetch(`${apiURL}/categories`);
  if (!res.ok) throw new Error("Error al cargar categorías");
  return await res.json();
};

export const opcionesFecha = [
  { value: "todos", label: "Todas las fechas" },
  { value: "esta-semana", label: "Esta semana" },
  { value: "este-mes", label: "Este mes" },
  { value: "proximo-mes", label: "Próximo mes" },
];

export const getStartOfWeek = (date = new Date()) => {
  const day = date.getDay();
  const diff = date.getDate() - day + (day === 0 ? -6 : 1);
  return new Date(date.setDate(diff));
};

export const getEndOfWeek = (startDate) => {
  const end = new Date(startDate);
  end.setDate(end.getDate() + 6);
  return end;
};

export const getStartOfMonth = (date = new Date()) =>
  new Date(date.getFullYear(), date.getMonth(), 1);

export const getEndOfMonth = (date = new Date()) =>
  new Date(date.getFullYear(), date.getMonth() + 1, 0);

export const getStartOfNextMonth = (date = new Date()) =>
  new Date(date.getFullYear(), date.getMonth() + 1, 1);

export const getEndOfNextMonth = (date = new Date()) =>
  new Date(date.getFullYear(), date.getMonth() + 2, 0);

export const obtenerFechasReferencia = () => {
  const hoy = new Date();
  const inicioSemana = getStartOfWeek(new Date());

  return {
    inicioSemana,
    finSemana: getEndOfWeek(inicioSemana),
    primerDiaMes: getStartOfMonth(hoy),
    ultimoDiaMes: getEndOfMonth(hoy),
    primerDiaProximoMes: getStartOfNextMonth(hoy),
    ultimoDiaProximoMes: getEndOfNextMonth(hoy),
  };
};

export const transformarEventos = (data) =>
  data
    .filter((evento) => evento.status === "published")
    .map((evento) => {
      const nombreCategoriaOriginal = evento.categories?.[0]?.name || "Otros";

      const categoriaCss = nombreCategoriaOriginal
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .replace(/\s+/g, "-");

      return {
        id: evento.id,
        titulo: evento.title,
        descripcion: evento.description,
        capacidad: evento.capacity,
        fecha: evento.event_date, // YYYY-MM-DD
        hora: evento.start_time?.substring(0, 5) || "00:00",
        ubicacion:
          evento.locations?.[0]?.address ||
          evento.branch?.address ||
          "Ubicación no disponible",
        categoriaCss,
        categoriaTexto: nombreCategoriaOriginal,
        imagen: evento.banner || "/simple_logo.svg",
        organizador:
          evento.branch?.organization?.name || "Organización no especificada",
      };
    });

export const filtrarEventos = (
  eventos,
  filtroCategoria,
  filtroFecha,
  fechasReferencia
) => {
  const {
    inicioSemana,
    finSemana,
    primerDiaMes,
    ultimoDiaMes,
    primerDiaProximoMes,
    ultimoDiaProximoMes,
  } = fechasReferencia;

  return eventos.filter((evento) => {
    const [year, month, day] = evento.fecha.split("-");
    const fechaEvento = new Date(year, month - 1, day);

    const categoriaOK =
      filtroCategoria === "todos" || evento.categoriaCss === filtroCategoria;

    let fechaOK = true;
    if (filtroFecha === "esta-semana") {
      fechaOK = fechaEvento >= inicioSemana && fechaEvento <= finSemana;
    } else if (filtroFecha === "este-mes") {
      fechaOK = fechaEvento >= primerDiaMes && fechaEvento <= ultimoDiaMes;
    } else if (filtroFecha === "proximo-mes") {
      fechaOK =
        fechaEvento >= primerDiaProximoMes &&
        fechaEvento <= ultimoDiaProximoMes;
    }

    return categoriaOK && fechaOK;
  });
};
