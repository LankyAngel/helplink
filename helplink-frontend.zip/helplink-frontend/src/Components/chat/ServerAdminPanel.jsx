import React, { useEffect, useState } from "react";
import axios from "axios";

export default function ServerAdminPanel({ server, token, setShowAdminPanel, onReturn, onMediaUpdate }) {
    const serverId = server.id;

    const [members, setMembers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [updatingRoleId, setUpdatingRoleId] = useState(null);
    const [myRole, setMyRole] = useState(null);
    const [bannerFile, setBannerFile] = useState(null);
    const [logoFile, setLogoFile] = useState(null);
    const [uploading, setUploading] = useState(false);
    const [roleChanges, setRoleChanges] = useState({});
    const currentUserId = JSON.parse(localStorage.getItem("user"))?.id;
    const [description, setDescription] = useState(server.description || "");

    const ROLE_OPTIONS = ["admin", "moderator", "member"];

    const handleSaveMedia = async () => {
        const formData = new FormData();
        if (bannerFile) formData.append("banner", bannerFile);
        if (logoFile) formData.append("logo", logoFile);
        formData.append("description", description); // ✅ agregar descripción

        try {
            setUploading(true);
            const res = await axios.patch(
                `${process.env.REACT_APP_API_URL}/servers/${serverId}/update-media/`,
                formData,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                        "Content-Type": "multipart/form-data",
                    },
                    withCredentials: true,
                }
            );

            if ((res.data.banner || res.data.logo) && onMediaUpdate) {
                onMediaUpdate({
                    banner: res.data.banner,
                    logo: res.data.logo,
                });
            }

            alert("Cambios guardados con éxito.");
        } catch (error) {
            console.error("Error al subir medios o descripción:", error);
            alert("Hubo un problema al guardar los cambios.");
        } finally {
            setUploading(false);
        }
    };

    useEffect(() => {
        fetchMembers();
        fetchMyRole();
    }, []);

    const fetchMembers = async () => {
        try {
            const res = await axios.get(
                `${process.env.REACT_APP_API_URL}/servers/${serverId}/members/`,
                {
                    headers: { Authorization: `Bearer ${token}` },
                    withCredentials: true,
                }
            );
            setMembers(res.data);
        } catch (error) {
            console.error("Error al obtener miembros:", error);
        } finally {
            setLoading(false);
        }
    };

    const fetchMyRole = async () => {
        try {
            const res = await axios.get(
                `${process.env.REACT_APP_API_URL}/servers/${serverId}/my-role/`,
                {
                    headers: { Authorization: `Bearer ${token}` },
                    withCredentials: true,
                }
            );
            setMyRole(res.data.role);
        } catch (error) {
            console.error("Error al obtener rol propio:", error);
        }
    };

    const handleRemoveMember = async (membershipId, username) => {
        const confirm = window.confirm(`¿Eliminar a "${username}" del servidor?`);
        if (!confirm) return;

        try {
            await axios.delete(
                `${process.env.REACT_APP_API_URL}/server-memberships/${membershipId}/remove/`,
                {
                    headers: { Authorization: `Bearer ${token}` },
                    withCredentials: true,
                }
            );
            fetchMembers(); // Refrescar
        } catch (err) {
            console.error("Error al eliminar:", err);
            alert("No se pudo eliminar al miembro.");
        }
    };

    const handleRoleChange = async (membershipId, newRole) => {
        try {
            setUpdatingRoleId(membershipId);
            await axios.put(
                `${process.env.REACT_APP_API_URL}/server/${membershipId}/roles/`,
                { role: newRole },
                {
                    headers: { Authorization: `Bearer ${token}` },
                    withCredentials: true,
                }
            );
            fetchMembers();
            setRoleChanges((prev) => {
                const updated = { ...prev };
                delete updated[membershipId];
                return updated;
            });
        } catch (error) {
            console.error("Error al actualizar el rol:", error);
        } finally {
            setUpdatingRoleId(null);
        }
    };

    if (loading) return <p>Cargando miembros...</p>;

    return (
        <div className="server-admin-panel">
            <h2>Administrar Servidor: <strong>{server.name}</strong></h2>

            <button
                onClick={onReturn}
                className="volver-btn"
            >
                ← Volver al servidor
            </button>

            {(myRole === "admin" || myRole === "owner") && (
                <div className="server-media-edit">
                    <h3>Editar servidor</h3>

                    <label htmlFor="description">Descripción del servidor:</label>
                    <textarea
                        id="description"
                        rows={3}
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        placeholder="Agrega una descripción..."
                    />

                    <label htmlFor="banner">Nuevo Banner:</label>
                    <input
                        type="file"
                        id="banner"
                        accept="image/*"
                        onChange={(e) => setBannerFile(e.target.files[0])}
                    />

                    <label htmlFor="logo">Nuevo Logo:</label>
                    <input
                        type="file"
                        id="logo"
                        accept="image/*"
                        onChange={(e) => setLogoFile(e.target.files[0])}
                    />

                    <button onClick={handleSaveMedia} disabled={uploading}>
                        {uploading ? "Guardando..." : "Guardar Cambios"}
                    </button>
                </div>
            )}

            {members.length === 0 ? (
                <p>No hay miembros en este servidor.</p>
            ) : (
                <table className="server-admin-table">
                    <thead>
                        <tr>
                            <th>Usuario</th>
                            <th>Correo</th>
                            <th>Rol</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        {members.map((member) => (
                            <tr key={member.user_id}>
                                <td>{member.username}</td>
                                <td>{member.email}</td>
                                <td className="capitalize">{member.role}</td>
                                <td>
                                    <select
                                        value={roleChanges[member.user_id] || member.role}
                                        onChange={(e) =>
                                            setRoleChanges((prev) => ({
                                                ...prev,
                                                [member.user_id]: e.target.value,
                                            }))
                                        }
                                        disabled={updatingRoleId === member.user_id}
                                        className="role-selector"
                                    >
                                        {ROLE_OPTIONS.map((r) => (
                                            <option key={r} value={r}>
                                                {r}
                                            </option>
                                        ))}
                                    </select>

                                    <button
                                        onClick={() => handleRoleChange(member.id, roleChanges[member.user_id])}
                                        className="action-button save"
                                        disabled={
                                            !roleChanges[member.user_id] ||
                                            roleChanges[member.user_id] === member.role ||
                                            updatingRoleId === member.user_id
                                        }
                                    >
                                        Guardar cambios
                                    </button>

                                    {member.user_id !== currentUserId ? (
                                        <button
                                            onClick={() => handleRemoveMember(member.id, member.username)}
                                            className="action-button delete"
                                        >
                                            Eliminar
                                        </button>
                                    ) : (
                                        <button
                                            className="action-button disabled"
                                            disabled
                                        >
                                            Eliminar
                                        </button>
                                    )}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            )}
        </div>
    );
}
