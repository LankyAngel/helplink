import React, { useState, useEffect, useRef } from "react";
import { FaPaperclip, FaSmile, FaPaperPlane } from "react-icons/fa";
import EmojiPicker from "emoji-picker-react";

export default function MessageInput({ onSend, replyTo, onCancelReply, isReadOnly = false }) {
    const [message, setMessage] = useState("");
    const [showEmojiPicker, setShowEmojiPicker] = useState(false);
    const [uploading, setUploading] = useState(false);
    const [selectedFile, setSelectedFile] = useState(null);
    const [selectedFileName, setSelectedFileName] = useState("");
    const [selectedFilePreview, setSelectedFilePreview] = useState(null); // para imagen

    const activeChannel = localStorage.getItem("active_channel");
    const token = localStorage.getItem("access_token");

    const handleSend = async () => {
        if (!message.trim() && !selectedFile) return;

        const activeChannel = localStorage.getItem("active_channel");
        if (!activeChannel) return;

        setUploading(true);

        let attachmentUrl = null;
        let externalData = null;

        // Subir archivo si existe
        if (selectedFile) {
            const formData = new FormData();
            formData.append("file", selectedFile);
            formData.append("channel_id", activeChannel);

            try {
                const res = await fetch(`${process.env.REACT_APP_API_URL}/chat/upload/`, {
                    method: "POST",
                    headers: {
                        Authorization: `Bearer ${token}`
                    },
                    body: formData
                });

                const data = await res.json();

                if (res.ok) {
                    attachmentUrl = data.attachment;
                    externalData = {
                        attachment: data.attachment,
                        timestamp: data.timestamp,
                        id: data.id,
                        sender_id: data.sender_id,
                        sender_name: data.sender_name,
                        original_filename: data.original_filename
                    };
                } else {
                    alert("Error al subir el archivo");
                    return;
                }
            } catch (err) {
                console.error("Error de subida:", err);
                return;
            }
        }

        onSend(message, externalData);

        setMessage("");
        setSelectedFile(null);
        setSelectedFileName("");
        setSelectedFilePreview(null);
        setUploading(false);
    };

    const handleKeyDown = (e) => {
        if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            handleSend();
        }
    };

    const onEmojiClick = (emojiData) => {
        setMessage((prev) => prev + emojiData.emoji);
    };

    const handleFileSelect = (e) => {
        const file = e.target.files[0];
        if (!file) return;

        setSelectedFile(file);
        setSelectedFileName(file.name);

        if (file.type.startsWith("image/")) {
            const reader = new FileReader();
            reader.onloadend = () => {
                setSelectedFilePreview(reader.result);
            };
            reader.readAsDataURL(file);
        } else {
            setSelectedFilePreview(null);
        }
    };

    const emojiPickerRef = useRef(null);
    const emojiBtnRef = useRef(null);

    // Cerrar el emoji picker al hacer clic fuera
    useEffect(() => {
        const handleClickOutside = (event) => {
            if (
                showEmojiPicker &&
                emojiPickerRef.current &&
                !emojiPickerRef.current.contains(event.target) &&
                !emojiBtnRef.current.contains(event.target)
            ) {
                setShowEmojiPicker(false);
            }
        };

        document.addEventListener("mousedown", handleClickOutside);
        return () => {
            document.removeEventListener("mousedown", handleClickOutside);
        };
    }, [showEmojiPicker]);

    if (isReadOnly) {
        return (
            <div className="message-input-container readonly-msg">
                <p className="read-only">
                    ⚠️ Este evento ha finalizado. No puedes enviar más mensajes. ⚠️
                </p>
            </div>
        );
    }

    return (
        <>
            {replyTo && (
                <div
                    className="reply-preview"
                >
                    <div style={{ display: "flex", justifyContent: "space-between" }}>
                        <div>
                            <strong>Respondiendo a {replyTo.sender_name}:</strong> {replyTo.content}
                        </div>
                        <button onClick={onCancelReply} style={{ background: "none", border: "none", color: "#ccc", cursor: "pointer" }}>
                            ✖
                        </button>
                    </div>
                </div>
            )}

            {/* Mostrar preview del archivo (antes del input) */}
            {selectedFileName && (
                <div
                    className="file-preview"
                >
                    {selectedFilePreview ? (
                        <img
                            src={selectedFilePreview}
                            alt="preview"
                            style={{ maxHeight: "60px", borderRadius: "6px" }}
                        />
                    ) : (
                        <span style={{ fontSize: "1.2rem" }}></span>
                    )}
                    <span style={{ color: "#fff", fontSize: "0.85rem" }}>
                        <strong>{selectedFileName}</strong>
                    </span>
                    <button
                        onClick={() => {
                            setSelectedFileName("");
                            setSelectedFilePreview(null);
                        }}
                        style={{
                            background: "transparent",
                            border: "none",
                            color: "#fff",
                            cursor: "pointer",
                            fontSize: "1rem"
                        }}
                    >
                        ✖
                    </button>
                </div>
            )}

            <div className="message-input-container" style={{ position: "relative" }}>
                {/* Selector de archivo */}
                <input
                    type="file"
                    id="file-input"
                    style={{ display: "none" }}
                    onChange={handleFileSelect}
                />
                <label htmlFor="file-input" className="icon-btn" style={{ cursor: "pointer" }}>
                    <FaPaperclip />
                </label>

                {/* Input de texto */}
                <textarea
                    className="message-textarea"
                    placeholder={replyTo ? `Respondiendo a ${replyTo.sender_name}...` : "Escribe un mensaje..."}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    onKeyDown={handleKeyDown}
                    rows={1}
                />

                {/* Picker emoji */}
                <button
                    ref={emojiBtnRef}
                    className="icon-btn"
                    type="button"
                    onClick={() => setShowEmojiPicker((prev) => !prev)}
                >
                    <FaSmile />
                </button>

                {showEmojiPicker && (
                    <div
                        ref={emojiPickerRef}
                        style={{
                            position: "absolute",
                            bottom: "60px",
                            right: "10px",
                            zIndex: 1000,
                            background: "#2f3136",
                            borderRadius: "8px",
                            boxShadow: "0 4px 10px rgba(0,0,0,0.5)"
                        }}
                    >
                        <EmojiPicker
                            onEmojiClick={onEmojiClick}
                            theme="dark"
                            searchDisabled={false}
                            skinTonesDisabled={false}
                        />
                    </div>
                )}

                <button className="send-btn" onClick={handleSend} disabled={uploading}>
                    <FaPaperPlane />
                </button>
            </div>
        </>
    );
}
