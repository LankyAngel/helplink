import React, { useEffect, useState } from "react";

export default function ServerLanding({
    server,
    onJoinMainChannel,
    setShowAdminPanel,
    onExitSuccess
}) {
    const [canAdmin, setCanAdmin] = useState(false);
    const token = localStorage.getItem("access");

    useEffect(() => {
        if (!server || !token) return;

        const fetchRole = async () => {
            try {
                const res = await fetch(
                    `${process.env.REACT_APP_API_URL}/servers/${server.id}/my-role/`,
                    {
                        headers: {
                            Authorization: `Bearer ${token}`
                        }
                    }
                );

                const data = await res.json();
                setCanAdmin(data.role === "admin" || data.role === "owner");
            } catch (err) {
                console.error("Error al obtener rol dinámico:", err);
                setCanAdmin(false);
            }
        };

        fetchRole();
    }, [server, token]);

    if (!server) return null;

    return (
        <div className="server-landing-container">
            {/* Banner */}
            <div className="server-banner">
                <div
                    className="server-banner-bg"
                    style={{
                        backgroundImage: `url(${server.banner || "/default_banner.jpg"})`
                    }}
                />
            </div>

            {/* Logo */}
            <div className="server-logo-wrapper">
                <img
                    src={server.logo || "/default_logo.jpg"}
                    alt="Server Logo"
                    className="server-logo"
                />
            </div>

            {/* Nombre y descripción */}
            <div className="server-info">
                <h1 className="server-title">{server.name}</h1>
                <p className="server-description">{server.description}</p>
            </div>

            {/* Stats */}
            <div className="server-stats">
                <Stat label="Miembros" value={server.members_count || 0} />
                <Stat label="Canales" value={server.channels_count || 0} />
                <Stat
                    label="Creado"
                    value={
                        server.created_at
                            ? new Date(server.created_at).toLocaleDateString()
                            : "—"
                    }
                />
            </div>

            <div className="server-actions">
                <button onClick={onJoinMainChannel} className="server-cta">
                    Entrar al canal principal
                </button>

                {canAdmin && (
                    <button className="server-cta" onClick={() => setShowAdminPanel({ show: true })}>
                        Administrar servidor
                    </button>
                )}

                {!canAdmin && (
                    <button
                        className="exit-server-btn"
                        onClick={() => {
                            const confirmExit = window.confirm(
                                "¿Seguro que quieres salir de este servidor? Ya no podrás acceder a sus canales."
                            );
                            if (!confirmExit) return;

                            fetch(`${process.env.REACT_APP_API_URL}/servers/${server.id}/exit/`, {
                                method: "DELETE",
                                headers: {
                                    Authorization: `Bearer ${token}`
                                }
                            })
                                .then((res) => {
                                    if (!res.ok) throw new Error("No se pudo salir del servidor.");
                                    alert("Saliste del servidor exitosamente.");
                                    onExitSuccess?.(); // <- asegúrate de que esto exista
                                })
                                .catch((err) => {
                                    console.error("Error al salir del servidor:", err);
                                    alert("Ocurrió un error al intentar salir del servidor.");
                                });
                        }}
                    >
                        Salir del servidor
                    </button>
                )}
            </div>
        </div>
    );
}

function Stat({ label, value }) {
    return (
        <div className="server-stat-item">
            <span className="server-stat-value">{value}</span>
            <span className="server-stat-label">{label}</span>
        </div>
    );
}
