import React, { useEffect, useState } from "react";
import axios from "axios";

export default function Sidebar({ onSelectServer, onSelectChannel, refreshTrigger, activeChannel, activeServerId }) {
    const [servers, setServers] = useState([]);
    const [activeServer, setActiveServer] = useState(null);
    const [channels, setChannels] = useState([]);
    const token = localStorage.getItem("access_token");

    const fetchServers = () => {
        axios.get(`${process.env.REACT_APP_API_URL}/servers/my/`, {
            headers: {
                Authorization: `Bearer ${token}`
            },
            withCredentials: true
        })
            .then(res => setServers(res.data))
            .catch(err => console.error("Error al cargar servers:", err));
    };

    useEffect(() => {
        fetchServers();
    }, [token, refreshTrigger]); // este trigger fuerza el refresh

    const fetchChannels = async (serverObj) => {
        try {
            const res = await axios.get(`${process.env.REACT_APP_API_URL}/servers/${serverObj.id}/channels/`, {
                headers: { Authorization: `Bearer ${token}` },
                withCredentials: true
            });
            setChannels(res.data);
            setActiveServer(serverObj.id);
            onSelectServer({ ...serverObj, channels: res.data });
        } catch (err) {
            console.error("Error al cargar canales:", err);
        }
    };

    const generalChannels = channels.filter(c => !c.is_event && !c.is_private);
    const eventChannels = channels.filter(c => c.is_event);
    const archivedEvents = channels.filter(c => !c.is_event && c.is_private);

    return (
        <aside className="chat-sidebar">
            <div className="section-title">Servidores</div>
            {servers.map(server => (
                <button
                    key={server.id}
                    onClick={() => fetchChannels(server)}
                    className={`server-btn ${server.id === activeServerId ? "active" : ""}`}
                >
                    {server.name}
                </button>
            ))}

            {activeServer && (
                <>
                    <div className="section-title">Canales</div>
                    {generalChannels.length > 0 && (
                        <>
                            <div className="channel-group-title">Canales generales</div>
                            {generalChannels.map(ch => (
                                <button
                                    key={ch.id}
                                    onClick={() => {
                                        localStorage.setItem("active_channel", ch.id);
                                        onSelectChannel(null);
                                        setTimeout(() => onSelectChannel(ch.id), 0);
                                    }}
                                    className={`channel-btn ${ch.id === activeChannel ? "active" : ""}`}
                                >
                                    # {ch.name}
                                </button>
                            ))}
                        </>
                    )}

                    {eventChannels.length > 0 && (
                        <>
                            <div className="channel-group-title">Eventos activos</div>
                            {eventChannels.map(ch => (
                                <button
                                    key={ch.id}
                                    onClick={() => {
                                        localStorage.setItem("active_channel", ch.id);
                                        onSelectChannel(null);
                                        setTimeout(() => onSelectChannel(ch.id), 0);
                                    }}
                                    className={`channel-btn ${ch.id === activeChannel ? "active" : ""}`}
                                >
                                    📅 {ch.name}
                                </button>
                            ))}
                        </>
                    )}

                    {archivedEvents.length > 0 && (
                        <>
                            <div className="channel-group-title">Eventos terminados</div>
                            {archivedEvents.map(ch => (
                                <button
                                    key={ch.id}
                                    onClick={() => {
                                        localStorage.setItem("active_channel", ch.id);
                                        onSelectChannel(null);
                                        setTimeout(() => onSelectChannel(ch.id), 0);
                                    }}
                                    className={`channel-btn ${ch.id === activeChannel ? "active" : ""}`}
                                >
                                    🗃️ {ch.name}
                                </button>
                            ))}
                        </>
                    )}
                </>
            )}
        </aside>
    );
}
