import React, { useEffect, useRef } from "react";
import { FaReply } from "react-icons/fa";

export default function MessageList({ messages, onReact, onReply, reactionMap, currentUser }) {
    const endRef = useRef(null);
    const REACTION_EMOJIS = ["👍", "❤️", "😆", "😮", "😭"];

    const sortedMessages = [...messages].sort(
        (a, b) => new Date(a.timestamp) - new Date(b.timestamp)
    );

    useEffect(() => {
        if (endRef.current) {
            endRef.current.scrollIntoView({ behavior: "smooth" });
        }
    }, [messages]);

    const getUserColor = (name) => {
        const colors = ["#ff73fa", "#faa61a", "#3ba55d", "#7289da", "#f04747"];
        return name ? colors[name.charCodeAt(0) % colors.length] : colors[0];
    };

    const groupReactions = (messageId) => {
        const reactions = reactionMap?.[messageId] || [];
        const grouped = {};

        reactions.forEach(({ user, emoji }) => {
            if (!grouped[emoji]) grouped[emoji] = [];
            grouped[emoji].push(user);
        });

        return grouped;
    };

    return (
        <div className="chat-messages">
            {sortedMessages.map((msg, index) => {
                const prevMsg = sortedMessages[index - 1];
                const sameUser = prevMsg && prevMsg.sender_id === msg.sender_id;
                const groupedReactions = groupReactions(msg.id);
                const fileName = msg.attachment ? msg.attachment.split("/").pop() : "";
                const fileExtension = fileName ? fileName.split(".").pop() : "";

                return (
                    <div
                        key={msg.clientId || msg.id}
                        className={`message ${sameUser ? "grouped" : ""}`}
                        style={{ position: "relative" }}
                    >
                        {!sameUser && (
                            <img
                                src={msg.sender_profile || "/avatar.png"}
                                alt="avatar"
                                className="avatar"
                            />
                        )}

                        <div className="message-content">
                            {!sameUser && (
                                <div className="message-header">
                                    <span
                                        className="username"
                                        style={{ color: getUserColor(msg.sender_name) }}
                                    >
                                        {msg.sender_name || "Usuario"}
                                    </span>
                                    <span className="timestamp">
                                        {msg.timestamp
                                            ? new Date(msg.timestamp).toLocaleTimeString([], {
                                                hour: "2-digit",
                                                minute: "2-digit",
                                            })
                                            : ""}
                                    </span>
                                </div>
                            )}

                            {msg.reply_to && (
                                <div
                                    className="reply-box"
                                >
                                    <div>
                                        <strong>{msg.reply_to.sender_name}:</strong>{" "}
                                        {msg.reply_to.content || "[archivo]"}
                                    </div>

                                    {msg.reply_to.attachment &&
                                        /\.(jpg|jpeg|png|gif|webp)$/i.test(msg.reply_to.attachment) && (
                                            <img
                                                src={msg.reply_to.attachment}
                                                alt="preview"
                                                style={{
                                                    maxHeight: "60px",
                                                    borderRadius: "4px",
                                                    objectFit: "cover",
                                                    maxWidth: "120px"
                                                }}
                                            />
                                        )}
                                </div>
                            )}

                            <p className="text">{msg.content}</p>

                            {msg.attachment && (
                                /\.(jpg|jpeg|png|gif|webp)$/i.test(msg.attachment) ? (
                                    <img
                                        src={msg.attachment}
                                        alt="attachment"
                                        className="chat-image-preview"
                                        style={{
                                            maxWidth: "100%",
                                            maxHeight: "200px",
                                            marginTop: "6px",
                                            borderRadius: "8px"
                                        }}
                                    />
                                ) : (
                                    <div style={{ display: "flex", alignItems: "center", gap: "10px", marginTop: "6px" }}>
                                        <a
                                            href={msg.attachment}
                                            download
                                            className="attachment-btn"
                                        >
                                            Descargar archivo
                                        </a>
                                        <span style={{ color: "#1e293b", fontSize: "0.8rem" }}>
                                            {msg.original_filename || fileName}
                                        </span>
                                    </div>
                                )
                            )}

                            {Object.keys(groupedReactions).length > 0 && (
                                <div className="reactions">
                                    {Object.entries(groupedReactions).map(([emoji, users]) => {
                                        const isMine = users.includes(currentUser);
                                        return (
                                            <button
                                                key={emoji}
                                                className={`reaction ${isMine ? "my-reaction" : ""}`}
                                                title={users.join(", ")}
                                                onClick={() => onReact({ ...msg, id: String(msg.id) }, emoji)}
                                            >
                                                {emoji} {users.length}
                                            </button>
                                        );
                                    })}
                                </div>
                            )}

                            <div className="message-actions">
                                <button
                                    className="reply-btn"
                                    onClick={() => onReply(msg)}
                                    title="Responder"
                                >
                                    <FaReply />
                                </button>
                            </div>

                            <div className="reaction-bar">
                                {REACTION_EMOJIS.map((emoji) => (
                                    <button
                                        key={emoji}
                                        className={`reaction-btn ${groupedReactions[emoji]?.includes(currentUser)
                                            ? "active"
                                            : ""
                                            }`}
                                        onClick={() => onReact({ ...msg, id: String(msg.id) }, emoji)}
                                    >
                                        {emoji}
                                    </button>
                                ))}
                            </div>
                        </div>
                    </div>
                );
            })}
            <div ref={endRef}></div>
        </div>
    );
}
