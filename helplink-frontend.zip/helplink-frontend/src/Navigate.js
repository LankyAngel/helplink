import { BrowserRouter, Routes, Route } from "react-router-dom";
import React from "react";
import Login from "./pages/Login";
import Home from "./pages/Home";
import Events from "./pages/Events";
import EventDetails from "./pages/EventDetails";
import Profile from "./pages/Profile";
import Messages from "./pages/ChatPage";
import Register from "./pages/Register";
import EditProfile from "./pages/EditProfile";
import OrganizationAdmin from "./pages/OrganizationAdmin";
import OrganizationStaff from "./pages/OrganizationStaff";
import AddOrganization from "./pages/AddOrganization";
import AddEvent from "./pages/AddEvent";
import { AddBranch } from "./pages/AddBranch";
import ShowEventsOrganization from "./pages/ShowEventsOrganization";
import OrganizationAdminPanel from "./pages/OrganizationAdminPanel";
import BranchAdminPanel from "./pages/BranchAdminPanel";
import AddFeedback from "./pages/AddFeedback";
import OrganizationProfile from "./pages/OrganizationProfile";
import OrganizationBranches from "./pages/OrganizationBranches";
import OrganizationEvents from "./pages/OrganizationEvents";
import OrganizationMembers from "./pages/OrganizationMembers";
import BranchMemberPanel from "./pages/BranchMemberPanel";
import AddOrganizationMember from "./pages/AddOrganizationMembers";
import AddBranchMembers from "./pages/AddBranchMembers";
import AddBranchEvent from "./pages/AddBranchEvent";
import AttendanceValidator from "./pages/AttendanceValidator";
import BranchMembers from "./pages/BranchMembers";
import BranchEvents from "./pages/BranchEvents";
import PasswordResetRequest from "./pages/PasswordResetRequest";
import PasswordResetConfirm from "./pages/PasswordResetConfirm";
import EditEvent from "./pages/EditEvent";

const Navigate = () => {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/home" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path="/events" element={<Events />} />
      <Route path="/events/:id" element={<EventDetails />} />
      <Route path="/organization/:id" element={<OrganizationProfile />} />
      <Route path="/profile" element={<Profile />} />
      <Route path="/editprofile" element={<EditProfile />} />
      <Route path="/messages" element={<Messages />} />
      <Route path="/register" element={<Register />} />
      <Route path="/organizationAdmin" element={<OrganizationAdmin />} />
      <Route path="/organizationStaff" element={<OrganizationStaff />} />
      <Route path="/addOrganization" element={<AddOrganization />} />
      <Route path="/addEvent" element={<AddEvent />} />
      <Route path="/addBranch" element={<AddBranch />} />
      <Route path="/addBranchEvent" element={<AddBranchEvent />} />
      <Route path="/addFeedback/:id" element={<AddFeedback />} />
      <Route path="/password-reset" element={<PasswordResetRequest />} />
      <Route path="/password-reset/confirm" element={<PasswordResetConfirm />} />

      <Route
        path="/showEventsOrganization"
        element={<ShowEventsOrganization />}
      />
      <Route
        path="/organizationAdminPanel"
        element={<OrganizationAdminPanel />}
      />
      <Route path="/branchAdminPanel" element={<BranchAdminPanel />} />
      <Route path="/branchMemberPanel" element={<BranchMemberPanel />} />
      <Route path="/branchMemberPanel/add" element={<AddBranchMembers />} />
      <Route
        path="/organizationAdminPanel/branches"
        element={<OrganizationBranches />}
      />
      <Route
        path="/organizationAdminPanel/members"
        element={<OrganizationMembers />}
      />
      <Route
        path="/branchAdminPanel/members"
        element={<BranchMembers />}
      />
      <Route
        path="/branchAdminPanel/events"
        element={<BranchEvents />}
      />
      <Route
        path="/organizationAdminPanel/members/add"
        element={<AddOrganizationMember />}
      />
      <Route
        path="/organizationAdminPanel/events"
        element={<OrganizationEvents />}
      />
      <Route
        path="/organizationAdminPanel/events/edit/:eventId"
        element={<EditEvent />}
      />
      <Route
        path="/attendanceEvents/:validationToken"
        element={<AttendanceValidator />}
      />
      <Route path="*" element={<h1>404 - Página no encontrada</h1>} />
    </Routes>
  );
};

export default Navigate;
