//src/firebase.js
import { initializeApp } from "firebase/app";
import { getMessaging } from "firebase/messaging";

const firebaseConfig = {
  apiKey: "AIzaSyCvHx_xzicdsYVFpuZXQlpp_osiOXTs8vI",
  authDomain: "helplink-d1358.firebaseapp.com",
  projectId: "helplink-d1358",
  storageBucket: "helplink-d1358.firebasestorage.app",
  messagingSenderId: "656549067468",
  appId: "1:656549067468:web:61560023ff775809e72069",
  measurementId: "G-3L87G0FHFB"
};

const app = initializeApp(firebaseConfig);
export const messaging = getMessaging(app);