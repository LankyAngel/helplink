// src/contex/AuthProvider.js
import React, { createContext, useContext, useReducer, useEffect } from "react";
import { login as apiLogin } from "../services/authService.js";

const AuthContext = createContext();

const initialState = {
  isAuthenticated: false,
  access: null,
  refresh: null,
  username: null,
  user_id: null,
  org_code: null,
  branch__id: null,
};

const authReducer = (state, action) => {
  switch (action.type) {
    case "LOGIN":
      return {
        isAuthenticated: true,
        access: action.payload.access,
        refresh: action.payload.refresh,
        username: action.payload.username,
        org_code: action.payload.org_code,
        user_id: action.payload.user_id,
        branch__id: action.payload.branch_roles?.branch__id,
      };
    case "LOGOUT":
      return initialState;
    default:
      return state;
  }
};

export const AuthProvider = ({ children }) => {
  const [state, dispatch] = useReducer(authReducer, initialState);

  // Cargar usuario desde localStorage al iniciar
  useEffect(() => {
    const access = localStorage.getItem("access");
    const refresh = localStorage.getItem("refresh");
    const username = localStorage.getItem("username");
    const org_code = localStorage.getItem("org_code");
    const user_id = localStorage.getItem("user_id");
    const branch__id = localStorage.getItem("branch__id");

    if (access && refresh && username && org_code && user_id && branch__id) {
      dispatch({
        type: "LOGIN",
        payload: {
          access,
          refresh,
          username,
          org_code: parseInt(org_code, 10),
          user_id: parseInt(user_id, 10),
          branch__id: parseInt(branch__id, 10),
        },
      });
    }
  }, []);

  const login = async (username, password) => {
    const response = await apiLogin(username, password);
    const {
      access,
      refresh,
      username: name,
      org_code,
      user_id,
      branch_roles,
    } = response.data;
    const branch__id =
      branch_roles.length > 0 ? branch_roles[0].branch__id : null;

    localStorage.setItem("access", access);
    localStorage.setItem("refresh", refresh);
    localStorage.setItem("username", name);
    localStorage.setItem("user_id", user_id);
    localStorage.setItem("org_code", org_code);
    localStorage.setItem("branch__id", branch__id);

    dispatch({
    type: "LOGIN",
    payload: {
      access,
      refresh,
      username: name,
      user_id,
      org_code,
      branch_roles: { branch__id: parseInt(branch__id, 10) },
    },
});

  };

  const logout = () => {
    localStorage.removeItem("access");
    localStorage.removeItem("refresh");
    localStorage.removeItem("username");
    localStorage.removeItem("org_code");
    localStorage.removeItem("user_id");
    localStorage.removeItem("branch__id");
    dispatch({ type: "LOGOUT" });
  };

  return (
    <AuthContext.Provider value={{ ...state, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
