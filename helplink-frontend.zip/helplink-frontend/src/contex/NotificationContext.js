import React, { createContext, useState, useContext, useCallback, useEffect, useRef } from 'react';
import { getToken, onMessage } from "firebase/messaging";
import { messaging } from '../firebase';
import axios from 'axios';

const NotificationContext = createContext();

//const userid = localStorage.getItem("user_id");
//const tokenAccess = localStorage.getItem("access_token");

export function NotificationProvider({ children }) {
  const [notifications, setNotifications] = useState([
    // Notificación inicial sin ruta, se mostrará pero no será navegable.
    //{ id: 1, title: '¡Notificaciones activadas!', body: 'Estás listo para recibir actualizaciones.' },
    //{ id: 1, title: '¡Notificaciones activadas!', body: 'Estas tienen ruta', path: '/Events/17' },
  ]);


  const addNotification = useCallback((notification) => {
    const newNotification = { id: Date.now(), ...notification };
    setNotifications(prev => {
      if (prev.some(n => n.title === newNotification.title && n.body === newNotification.body)) {
        return prev;
      }
      return [newNotification, ...prev];
    });
  }, []);

  const removeNotification = useCallback((id) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  }, []);

  const clearAllNotifications = useCallback(() => {
    setNotifications([]);
  }, []);

  const addNotificationRef = useRef(addNotification);
  useEffect(() => {
    addNotificationRef.current = addNotification;
  });

  useEffect(() => {
    // Mensajes en primer plano (app abierta)
    const unsubscribeOnMessage = onMessage(messaging, (payload) => {
      console.log('Notificación recibida en primer plano: ', payload);
      const newNotification = {
        ...payload.notification,
        ...payload.data,
      };
      addNotificationRef.current(newNotification);
    });

    const handleMessageFromSW = (event) => {
      if (event.data && event.data.type === 'new-notification') {
        console.log('Notificación recibida desde el Service Worker:', event.data.data);
        // Asumimos que el SW ya envía el objeto completo (title, body, path)
        addNotificationRef.current(event.data.data);
      }
    };
    navigator.serviceWorker.addEventListener('message', handleMessageFromSW);

    return () => {
      unsubscribeOnMessage();
      navigator.serviceWorker.removeEventListener('message', handleMessageFromSW);
    };
  }, []);


  const value = {
    notifications,
    addNotification,
    removeNotification,
    clearAllNotifications,
  };

  return (
    <NotificationContext.Provider value={value}>
      {children}
    </NotificationContext.Provider>
  );
}

export function useNotifications() {
  return useContext(NotificationContext);
}