// import React, { useState, useEffect } from "react";
// import "../assets/style/BranchAdminPanel.css";
// import { useAuth } from "../contex/AuthProvider";
// import { useNavigate } from "react-router-dom";
// import NavarCompleto from "../Components/NavarCompleto";
// import { getUserInfo } from "../services/authService";
// import {
//   FaUsers,
//   FaCalendarAlt,
//   FaUserCog,
//   FaPlus,
//   FaChartBar,
//   FaCog,
//   FaClipboardList,
//   FaChartLine,
//   FaBuilding,
//   FaEdit,
//   FaEye,
//   FaUserPlus,
//   FaMapMarkerAlt,
//   FaStar,
//   FaHandsHelping,
//   FaTasks,
//   FaCheckCircle,
//   FaClock,
//   FaExclamationTriangle,
// } from "react-icons/fa";
// import {
//   getAllUsers,
//   getAllEvents,
//   getVolunteerEvents,
//   getBranchMembers,
// } from "../services/api";

// const BranchAdminPanel = () => {
//   const [isLoaded, setIsLoaded] = useState(false);
//   const { isAuthenticated, branch__id, access } = useAuth();
//   const [loadingEvents, setLoadingEvents] = useState(true);
//   const navigate = useNavigate();
//   const [branchInfo, setBranchInfo] = useState(null);
//   const [userRole, setUserRole] = useState("branch_admin"); // branch_admin, branch_member
//   const [activeTab, setActiveTab] = useState("dashboard");
//   const apiURL = process.env.REACT_APP_API_URL;
//   const _apiURL = `${apiURL}/events/`;
//    const [eventosSucursal, setEventosSucursal] = useState([]);

//   // Estado para almacenar las estadísticas de la sucursal
//   const [branchStats, setBranchStats] = useState({
//     branchEvents: 0,
//     branchMembers: 0,
//     activeParticipations: 0,
//     completedEvents: 0,
//     pendingTasks: 0,
//     branchRating: 4.6,
//   });

//   // Estado para datos detallados
//   const [recentEvents, setRecentEvents] = useState([]);
//   const [branchMembers, setBranchMembers] = useState([]);
//   const [upcomingTasks, setUpcomingTasks] = useState([]);

//   useEffect(() => {
//   const fetchEventos = async () => {
//     try {
//       const res = await fetch(`${_apiURL}`, {
//         headers: {
//           Authorization: `Bearer ${access}`,
//         },
//       });

//       if (!res.ok) throw new Error("Error al obtener eventos");

//       const data = await res.json();

//       // Filtrar por branch específico
//       const eventosSucursal = data.filter(
//         (evento) => evento?.branch === branch__id
//       );

//       console.log("Eventos filtrados por branch:", eventosSucursal); // 👈 Aquí el log

//       setEventosSucursal(eventosSucursal);
//     } catch (error) {
//       console.error("Error al cargar eventos:", error);
//     }
//   };
//   fetchEventos();
// }, []);



//   // useEffect(() => {
//   //   const fetchEvents = async () => {
//   //     try {
//   //       const res = await fetch(`${_apiURL}?branch=${branch__id}`, {
//   //         headers: {
//   //           Authorization: `Bearer ${access}`,
//   //         },
//   //       });

//   //       if (!res.ok) {
//   //         throw new Error("No se pudieron obtener los eventos");
//   //       }

//   //       const data = await res.json();
//   //       setRecentEvents(data);
//   //     } catch (error) {
//   //       console.error("Error cargando eventos:", error);
//   //       setRecentEvents([]);
//   //     } finally {
//   //       setLoadingEvents(false);
//   //     }
//   //   };

//   //   if (isAuthenticated && branch__id && access) {
//   //     fetchEvents();
//   //   }
//   // }, [isAuthenticated, branch__id, access]);


//   // Función para obtener información de la sucursal y estadísticas
// const fetchBranchData = async () => {
//   try {
//     const currentUser = await getUserInfo();

//     if (currentUser && currentUser.branch) {
//       setBranchInfo(currentUser.branch);
//     }

//     const [branchMembersData, volunteerEventsData] = await Promise.all([
//       getBranchMembers(currentUser.branch?.id),
//       getVolunteerEvents(),
//     ]);

//     const activeBranchEvents =
//       branchMembersData?.filter((event) => event.status === "published")
//         .length || 0;

//     const branchMembersCount = branchMembersData?.length || 0;

//     const activeParticipationsCount =
//       volunteerEventsData?.filter((ve) =>
//         branchMembersData?.some((be) => be.id === ve.event_id)
//       ).length || 0;

//     const completedEventsCount =
//       branchMembersData?.filter((event) => event.status === "completed")
//         .length || 0;

//     setBranchStats({
//       branchEvents: activeBranchEvents,
//       branchMembers: branchMembersCount,
//       activeParticipations: activeParticipationsCount,
//       completedEvents: completedEventsCount,
//       pendingTasks: Math.floor(Math.random() * 5) + 2, // Puedes quitar esto si no lo usas
//       branchRating: 4.6,
//     });

//     const recentBranchEvents =
//       branchMembersData
//         ?.sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
//         .slice(0, 5) || [];

//     setRecentEvents(recentBranchEvents);
//     setBranchMembers(branchMembersData?.slice(0, 6) || []);

//     // ✅ Aquí se reemplaza la simulación de tareas por eventos reales "próximos"
//     const upcomingEvents = branchMembersData
//       ?.filter((event) => {
//         const eventDate = new Date(event.date);
//         const now = new Date();
//         return eventDate > now && event.status === "published";
//       })
//       .sort((a, b) => new Date(a.date) - new Date(b.date)) // ordena por fecha más próxima
//       .slice(0, 5); // limitar a los 5 más próximos

//     setUpcomingTasks(upcomingEvents);
//   } catch (error) {
//     console.error("Error al cargar los datos de la sucursal:", error);
//   }
// };


//   useEffect(() => {
//     setIsLoaded(true);
//     fetchBranchData();

//     // Determinar rol del usuario (simulado)
//     const role = localStorage.getItem("user_role") || "branch_admin";
//     setUserRole(role);
//   }, []);

//   // Navegación
//   const goCreateEvent = () => navigate("/addBranchEvent");
//   const goManageMembers = () => navigate("/branchMemberPanel");
//   const goManageEvents = () => navigate("/");
//   const goAddMember = () => navigate("/branchMemberPanel/add");
//   const goEventDetails = (eventId) => navigate(`/event/${eventId}`);

//   // Verificar permisos
//   const canManage = userRole === "branch_admin";

//   const renderDashboard = () => (
//     <div className="branch-dashboard">
//       {/* Estadísticas principales */}
//       <div className="branch-stats-grid">
//         <div className="branch-stat-card primary">
//           <div className="stat-icon">
//             <FaCalendarAlt />
//           </div>
//           <div className="stat-content">
//             <div className="stat-number">{branchStats.branchEvents}</div>
//             <div className="stat-label">Eventos Activos</div>
//             <div className="stat-change">
//               +{Math.floor(Math.random() * 5) + 1} este mes
//             </div>
//           </div>
//         </div>

//         <div className="branch-stat-card secondary">
//           <div className="stat-icon">
//             <FaUsers />
//           </div>
//           <div className="stat-content">
//             <div className="stat-number">{branchStats.branchMembers}</div>
//             <div className="stat-label">Miembros</div>
//             <div className="stat-change">
//               +{Math.floor(Math.random() * 3) + 1} nuevos
//             </div>
//           </div>
//         </div>

//         <div className="branch-stat-card success">
//           <div className="stat-icon">
//             <FaHandsHelping />
//           </div>
//           <div className="stat-content">
//             <div className="stat-number">
//               {branchStats.activeParticipations}
//             </div>
//             <div className="stat-label">Participaciones</div>
//             <div className="stat-change">
//               +{Math.floor(Math.random() * 8) + 2} activas
//             </div>
//           </div>
//         </div>
//       </div>

//       {/* Acciones rápidas - Solo para administradores */}
//       {canManage && (
//         <div className="quick-actions-section">
//           <h3>Acciones Rápidas</h3>
//           <div className="quick-actions-grid">
//             <button
//               className="quick-action-btn primary"
//               onClick={goCreateEvent}
//             >
//               <FaPlus />
//               <span>Crear Evento</span>
//             </button>
//             <button
//               className="quick-action-btn secondary"
//               onClick={goAddMember}
//             >
//               <FaUserPlus />
//               <span>Agregar Miembro</span>
//             </button>
//             {/* <button
//               className="quick-action-btn tertiary"
//               onClick={goManageEvents}
//             >
//               <FaClipboardList />
//               <span>Gestionar Eventos</span>
//             </button> */}
//             {/* <button
//               className="quick-action-btn tertiary"
//               onClick={goManageMembers}
//             >
//               <FaUsers />
//               <span>Ver Miembros</span>
//             </button> */}
//           </div>
//         </div>
//       )}

//       {/* Contenido en grid */}
//       <div className="branch-content-grid">
//         {/* Eventos recientes */}
//         <div className="content-card">
//           <div className="card-header">
//             <h3>Eventos de la Sucursal</h3>
//             {canManage && (
//               <button className="header-action" onClick={goManageEvents}>
//                 Ver todos
//               </button>
//             )}
//           </div>
//         <div className="events-container">
//           {recentEvents.length > 0 ? (
//             recentEvents.map((event, index) => (
//               <button
//                 key={event.id}
//                 className="event-card"
//                 onClick={() => goEventDetails(event.id)}
//               >
//                 <div className="event-header">
//                   <h4>{event.title}</h4>
//                   <span className={`event-status ${event.status}`}>
//                     {event.status === "published"
//                       ? "Activo"
//                       : event.status === "completed"
//                       ? "Completado"
//                       : "Borrador"}
//                   </span>
//                 </div>
//                 <p className="event-description">{event.description}</p>
//                 <div className="event-meta">
//                   <span className="event-date">
//                     <FaClock /> {event.event_date} {event.start_time}
//                   </span>
//                   <span className="event-participants">
//                     <FaUsers /> {event.title} participantes
//                   </span>
//                 </div>
//               </button>
//             ))
//           ) : (
//             <div className="empty-state">
//               <FaCalendarAlt />
//               <p>No hay eventos creados aún</p>
//               {canManage && (
//                 <button className="create-first-btn" onClick={goCreateEvent}>
//                   Crear primer evento
//                 </button>
//               )}
//             </div>
//           )}
//         </div>

//         </div>

//         {/* Miembros de la sucursal */}
//         <div className="content-card">
//           <div className="card-header">
//             <h3>Miembros de la Sucursal</h3>
//             {canManage && (
//               <button className="header-action" onClick={goManageMembers}>
//                 Ver todos
//               </button>
//             )}
//           </div>
//           <div className="members-container">
//             {branchMembers.length > 0 ? (
//               branchMembers.map((member, index) => (
//                 <div key={index} className="member-card">
//                   <div className="member-avatar">
//                     <img
//                       src={
//                         member.avatar ||
//                         `https://ui-avatars.com/api/?name=${member.name || `Miembro ${index + 1}`}&background=2563eb&color=fff`
//                       }
//                       alt={member.name || `Miembro ${index + 1}`}
//                     />
//                   </div>
//                   <div className="member-info">
//                     <h4>{member.name || `Miembro ${index + 1}`}</h4>
//                     <p>{member.role || "Miembro"}</p>
//                     <span className="member-status active">Activo</span>
//                   </div>
//                 </div>
//               ))
//             ) : (
//               <div className="empty-state">
//                 <FaUsers />
//                 <p>No hay miembros registrados</p>
//                 {canManage && (
//                   <button className="create-first-btn" onClick={goAddMember}>
//                     Agregar primer miembro
//                   </button>
//                 )}
//               </div>
//             )}
//           </div>
//         </div>
//       </div>
//     </div>
//   );

//   const renderManagement = () => (
//     <div className="branch-management">
//       {!canManage ? (
//         <div className="no-permission">
//           <FaExclamationTriangle />
//           <h3>Acceso Restringido</h3>
//           <p>
//             Solo los administradores de sucursal pueden acceder a estas
//             funciones.
//           </p>
//         </div>
//       ) : (
//         <div className="management-sections">
//           <button className="management-card" onClick={goManageEvents}>
//             <div className="management-icon">
//               <FaCalendarAlt />
//             </div>
//             <div className="management-content">
//               <h3>Gestionar Eventos</h3>
//               <p>Crear, editar y administrar eventos de la sucursal</p>
//               <span className="management-stat">
//                 {branchStats.branchEvents} eventos activos
//               </span>
//             </div>
//           </button>

//           <button className="management-card" onClick={goManageMembers}>
//             <div className="management-icon">
//               <FaUsers />
//             </div>
//             <div className="management-content">
//               <h3>Gestionar Miembros</h3>
//               <p>Administrar miembros y permisos de la sucursal</p>
//               <span className="management-stat">
//                 {branchStats.branchMembers} miembros activos
//               </span>
//             </div>
//           </button>

//           <div className="management-card">
//             <div className="management-icon">
//               <FaChartBar />
//             </div>
//             <div className="management-content">
//               <h3>Reportes y Métricas</h3>
//               <p>Ver estadísticas y generar reportes de la sucursal</p>
//               <span className="management-stat">
//                 Rating: {branchStats.branchRating} ⭐
//               </span>
//             </div>
//           </div>

//           <div className="management-card">
//             <div className="management-icon">
//               <FaCog />
//             </div>
//             <div className="management-content">
//               <h3>Configuración</h3>
//               <p>Ajustar configuraciones de la sucursal</p>
//               <span className="management-stat">Personalizar sucursal</span>
//             </div>
//           </div>
//         </div>
//       )}
//     </div>
//   );

//   return (
//     <div className="branch-admin-container">
//       {/* Elementos decorativos */}
//       <div className="bg-decoration">
//         <div className="floating-shape shape-1"></div>
//         <div className="floating-shape shape-2"></div>
//         <div className="floating-shape shape-3"></div>
//       </div>

//       <NavarCompleto login={true} />

//       <div className={`branch-panel ${isLoaded ? "loaded" : ""}`}>
//         {/* Header de la sucursal */}
//         <div className="branch-header">
//           <div className="branch-info-section">
//             <div className="branch-badge">
//               <FaBuilding />
//               <span>
//                 {canManage
//                   ? "Administrador de Sucursal"
//                   : "Miembro de Sucursal"}
//               </span>
//             </div>
//             <h1>
//               <span className="text-primary">
//                 {branchInfo?.name || "Mi Sucursal"}
//               </span>
//             </h1>
//             <div className="branch-details">
//               <span className="branch-location">
//                 <FaMapMarkerAlt />
//                 {branchInfo?.location || "Ubicación de la sucursal"}
//               </span>
//               <span className="branch-rating">
//                 <FaStar />
//                 {branchStats.branchRating} Rating
//               </span>
//             </div>
//           </div>
//         </div>

//         {/* Navegación */}
//         <div className="branch-nav">
//           <button
//             className={`branch-nav-tab ${activeTab === "dashboard" ? "active" : ""}`}
//             onClick={() => setActiveTab("dashboard")}
//           >
//             <FaChartBar />
//             <span>Panel Principal</span>
//           </button>
//           <button
//             className={`branch-nav-tab ${activeTab === "management" ? "active" : ""} ${!canManage ? "disabled" : ""}`}
//             onClick={() => canManage && setActiveTab("management")}
//           >
//             <FaCog />
//             <span>Gestión</span>
//             {!canManage && (
//               <span className="restricted-badge">Restringido</span>
//             )}
//           </button>
//         </div>

//         {/* Contenido */}
//         <div className="branch-content">
//           {activeTab === "dashboard" && renderDashboard()}
//           {activeTab === "management" && renderManagement()}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default BranchAdminPanel;

import React, { useState, useEffect } from "react";
import "../assets/style/BranchAdminPanel.css";
import { useAuth } from "../contex/AuthProvider";
import { useNavigate } from "react-router-dom";
import NavarCompleto from "../Components/NavarCompleto";
import {
  FaUsers,
  FaCalendarAlt,
  FaUserCog,
  FaPlus,
  FaChartBar,
  FaCog,
  FaClipboardList,
  FaChartLine,
  FaBuilding,
  FaEdit,
  FaEye,
  FaUserPlus,
  FaMapMarkerAlt,
  FaStar,
  FaHandsHelping,
  FaTasks,
  FaCheckCircle,
  FaClock,
  FaExclamationTriangle,
} from "react-icons/fa";
import { getBranchDashboard } from "../services/api";

const BranchAdminPanel = () => {
  const [isLoaded, setIsLoaded] = useState(false);
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [branchInfo, setBranchInfo] = useState(null);
  const [userRole, setUserRole] = useState("branch_admin");
  const [activeTab, setActiveTab] = useState("dashboard");

  const [branchStats, setBranchStats] = useState({
    branchEvents: 0,
    branchMembers: 0,
    activeParticipations: 0,
    completedEvents: 0,
    pendingTasks: 0,
    branchRating: 4.6,
  });

  const [recentEvents, setRecentEvents] = useState([]);
  const [branchMembers, setBranchMembers] = useState([]);
  const [upcomingTasks, setUpcomingTasks] = useState([]);

  const fetchBranchData = async () => {
    try {
      const dashboardData = await getBranchDashboard();

      if (!dashboardData) return;

      // Info de la sucursal
      setBranchInfo({
        name: dashboardData.branch.name,
        location: `${dashboardData.location.address}, ${dashboardData.location.city} ${dashboardData.location.zip_code}`,
      });

      // Estadísticas
      setBranchStats({
        branchEvents: dashboardData.events.filter(e => e.status === "published").length,
        branchMembers: dashboardData.members.length,
        activeParticipations: dashboardData.total_event_participants,
        completedEvents: dashboardData.events.filter(e => e.status === "completed").length,
        branchRating: 4.6,
      });

      // Datos para las listas
      setRecentEvents(dashboardData.events.slice(0, 5));
      setBranchMembers(dashboardData.members.slice(0, 6));

      // Tareas próximas (eventos futuros publicados)
      const upcomingEvents = dashboardData.events
        .filter(event => new Date(event.date) > new Date() && event.status === "published")
        .sort((a, b) => new Date(a.date) - new Date(b.date))
        .slice(0, 5);

      setUpcomingTasks(upcomingEvents);

    } catch (error) {
      console.error("Error al cargar datos del branch dashboard:", error);
    } finally {
      setIsLoaded(true);
    }
  };

  useEffect(() => {
    fetchBranchData();
    const role = localStorage.getItem("user_role") || "branch_admin";
    setUserRole(role);
  }, []);

  // Navegación
  const goCreateEvent = () => navigate("/addBranchEvent");
  const goManageMembers = () => navigate("/branchAdminPanel/members");
  const goManageEvents = () => navigate("/branchAdminPanel/events");
  const goAddMember = () => navigate("/branchMemberPanel/add");
  const goEventDetails = (eventId) => navigate(`/event/${eventId}`);

  const canManage = userRole === "branch_admin";

  const renderDashboard = () => (
    <div className="branch-dashboard">
      {/* Estadísticas */}
      <div className="branch-stats-grid">
        <div className="branch-stat-card primary">
          <div className="stat-icon"><FaCalendarAlt /></div>
          <div className="stat-content">
            <div className="stat-number">{branchStats.branchEvents}</div>
            <div className="stat-label">Eventos Activos</div>
          </div>
        </div>
        <div className="branch-stat-card secondary">
          <div className="stat-icon"><FaUsers /></div>
          <div className="stat-content">
            <div className="stat-number">{branchStats.branchMembers}</div>
            <div className="stat-label">Miembros</div>
          </div>
        </div>
        <div className="branch-stat-card success">
          <div className="stat-icon"><FaHandsHelping /></div>
          <div className="stat-content">
            <div className="stat-number">{branchStats.activeParticipations}</div>
            <div className="stat-label">Participaciones</div>
          </div>
        </div>
      </div>

      {/* Acciones rápidas */}
      {canManage && (
        <div className="quick-actions-section">
          <h3>Acciones Rápidas</h3>
          <div className="quick-actions-grid">
            <button className="quick-action-btn primary" onClick={goCreateEvent}>
              <FaPlus /><span>Crear Evento</span>
            </button>
            <button className="quick-action-btn secondary" onClick={goAddMember}>
              <FaUserPlus /><span>Agregar Miembro</span>
            </button>
          </div>
        </div>
      )}

      {/* Grid de contenido */}
      <div className="branch-content-grid">
        {/* Eventos recientes */}
        <div className="content-card">
          <div className="card-header">
            <h3>Eventos de la Sucursal</h3>
            {canManage && <button className="header-action" onClick={goManageEvents}>Ver todos</button>}
          </div>
          <div className="events-container">
            {recentEvents.length > 0 ? (
              recentEvents.map(event => (
                <button key={event.id} className="event-card" onClick={() => goEventDetails(event.id)}>
                  <div className="event-header">
                    <h4>{event.title}</h4>
                    <span className={`event-status ${event.status}`}>
                      {event.status === "finished" ? "Finalizado" : event.status === "progress" ? "En proceso" : event.status === "pending" ? "Pendiente" : event.status === "canceled" ? "Cancelado" : event.status === "published" ? "Publicado" : ""}
                    </span>
                  </div>
                  <p className="event-description">{event.description}</p>
                  <div className="event-meta">
                    <span className="event-date"><FaClock /> {event.event_date} {event.start_time}</span>
                    <span className="event-participants"><FaUsers /> {event.participants?.length || 0} participantes</span>
                  </div>
                </button>
              ))
            ) : (
              <div className="empty-state">
                <FaCalendarAlt />
                <p>No hay eventos creados aún</p>
                {canManage && <button className="create-first-btn" onClick={goCreateEvent}>Crear primer evento</button>}
              </div>
            )}
          </div>
        </div>

        {/* Miembros */}
        <div className="content-card">
          <div className="card-header">
            <h3>Miembros de la Sucursal</h3>
            {canManage && <button className="header-action" onClick={goManageMembers}>Ver todos</button>}
          </div>
          <div className="members-container">
            {branchMembers.length > 0 ? (
              branchMembers.map((member, index) => (
                <div key={index} className="member-card">
                  <div className="member-avatar">
                    <img
                      src={member.avatar || `https://ui-avatars.com/api/?name=${member.name}&background=2563eb&color=fff`}
                      alt={member.name}
                    />
                  </div>
                  <div className="member-info">
                    <h4>{member.name}</h4>
                    <p>{member.role || "Miembro"}</p>
                    <span className="member-status active">Activo</span>
                  </div>
                </div>
              ))
            ) : (
              <div className="empty-state">
                <FaUsers /><p>No hay miembros registrados</p>
                {canManage && <button className="create-first-btn" onClick={goAddMember}>Agregar primer miembro</button>}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );

  const renderManagement = () => (
    <div className="branch-management">
      {!canManage ? (
        <div className="no-permission">
          <FaExclamationTriangle />
          <h3>Acceso Restringido</h3>
          <p>Solo los administradores de sucursal pueden acceder a estas funciones.</p>
        </div>
      ) : (
        <div className="management-sections">
          <button className="management-card" onClick={goManageEvents}>
            <div className="management-icon"><FaCalendarAlt /></div>
            <div className="management-content">
              <h3>Gestionar Eventos</h3>
              <p>Crear, editar y administrar eventos de la sucursal</p>
              <span className="management-stat">{branchStats.branchEvents} eventos activos</span>
            </div>
          </button>
          <button className="management-card" onClick={goManageMembers}>
            <div className="management-icon"><FaUsers /></div>
            <div className="management-content">
              <h3>Gestionar Miembros</h3>
              <p>Administrar miembros y permisos de la sucursal</p>
              <span className="management-stat">{branchStats.branchMembers} miembros activos</span>
            </div>
          </button>
        </div>
      )}
    </div>
  );

  return (
    <div className="branch-admin-container">
      <div className="bg-decoration">
        <div className="floating-shape shape-1"></div>
        <div className="floating-shape shape-2"></div>
        <div className="floating-shape shape-3"></div>
      </div>
      <NavarCompleto login={true} />
      <div className={`branch-panel ${isLoaded ? "loaded" : ""}`}>
        <div className="branch-header">
          <div className="branch-info-section">
            <div className="branch-badge">
              <FaBuilding />
              <span>{canManage ? "Administrador de Sucursal" : "Miembro de Sucursal"}</span>
            </div>
            <h1><span className="text-primary">{branchInfo?.name || "Mi Sucursal"}</span></h1>
            <div className="branch-details">
              <span className="branch-location"><FaMapMarkerAlt />{branchInfo?.location || "Ubicación de la sucursal"}</span>
              <span className="branch-rating"><FaStar />{branchStats.branchRating} Rating</span>
            </div>
          </div>
        </div>
        <div className="branch-nav">
          <button className={`branch-nav-tab ${activeTab === "dashboard" ? "active" : ""}`} onClick={() => setActiveTab("dashboard")}>
            <FaChartBar /><span>Panel Principal</span>
          </button>
          <button className={`branch-nav-tab ${activeTab === "management" ? "active" : ""} ${!canManage ? "disabled" : ""}`} onClick={() => canManage && setActiveTab("management")}>
            <FaCog /><span>Gestión</span>{!canManage && <span className="restricted-badge">Restringido</span>}
          </button>
        </div>
        <div className="branch-content">
          {activeTab === "dashboard" && renderDashboard()}
          {activeTab === "management" && renderManagement()}
        </div>
      </div>
    </div>
  );
};

export default BranchAdminPanel;
