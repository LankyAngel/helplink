import React, { useState, useEffect } from "react";
import { FaLock, FaExclamationTriangle, FaEye, FaEyeSlash } from "react-icons/fa";
import "../assets/style/Login.css";
import NavarCompleto from "../Components/NavarCompleto";
import { useNavigate } from "react-router-dom";

const PasswordResetConfirm = () => {
    const navigate = useNavigate();
    const [token, setToken] = useState("");
    const [formData, setFormData] = useState({
        password: "",
        re_password: "",
    });

    const [showPassword, setShowPassword] = useState(false);
    const [showConfirmPassword, setShowConfirmPassword] = useState(false);
    const [passwordTouched, setPasswordTouched] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [errorMsg, setErrorMsg] = useState("");
    const [successMsg, setSuccessMsg] = useState("");

    const passwordRequirements = [
        { label: "Mínimo 8 caracteres", test: (pw) => pw.length >= 8 },
        { label: "Una mayúscula", test: (pw) => /[A-Z]/.test(pw) },
        { label: "Una minúscula", test: (pw) => /[a-z]/.test(pw) },
        { label: "Un número", test: (pw) => /[0-9]/.test(pw) },
        { label: "Un símbolo", test: (pw) => /[^A-Za-z0-9]/.test(pw) },
    ];

    useEffect(() => {
        const params = new URLSearchParams(window.location.search);
        const t = params.get("token");
        if (!t) {
            setErrorMsg("Token no válido o ausente.");
        } else {
            setToken(t);
        }
    }, []);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData((prev) => ({
            ...prev,
            [name]: value,
        }));

        if (name === "password") setPasswordTouched(true);
        if (errorMsg) setErrorMsg("");
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (formData.password !== formData.re_password) {
            setErrorMsg("Las contraseñas no coinciden.");
            return;
        }

        setIsSubmitting(true);
        setErrorMsg("");
        setSuccessMsg("");

        try {
            const response = await fetch(`${process.env.REACT_APP_API_URL}/password_reset/confirm/`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({
                    token: token,
                    password: formData.password,
                }),
            });

            if (!response.ok) throw new Error("Token inválido o expirado.");

            setSuccessMsg("Contraseña restablecida correctamente. Serás redirigido...");
            setTimeout(() => navigate("/login"), 3000);
        } catch (err) {
            console.error("Error:", err.message);
            setErrorMsg("No se pudo cambiar la contraseña. Verifica el token o intenta de nuevo.");
        } finally {
            setIsSubmitting(false);
        }
    };

    return (
        <>
            <NavarCompleto />
            <div className="login-container">
                <div className="background-decorations">
                    <div className="decoration decoration-1"></div>
                    <div className="decoration decoration-2"></div>
                    <div className="decoration decoration-3"></div>
                </div>

                <div className="login-wrapper">
                    <div className="login-card">
                        <div className="login-header">
                            <div className="avatar-container">
                                <FaLock className="avatar-icon" />
                            </div>
                            <h1 className="login-title">Establecer nueva contraseña</h1>
                            <p className="login-subtitle">Escribe tu nueva contraseña</p>
                        </div>

                        <form className="login-form" onSubmit={handleSubmit}>
                            {errorMsg && (
                                <div className="error-container">
                                    <div className="error-icon">
                                        <FaExclamationTriangle className="error-icon-svg" />
                                    </div>
                                    <p className="error-message">{errorMsg}</p>
                                </div>
                            )}

                            {successMsg && (
                                <div className="success-container">
                                    <p className="success-message">{successMsg}</p>
                                </div>
                            )}

                            {/* Nueva contraseña */}
                            <div className="input-group">
                                <div className="input-icon">
                                    <FaLock className="icon" />
                                </div>
                                <input
                                    type={showPassword ? "text" : "password"}
                                    name="password"
                                    placeholder="Nueva contraseña"
                                    className="form-input password-input"
                                    value={formData.password}
                                    onChange={handleInputChange}
                                    onFocus={() => setPasswordTouched(true)}
                                    required
                                />
                                <button
                                    type="button"
                                    onClick={() => setShowPassword(!showPassword)}
                                    className="password-toggle"
                                >
                                    {showPassword ? <FaEyeSlash className="toggle-icon" /> : <FaEye className="toggle-icon" />}
                                </button>
                            </div>

                            {passwordTouched && (
                                <div className="text-sm text-gray-700 mb-3 mt-2 space-y-1">
                                    {passwordRequirements.map((req, idx) => {
                                        const passed = req.test(formData.password);
                                        return (
                                            <p key={idx} className={`flex items-center gap-2 ${passed ? "text-green-600" : "text-red-500"}`}>
                                                {passed ? "✔" : "✖"} {req.label}
                                            </p>
                                        );
                                    })}
                                </div>
                            )}

                            {/* Confirmar contraseña */}
                            <div className="input-group mt-3">
                                <div className="input-icon">
                                    <FaLock className="icon" />
                                </div>
                                <input
                                    type={showConfirmPassword ? "text" : "password"}
                                    name="re_password"
                                    placeholder="Confirmar contraseña"
                                    className={`form-input password-input ${formData.re_password && formData.password !== formData.re_password ? "ring-2 ring-red-500" : ""
                                        }`}
                                    value={formData.re_password}
                                    onChange={handleInputChange}
                                    required
                                />
                                <button
                                    type="button"
                                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                                    className="password-toggle"
                                >
                                    {showConfirmPassword ? <FaEyeSlash className="toggle-icon" /> : <FaEye className="toggle-icon" />}
                                </button>
                            </div>

                            {formData.re_password && formData.password !== formData.re_password && (
                                <p className="text-sm text-red-500 mt-1">Las contraseñas no coinciden.</p>
                            )}

                            <button type="submit" disabled={isSubmitting} className="submit-button mt-4">
                                {isSubmitting ? (
                                    <div className="loading-container">
                                        <div className="spinner"></div>
                                        Guardando...
                                    </div>
                                ) : (
                                    "Cambiar contraseña"
                                )}
                            </button>
                        </form>

                        <div className="form-options" style={{ justifyContent: "center", marginTop: "1rem" }}>
                            <a href="/login" className="forgot-password">Volver al inicio de sesión</a>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default PasswordResetConfirm;
