import React, { useState, useEffect } from "react";
import "../assets/style/Home.css";
import Header from "../Components/Header";
import Events from "./Events";
import { useAuth } from "../contex/AuthProvider";
import { useNavigate } from "react-router-dom";
import NavarCompleto from "../Components/NavarCompleto";
import {
  FaHeart,
  FaUsers,
  FaHandsHelping,
  FaArrowRight,
  FaCalendarAlt,
} from "react-icons/fa";

const Home = () => {
  const [showHeader, setShowHeader] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();

  // Efecto para la animación inicial
  useEffect(() => {
    setIsLoaded(true);
  }, []);

  //Este putHeader pone los iconos en el navar
  //Para cuando este logeado
  //Idea en proceso
  const putHeader = (e) => {
    e.preventDefault(); // Previene el salto de ancla
    setShowHeader(true);
  };

  //Redirecciona al Login
  const goLogin = (e) => {
    e.preventDefault(); // Previene el comportamiento por defecto del enlace
    navigate("/login"); // Navega a la ruta /login
  };

  const goEvents = (e) => {
    e.preventDefault(); // Previene el comportamiento por defecto del enlace
    navigate("/events"); // Navega a la ruta /login
  };

  return (
    <div className="home-container">
      {/* Elementos decorativos de fondo */}
      <div className="bg-decoration">
        <div className="floating-shape shape-1"></div>
        <div className="floating-shape shape-2"></div>
        <div className="floating-shape shape-3"></div>
      </div>

      <NavarCompleto />

      <main className={`home-main ${isLoaded ? "loaded" : ""}`}>
        <div className="content-section">
          <div className="content-wrapper">
            <div className="badge">
              <FaHeart />
              <span>Únete al cambio</span>
            </div>

            <h1>
              <span className="text-primary">Conecta</span>
              <span className="text-gradient">con tu</span>
              <span className="text-highlight">Comunidad</span>
            </h1>

            <p className="description">
              Descubre eventos de voluntariado cerca de ti y contribuye a
              <span className="highlight-text"> hacer la diferencia</span> en tu
              comunidad. Cada acción cuenta, cada momento importa.
            </p>

            <div className="cta-section">
              {!isAuthenticated && (
                <button className="btn-primary" onClick={goLogin}>
                  <span>Comenzar a Ayudar</span>
                  <div className="btn-glow"></div>
                </button>
              )}
              <button className="btn-secondary" onClick={goEvents}>
                <FaCalendarAlt />
                <span>Ver Eventos</span>
              </button>
            </div>

            <div className="impact-stats">
              <div className="stat-item">
                <div className="stat-number">500+</div>
                <div className="stat-label">Voluntarios</div>
              </div>
              <div className="stat-item">
                <div className="stat-number">150+</div>
                <div className="stat-label">Eventos</div>
              </div>
              <div className="stat-item">
                <div className="stat-number">50+</div>
                <div className="stat-label">Comunidades</div>
              </div>
            </div>

            <div className="features-preview">
              <div className="feature-item">
                <div className="feature-icon">
                  <FaUsers />
                </div>
                <span>Conecta</span>
              </div>
              <div className="feature-item">
                <div className="feature-icon">
                  <FaHandsHelping />
                </div>
                <span>Colabora</span>
              </div>
              <div className="feature-item">
                <div className="feature-icon">
                  <FaHeart />
                </div>
                <span>Impacta</span>
              </div>
            </div>
          </div>
        </div>

        <div className="image-section">
          <div className="image-wrapper">
            <div className="image-glow"></div>
            <img
              src="/ImagenHome.jpg"
              alt="Voluntarios ayudando en la comunidad"
              className="hero-image"
            />
            <div className="image-overlay"></div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Home;
