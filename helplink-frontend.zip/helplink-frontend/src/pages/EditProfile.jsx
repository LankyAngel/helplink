import React, { useState, useEffect } from "react";
import { FaUser, FaSave, FaTimes, FaEdit, FaEnvelope, FaPhone, FaUserTag } from "react-icons/fa";
import "../assets/style/EditProfile.css";
import NavarCompleto from "../Components/NavarCompleto";
import { useAuth } from '../contex/AuthProvider';
import { getUserInfo, putUser } from "../services/authService";
import { useNavigate } from "react-router-dom";

const EditProfile = () => {
    const { isAuthenticated } = useAuth();
    const navigate = useNavigate();
    
    const [formData, setFormData] = useState({
        email: '',
        first_name: '',
        last_name: '',
        phone_number: '',
        username: ''
    });
    
    const [originalData, setOriginalData] = useState({});
    const [loading, setLoading] = useState(true);
    const [saving, setSaving] = useState(false);
    const [errors, setErrors] = useState({});

    useEffect(() => {
        const fetchProfile = async () => {
            try {
                const data = await getUserInfo();
                const user = data.find(u => u.username === localStorage.getItem('username'));
                if (user) {
                    const userData = {
                        email: user.email || '',
                        first_name: user.first_name || '',
                        last_name: user.last_name || '',
                        phone_number: user.phone_number || '',
                        username: user.username || ''
                    };
                    setFormData(userData);
                    setOriginalData(userData);
                }
            } catch (error) {
                console.error('Error fetching profile:', error);
            } finally {
                setLoading(false);
            }
        };
        
        fetchProfile();
    }, [isAuthenticated, navigate]);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        
        // Para el número de teléfono, solo permitir dígitos
        if (name === 'phone_number') {
            const digitsOnly = value.replace(/\D/g, '');
            setFormData(prev => ({
                ...prev,
                [name]: digitsOnly
            }));
        } else {
            setFormData(prev => ({
                ...prev,
                [name]: value
            }));
        }
        
        if (errors[name]) {
            setErrors(prev => ({
                ...prev,
                [name]: ''
            }));
        }
    };

    const validateForm = () => {
        const newErrors = {};
        
        if (!formData.email.trim()) {
            newErrors.email = 'El email es requerido';
        } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
            newErrors.email = 'El email no es válido';
        }
        
        if (!formData.first_name.trim()) {
            newErrors.first_name = 'El nombre es requerido';
        }
        
        if (!formData.last_name.trim()) {
            newErrors.last_name = 'El apellido es requerido';
        }
        
        if (!formData.username.trim()) {
            newErrors.username = 'El nombre de usuario es requerido';
        }
        
        // Validación del número de teléfono: exactamente 10 dígitos si se proporciona
        if (formData.phone_number) {
            if (!/^\d{10}$/.test(formData.phone_number)) {
                newErrors.phone_number = 'El número de teléfono debe tener exactamente 10 dígitos';
            }
        }
        
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSave = async () => {
        if (!validateForm()) return;

        setSaving(true);
        try {
            await putUser(formData);
            localStorage.removeItem('username');
            localStorage.setItem('username', formData.username);
            navigate('/profile');
        } catch (error) {
            console.error('Error updating profile:', error);
            alert('Hubo un error al actualizar el perfil');
        } finally {
            setSaving(false);
        }
    };

    const handleCancel = () => {
        navigate('/profile');
    };

    const hasChanges = JSON.stringify(formData) !== JSON.stringify(originalData);

    if (loading) {
        return (
            <>
                <NavarCompleto login={true} />
                <div className="edit-profile-container">
                    <div className="edit-profile-loading">
                        <div className="edit-loading-spinner"></div>
                        <p>Cargando perfil...</p>
                    </div>
                </div>
            </>
        );
    }

    return (
        <>
            <NavarCompleto login={true} />
            <div className="edit-profile-container">
                <div className="edit-profile-card">
                    <div className="edit-profile-header">
                        <div className="edit-header-overlay"></div>
                        <div className="edit-profile-avatar">
                            <div className="edit-avatar-circle">
                                <FaUser className="edit-avatar-icon" />
                            </div>
                        </div>
                    </div>

                    <div className="edit-profile-content">
                        <div className="edit-profile-title-section">
                            <h1 className="edit-profile-title">
                                <FaEdit className="edit-title-icon" />
                                Editar Perfil
                            </h1>
                            <p className="edit-profile-subtitle">
                                Actualiza tu información personal
                            </p>
                        </div>

                        <div className="edit-profile-form">
                            <div className="edit-form-grid">
                                <div className="edit-form-group edit-form-group-full">
                                    <label htmlFor="username" className="edit-form-label">
                                        <FaUserTag className="edit-label-icon" />
                                        Nombre de Usuario
                                    </label>
                                    <input
                                        id="username"
                                        type="text"
                                        name="username"
                                        value={formData.username}
                                        onChange={handleInputChange}
                                        className={`edit-form-input ${errors.username ? 'edit-form-input-error' : ''}`}
                                        placeholder="Ingresa tu nombre de usuario"
                                        readOnly={true}
                                    />
                                    {errors.username && <span className="edit-error-message">{errors.username}</span>}
                                </div>

                                <div className="edit-form-group">
                                    <label htmlFor="first_name" className="edit-form-label">
                                        <FaUser className="edit-label-icon" />
                                        Nombre
                                    </label>
                                    <input
                                        id="first_name"
                                        type="text"
                                        name="first_name"
                                        value={formData.first_name}
                                        onChange={handleInputChange}
                                        className={`edit-form-input ${errors.first_name ? 'edit-form-input-error' : ''}`}
                                        placeholder="Ingresa tu nombre"
                                        readOnly={true}
                                    />
                                    {errors.first_name && <span className="edit-error-message">{errors.first_name}</span>}
                                </div>

                                <div className="edit-form-group">
                                    <label htmlFor="last_name" className="edit-form-label">
                                        <FaUser className="edit-label-icon" />
                                        Apellidos
                                    </label>
                                    <input
                                        id="last_name"
                                        type="text"
                                        name="last_name"
                                        value={formData.last_name}
                                        onChange={handleInputChange}
                                        className={`edit-form-input ${errors.last_name ? 'edit-form-input-error' : ''}`}
                                        placeholder="Ingresa tu apellido"
                                        readOnly={true}
                                    />
                                    {errors.last_name && <span className="edit-error-message">{errors.last_name}</span>}
                                </div>

                                <div className="edit-form-group edit-form-group-full">
                                    <label htmlFor="phone_number" className="edit-form-label">
                                        <FaPhone className="edit-label-icon" />
                                        Número de Teléfono
                                    </label>
                                    <input
                                        id="phone_number"
                                        type="tel"
                                        name="phone_number"
                                        maxLength={10}
                                        value={formData.phone_number}
                                        onChange={handleInputChange}
                                        className={`edit-form-input ${errors.phone_number ? 'edit-form-input-error' : ''}`}
                                        placeholder="Ingresa tu número de teléfono (10 dígitos)"
                                    />
                                    {errors.phone_number && <span className="edit-error-message">{errors.phone_number}</span>}
                                </div>
                                
                                <div className="edit-form-group edit-form-group-full">
                                    <label htmlFor="email" className="edit-form-label">
                                        <FaEnvelope className="edit-label-icon" />
                                        Email
                                    </label>
                                    <input
                                        id="email"
                                        type="email"
                                        name="email"
                                        value={formData.email}
                                        onChange={handleInputChange}
                                        className={`edit-form-input ${errors.email ? 'edit-form-input-error' : ''}`}
                                        placeholder="Ingresa tu email"
                                    />
                                    {errors.email && <span className="edit-error-message">{errors.email}</span>}
                                </div>
                            </div>

                            <div className="edit-form-actions">
                                <button
                                    type="button"
                                    onClick={handleCancel}
                                    className="edit-cancel-btn"
                                >
                                    <FaTimes className="edit-btn-icon" />
                                    Cancelar
                                </button>
                                
                                <button
                                    type="button"
                                    onClick={handleSave}
                                    disabled={!hasChanges || saving}
                                    className="edit-save-btn"
                                >
                                    {saving ? (
                                        <>
                                            <div className="edit-btn-spinner"></div>
                                            Guardando...
                                        </>
                                    ) : (
                                        <>
                                            <FaSave className="edit-btn-icon" />
                                            Guardar Cambios
                                        </>
                                    )}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default EditProfile;