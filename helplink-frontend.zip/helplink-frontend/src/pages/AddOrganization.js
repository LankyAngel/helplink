import React, { useState, useEffect } from "react";
import { FaUser, FaEnvelope, FaLock, FaPhone, FaUserPlus,FaImage,FaBuilding,FaUserTie,
  FaFileUpload,FaExclamationTriangle,FaCheckCircle  } from 'react-icons/fa';
import "../assets/style/AddOrganization.css";
import NavarCompleto from "../Components/NavarCompleto";
import { useNavigate } from "react-router-dom";
import axios from 'axios';
import { putAddOrganization } from "../services/authService";
import { useAuth } from '../contex/AuthProvider';


const AddOrganization = () => {
  const { access,logout } = useAuth();
  const apiURL = process.env.REACT_APP_API_URL;
  const _apiURL = `${apiURL}/organizations/`;
  const _apiURLcontact = `${apiURL}/legal-contact/`;
  const [errorMsg, setErrorMsg] = useState("");
  const [successMsg, setSuccessMsg] = useState("");
  
  //const [name, setName] = useState("");
  //const [email, setEmail] = useState("");
  //const [phoneNumber, setPhoneNumber] = useState("");
  const [emailError, setEmailError] = useState("");
  const [logo, setLogo] = useState(null);
  //const [logoContact, setLogoContact] = useState(null);

  //const [contactName, setContactName] = useState("");
  //const [contactEmail, setContactEmail] = useState("");
  //const [contactPhoneNumber, setContactPhoneNumber] = useState("");
  //const [contactPosition, setContactPosition] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  //const [organizacion, setOrganizacion] = useState(null);
  const navigate = useNavigate();

  //Guardar la imagen
  const handleImagenChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData({ ...formData, logo: file });
      setPreview(URL.createObjectURL(file)); // Aquí se genera la vista previa
    }
  };

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone_number: '',
    logo: File,
  });
  const [preview, setPreview] = useState(null);
  

  const [formDataContact, setFormDataContact] = useState({
    full_name: '',
    email: '',
    phone_number: '',
    position: '',
    professional_license: null,
    organization: '',
  });

 const submitForm = async (e) => {
  e.preventDefault();
  setIsLoading(true);

  try {
    // Paso 1: Crear y enviar la organización
    const fd = new FormData();
    fd.append('name', formData.name);
    fd.append('email', formData.email);
    fd.append('phone_number', formData.phone_number);
    if (formData.logo) {
      fd.append('logo', formData.logo);
    }

    const responseOrg = await fetch(_apiURL, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${access}`,
      },
      body: fd,
    });

    if (!responseOrg.ok) {
      const errorOrg = await responseOrg.json();
      console.error("Error al crear la organización:", errorOrg);
      throw new Error("Error al registrar la organización.");
    }

    const orgData = await responseOrg.json();
    const organizationId = orgData.id; // Aquí obtenemos el ID recién creado
    

    // Paso 2: Crear y enviar el contacto legal usando ese ID
    const formDataContacto = new FormData();
    formDataContacto.append("full_name", formDataContact.full_name);
    formDataContacto.append("email", formDataContact.email);
    formDataContacto.append("phone_number", formDataContact.phone_number);
    formDataContacto.append("position", formDataContact.position);

    if (formDataContact.professional_license) {
      formDataContacto.append("professional_license", formDataContact.professional_license);
    }

    formDataContacto.append("organization", parseInt(organizationId)); // Enviamos el ID aquí

    const responseContacto = await fetch(_apiURLcontact, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${access}`,
      },
      body: formDataContacto,
    });

    if (!responseContacto.ok) {
      const errorContacto = await responseContacto.json();
      console.error("Error al crear el contacto legal:", errorContacto);
      throw new Error("Error al registrar el contacto legal.");
    }

    //alert("Empresa y contacto legal registrados con éxito");
    setSuccessMsg("¡Evento creado y categoría asignada correctamente!");
      setTimeout(() => {
        setSuccessMsg("");
        logout();
        navigate("/login");
      }, 2000);
    //logout();
    //navigate("/login");
  } catch (error) {
    console.error("Error general:", error);
    setEmailError(error.message);
    setErrorMsg(error.message);
    setTimeout(() => setErrorMsg(""), 6000);
  } finally {
    setIsLoading(false);
  }
};



  
  return (
    <>
      <NavarCompleto />
      <div className="register-container">
        <div className="background-decorations">
          <div className="decoration decoration-1"></div>
          <div className="decoration decoration-2"></div>
          <div className="decoration decoration-3"></div>
        </div>

        <div className="register-wrapper">
          <div className="register-card">
            <div className="register-header">
              <div className="avatar-container">
                <FaBuilding  className="avatar-icon" />
              </div>
              <h1 className="register-title">Dar de alta organización</h1>
              <p className="register-subtitle">Datos de la organización</p>
            </div>

            
            <form className="register-form" onSubmit={submitForm}>
              {/* Campo de nombre */}
              <div className="input-group">
                <div className="input-icon">
                  <FaUser className="icon" />
                </div>
                <input
                  type="text"
                  placeholder="Nombre"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="form-input"
                  //required
                />
              </div>

              {/* Campo de email */}
              <div className="input-group">
                <div className="input-icon">
                  <FaEnvelope className="icon" />
                </div>
                <input
                  type="email"
                  placeholder="Correo electrónico"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="form-input"
                  //required
                />
              </div>
              

              {/* Campo de teléfono */}
              <div className="input-group">
                <div className="input-icon">
                  <FaPhone className="icon" />
                </div>
                <input
                  type="tel"
                  maxLength={10}
                  minLength={10}
                  placeholder="Número de teléfono"
                  value={formData.phone_number}
                  //onChange={(e) => setFormData({ ...formData, phone_number: e.target.value })}
                  onChange={(e) => {
                      const valor = e.target.value;

                      // Validar que solo se ingresen dígitos
                      if (/^\d*$/.test(valor)) {
                        setFormData({ ...formData, phone_number: valor });
                      }
                    }}

                  className="form-input"
                  //required
                  onInvalid={(e) => {
                    e.target.setCustomValidity(
                      "El número de teléfono debe contener 10 dígitos"
                    );
                  }}
                  onInput={(e) => {
                    e.target.setCustomValidity("");
                  }}
                />
              </div>

              {/* Campo de Logo */}
              <div className="input-group">
                <div className="input-icon">
                  <FaImage className="icon" />
                </div>
                <input
                  type="file"
                  accept="image/*"
                  //placeholder="Logo"
                  onChange={handleImagenChange}
                  // onChange={(e) =>
                  //     setFormData({ ...formData, logo: e.target.files[0] })
                     
                  // }
                  className="form-input"
                  //required
                />
                {preview && (
                  <img
                    src={preview}
                    alt="Vista previa del logo"
                    style={{ width: "150px", height: "auto", marginTop: "10px", borderRadius: "8px" }}
                  />
                )}
              </div>

              <center>
                <p className="register-subtitle" >Datos del contacto legal</p>
              </center>
              
               {/* Campo de nombre del contacto legal */}
              <div className="input-group">
                <div className="input-icon">
                  <FaUser className="icon" />
                </div>
                <input
                  type="text"
                  placeholder="Nombre completo"
                  value={formDataContact.full_name}
                  onChange={(e) =>
                    setFormDataContact({ ...formDataContact, full_name: e.target.value })
                  }
                  className="form-input"
                />
              </div>

              {/* Campo de email del contacto legal*/}
              <div className="input-group">
                <div className="input-icon">
                  <FaEnvelope className="icon" />
                </div>
                <input
                  type="email"
                  placeholder="Correo electrónico"
                  value={formDataContact.email}
                  onChange={(e) =>
                    setFormDataContact({ ...formDataContact, email: e.target.value })
                  }
                  className="form-input"
                />
              </div>
            
              {/* Campo de teléfono del contacto */}
              <div className="input-group">
                <div className="input-icon">
                  <FaPhone className="icon" />
                </div>
                <input
                  type="tel"
                  placeholder="Número de teléfono"
                  value={formDataContact.phone_number}
                  // onChange={(e) =>
                  //   setFormDataContact({ ...formDataContact, phone_number: e.target.value })
                  // }
                  maxLength={10}
                  minLength={10}
                  onChange={(e) => {
                      const valor = e.target.value;

                      // Validar que solo se ingresen dígitos
                      if (/^\d*$/.test(valor)) {
                        setFormDataContact({ ...formData, phone_number: valor });
                      }
                    }}
                  onInvalid={(e) => {
                    e.target.setCustomValidity(
                      "El número de teléfono debe contener 10 dígitos"
                    );
                  }}
                  onInput={(e) => {
                    e.target.setCustomValidity("");
                  }}
                  className="form-input"
                />
              </div>

              {/* Campo de posición del contacto */}
              <div className="input-group">
                <div className="input-icon">
                  <FaUserTie className="icon" />
                </div>
                <input
                  type="text"
                  placeholder="Posición"
                  value={formDataContact.position}
                  onChange={(e) =>
                    setFormDataContact({ ...formDataContact, position: e.target.value })
                  }
                  className="form-input"
                />
              </div>


              {/* Campo de docuemnto legal */}
              <div className="input-group">
                <div className="input-icon">
                  <FaFileUpload className="icon" />
                </div>
                <input
                  type="file"
                  accept=".pdf,.doc,.docx"
                  onChange={(e) =>
                    setFormDataContact({
                      ...formDataContact,
                      professional_license: e.target.files[0],
                    })
                  }
                  className="form-input"
                />
              </div>
              
                {emailError && (
                <p className="register-error">{emailError}</p>
              )}
               {errorMsg && (
                  <div className="toast-error">
                    <FaExclamationTriangle style={{ marginRight: "0.5rem" }} />
                    {errorMsg}
                  </div>
                )}
                {successMsg && (
                  <div className="toast-success">
                    <FaCheckCircle style={{ marginRight: "0.5rem" }} />
                    {successMsg}
                  </div>
                )}
              {/* Botón de registro */}
              <button
                type="submit"
                disabled={isLoading}
                className="submit-button"
              >
                {isLoading ? (
                  <div className="loading-container">
                    <div className="spinner"></div>
                    Procesando...
                  </div>
                ) : (
                  'Dar de alta'
                )}
              </button>
            </form>

          </div>
        </div>
      </div>
    </>
  );
};

export default AddOrganization;