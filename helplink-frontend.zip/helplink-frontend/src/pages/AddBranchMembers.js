// src/pages/AddBranchMembers.js
import React, { useEffect, useState } from "react";
import {
  FaUsers,
  FaArrowLeft,
  FaSearch,
  FaPlus,
  FaUser,
  FaEnvelope,
  FaBuilding,
  FaCheck,
  FaSpinner,
  FaTimes,
  FaUserPlus,
  FaFilter,FaExclamationTriangle,FaCheckCircle,
} from "react-icons/fa";
import NavarCompleto from "../Components/NavarCompleto";
import { getUserInfo, addUserToOrganization } from "../services/authService";
import { useNavigate } from "react-router-dom";
import "../assets/style/AddOrganizationMember.css";
import { useAuth } from "../contex/AuthProvider";
import OrganizationBranches from "./OrganizationBranches";

const AddBranchMembers = () => {
  const apiURL = process.env.REACT_APP_API_URL;
  const _apiURLGETBRANCHES = `${apiURL}/branches/`;
  const _apiURLinsert = `${apiURL}/branch-memberships/`;
  const { access, org_code, user_id, branch__id } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [allUsers, setAllUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [organizationBranches, setOrganizationBranches] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const [searchFocused, setSearchFocused] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [sucursales, setSucursales] = useState([]);
  const [errorMsg, setErrorMsg] = useState("");
  const [successMsg, setSuccessMsg] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    if (!org_code) return;
    const fetchOrganization = async () => {
      try {
        const response = await fetch(`${apiURL}/organizations/${org_code}/`);
        if (!response.ok) throw new Error("Error al cargar organización");
        const data = await response.json();
        // branches es un array de sucursales
        setSucursales(data.branches || []);
        setOrganizationBranches(data.branches || []);
      } catch (error) {
        console.error("Error al cargar la organización:", error);
        setSucursales([]);
        setOrganizationBranches([]);
      }
    };
    fetchOrganization();
  }, [org_code, apiURL]);

  const fetchUsers = async () => {
    setIsSearching(true);
    try {
      const users = await getUserInfo();
      // Filtrar solo los usuarios con global_role.role === 'volunteer'
      const volunteers = users.filter(
        (user) =>
          user.global_role &&
          user.global_role.role &&
          user.global_role.role.toLowerCase() === "volunteer"
      );

      setAllUsers(volunteers);
      setTimeout(() => setIsLoaded(true), 300);
    } catch (error) {
      console.error("Error fetching users:", error);
      setAllUsers([]);
      setTimeout(() => setIsLoaded(true), 300);
    } finally {
      setIsSearching(false);
    }
  };

  const handleSearch = (term) => {
    setSearchTerm(term);
    if (term.length >= 2) {
      const filtered = allUsers.filter(
        (user) =>
          `${user.first_name} ${user.last_name}`
            .toLowerCase()
            .includes(term.toLowerCase()) ||
          user.email.toLowerCase().includes(term.toLowerCase())
      );
      setFilteredUsers(filtered);
      setShowResults(true);
    } else {
      setFilteredUsers([]);
      setShowResults(false);
    }
  };

  const handleUserSelect = (user) => {
    setSelectedUser(user);
    setSearchTerm(`${user.first_name} ${user.last_name}`);
    setShowResults(false);
  };

  const handleClearSelection = () => {
    setSelectedUser(null);
    setSearchTerm("");
    setShowResults(false);
  };

  const handleAddMember = async () => {
    if (!selectedUser) {
      alert("Por favor selecciona un usuario y una sucursal");
      return;
    }

    // if (
    //   window.confirm(
    //     `¿Agregar a ${selectedUser.first_name} ${selectedUser.last_name} a la sucursal seleccionada?`
    //   )
    // ) {
      //setIsLoading(true);
      try {

        const formDataMember = {
          user_id: selectedUser.id,
          branch_id: branch__id,
          role: "staff",
        };
        

        const resInsert = await fetch(_apiURLinsert, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${access}`,
          },
          body: JSON.stringify(formDataMember),
        });

        if (!resInsert.ok) {
          const errorData = await resInsert.json();
          console.error("Detalles del error:", errorData);
          throw new Error("Error al insertar miembro");
        }

        // Aquí iría la lógica para agregar el usuario a la organización
        //await new Promise(resolve => setTimeout(resolve, 2000)); // Simulamos API call

        //alert("¡Miembro agregado exitosamente!");
        setSuccessMsg("¡Miembro agregado exitosamente!");
        setTimeout(() => {
          setSuccessMsg("");
          navigate("/branchAdminPanel");
        }, 2000);
        //navigate("/branchAdminPanel");
      } catch (error) {
        console.error("Error adding member:", error);
        //alert("Error al agregar el miembro. Inténtalo de nuevo.");
        setErrorMsg("Error al agregar el miembro. Inténtalo de nuevo.");
        setTimeout(() => setErrorMsg(""), 4000);
      } finally {
        setIsLoading(false);
      }
    //}
  };

  const handleBack = () => {
    navigate("/branchAdminPanel");
  };

  const getUserStatus = (user) => {
    if (user.is_active === false)
      return { text: "Inactivo", class: "inactive" };
    if (user.last_login) return { text: "Activo", class: "active" };
    return { text: "Nuevo", class: "new" };
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  return (
    <div className="add-member-org-container">
      <div className="add-member-org-bg-decoration">
        <div className="add-member-org-floating-shape add-member-org-shape-1"></div>
        <div className="add-member-org-floating-shape add-member-org-shape-2"></div>
        <div className="add-member-org-floating-shape add-member-org-shape-3"></div>
      </div>

      <NavarCompleto login={true} />

      <div className={`add-member-org-panel ${isLoaded ? "loaded" : ""}`}>
        <div className="add-member-org-header">
          <div className="add-member-org-header-content">
            <button onClick={handleBack} className="add-member-org-back-btn">
              <FaArrowLeft />
              Volver a Miembros
            </button>

            <div className="add-member-org-title-section">
              <h1>
                <FaUserPlus className="add-member-org-title-icon" />
                <span className="add-member-org-text-primary">Agregar</span>
                <span className="add-member-org-text-gradient">Miembro</span>
              </h1>
              <p className="add-member-org-subtitle">
                Busca y agrega nuevos miembros a tu organización
              </p>
            </div>
          </div>
        </div>

        <div className="add-member-org-form-container">
          <div className="add-member-org-form-card">
            <div className="add-member-org-form-header">
              <h2>
                <FaSearch />
                Información del Miembro
              </h2>
              <p>
                Busca el usuario que deseas agregar y selecciona la sucursal
              </p>
            </div>

            <div className="add-member-org-form-content">
              {/* BUSCADOR DE USUARIOS */}
              <div className="add-member-org-field-group">
                <label
                  htmlFor="add-member-org-field-group"
                  className="add-member-org-field-label"
                >
                  <FaUser />
                  Buscar Usuario
                </label>
                <div className="add-member-org-search-container">
                  <div
                    className={`add-member-org-search-wrapper ${searchFocused ? "focused" : ""} ${selectedUser ? "selected" : ""}`}
                  >
                    <FaSearch className="add-member-org-search-icon" />
                    <input
                      type="text"
                      placeholder="Buscar por nombre o email..."
                      value={searchTerm}
                      onChange={(e) => handleSearch(e.target.value)}
                      onFocus={() => {
                        setSearchFocused(true);
                        if (searchTerm.length >= 2) setShowResults(true);
                      }}
                      onBlur={() => {
                        setTimeout(() => {
                          setSearchFocused(false);
                          setShowResults(false);
                        }, 200);
                      }}
                      className="add-member-org-search-input"
                      disabled={selectedUser}
                    />
                    {selectedUser && (
                      <button
                        onClick={handleClearSelection}
                        className="add-member-org-clear-btn"
                        type="button"
                      >
                        <FaTimes />
                      </button>
                    )}
                    {isSearching && (
                      <FaSpinner className="add-member-org-loading-icon" />
                    )}
                  </div>

                  {showResults && filteredUsers.length > 0 && (
                    <div className="add-member-org-search-results">
                      {filteredUsers.slice(0, 5).map((user) => {
                        const status = getUserStatus(user);
                        return (
                          <button
                            key={user.id}
                            onClick={() => handleUserSelect(user)}
                            className="add-member-org-search-result-item"
                          >
                            <div className="add-member-org-user-info">
                              <div className="add-member-org-user-name">
                                {user.first_name} {user.last_name}
                              </div>
                              <div className="add-member-org-user-email">
                                <FaEnvelope />
                                {user.email}
                              </div>
                            </div>
                            <div
                              className={`add-member-org-user-status ${status.class}`}
                            >
                              {status.text}
                            </div>
                          </button>
                        );
                      })}
                      {filteredUsers.length > 5 && (
                        <div className="add-member-org-search-more">
                          +{filteredUsers.length - 5} usuarios más...
                        </div>
                      )}
                    </div>
                  )}

                  {showResults &&
                    filteredUsers.length === 0 &&
                    searchTerm.length >= 2 && (
                      <div className="add-member-org-search-empty">
                        <FaUser />
                        <span>No se encontraron usuarios</span>
                      </div>
                    )}
                </div>
              </div>

              {/* INFORMACIÓN DEL USUARIO SELECCIONADO */}
              {selectedUser && (
                <div className="add-member-org-selected-user">
                  <div className="add-member-org-selected-user-header">
                    <h3>
                      <FaCheck />
                      Usuario Seleccionado
                    </h3>
                  </div>
                  <div className="add-member-org-selected-user-info">
                    <div className="add-member-org-selected-user-details">
                      <div className="add-member-org-selected-user-name">
                        {selectedUser.first_name} {selectedUser.last_name}
                      </div>
                      <div className="add-member-org-selected-user-email">
                        <FaEnvelope />
                        {selectedUser.email}
                      </div>
                      {selectedUser.phone && (
                        <div className="add-member-org-selected-user-phone">
                          Teléfono: {selectedUser.phone}
                        </div>
                      )}
                    </div>
                    <div
                      className={`add-member-org-selected-user-status ${getUserStatus(selectedUser).class}`}
                    >
                      {getUserStatus(selectedUser).text}
                    </div>
                  </div>
                </div>
              )}
            </div>

            <div className="add-member-org-form-actions">
              {successMsg && (
                <div className="toast-success">
                  <FaCheckCircle style={{ marginRight: "0.5rem" }} />
                  {successMsg}
                </div>
              )}
               {errorMsg && (
                  <div className="toast-error">
                    <FaExclamationTriangle style={{ marginRight: "0.5rem" }} />
                    {errorMsg}
                  </div>
                )}

              <button
                onClick={handleBack}
                className="add-member-org-cancel-btn"
                disabled={isLoading}
              >
                <FaTimes />
                Cancelar
              </button>

              <button
                onClick={handleAddMember}
                className="add-member-org-submit-btn"
                disabled={!selectedUser || isLoading}
              >
                {isLoading ? (
                  <>
                    <FaSpinner className="add-member-org-loading-spinner" />
                    Agregando...
                  </>
                ) : (
                  <>
                    <FaPlus />
                    Agregar Miembro
                  </>
                )}
              </button>
            </div>
          </div>

          {/* PANEL DE AYUDA */}
          <div className="add-member-org-help-panel">
            <div className="add-member-org-help-header">
              <h3>
                <FaUsers />
                Instrucciones
              </h3>
            </div>
            <div className="add-member-org-help-content">
              <div className="add-member-org-help-step">
                <div className="add-member-org-help-step-number">1</div>
                <div className="add-member-org-help-step-text">
                  <strong>Buscar Usuario</strong>
                  <p>
                    Escribe el nombre o email del usuario que deseas agregar
                  </p>
                </div>
              </div>

              <div className="add-member-org-help-step">
                <div className="add-member-org-help-step-number">2</div>
                <div className="add-member-org-help-step-text">
                  <strong>Seleccionar Usuario</strong>
                  <p>Haz clic en el usuario correcto de los resultados</p>
                </div>
              </div>

              <div className="add-member-org-help-step">
                <div className="add-member-org-help-step-number">3</div>
                <div className="add-member-org-help-step-text">
                  <strong>Elegir Sucursal</strong>
                  <p>Selecciona la sucursal donde trabajará el nuevo miembro</p>
                </div>
              </div>

              <div className="add-member-org-help-step">
                <div className="add-member-org-help-step-number">4</div>
                <div className="add-member-org-help-step-text">
                  <strong>Confirmar</strong>
                  <p>
                    Revisa la información y confirma para agregar el miembro
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddBranchMembers;
