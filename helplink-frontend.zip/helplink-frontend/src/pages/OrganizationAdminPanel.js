import React, { useState, useEffect } from "react";
import "../assets/style/OrganizationAdminPanel.css";
import Header from "../Components/Header";
import { useAuth } from "../contex/AuthProvider";
import { useNavigate } from "react-router-dom";
import NavarCompleto from "../Components/NavarCompleto";
import { getUserInfo } from "../services/authService";
import {
  FaHeart,
  FaUsers,
  FaHandsHelping,
  FaArrowRight,
  FaCalendarAlt,
  FaUserTie,
  FaPlus,
  FaChartBar,
  FaCog,
  FaClipboardList,
  FaChartLine,
  FaRocket,
  FaBuilding,
  FaEdit,
  FaEye,
  FaTrash,
  FaUserPlus,
  FaCodeBranch,
  FaGlobe,
  FaTrophy,
  FaStar,
} from "react-icons/fa";
import {
  getOrganizationDashboard,
} from "../services/api";

const OrganizationAdminPanel = () => {
  const [isLoaded, setIsLoaded] = useState(false);
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [logo, setLogo] = useState();
  const [activeTab, setActiveTab] = useState("dashboard");

  const [stats, setStats] = useState({
    activeEvents: 0,
    participations: 0,
    branches: 0,
    members: 0,
    rating: 4.8,
  });

  const [recentEvents, setRecentEvents] = useState([]);
  const [topBranches, setTopBranches] = useState([]);

  const fetchAdminStats = async () => {
    try {
      const orgId = localStorage.getItem("organizationId");
      if (!orgId) return;

      const dashboardData = await getOrganizationDashboard();
      setStats((prev) => ({
        ...prev,
        activeEvents: dashboardData.active_events.length,
        participations: dashboardData.attendance_count,
        branches: dashboardData.branches.length,
      }));

      setRecentEvents(dashboardData.active_events);
      setTopBranches(dashboardData.branches.slice(0, 3));
    } catch (error) {
      console.error("Error al cargar las estadísticas reales:", error);
    }
  };

  const findOrganizationInfo = async () => {
    const data = await getUserInfo();
    const user = data.find(
      (u) => u.username === localStorage.getItem("username")
    );
    if (user && user.organization) {
      setLogo(user.organization.logo);
      localStorage.setItem("organizationId", user.organization.id);
    }
  };

  useEffect(() => {
    setIsLoaded(true);
    findOrganizationInfo();
    fetchAdminStats();
  }, []);

  // Navegación
  const goManageEvents = () => navigate("/organizationAdminPanel/events");
  const goCreateBranch = () => navigate("/addBranch");
  const goCreateEvent = () => navigate("/addEvent");
  const goManageBranches = () => navigate("/organizationAdminPanel/branches");
  const goManageMembers = () => navigate("/organizationAdminPanel/members");

  const renderDashboard = () => (
    <div className="dashboard-content">
      <div className="stats-grid">
        <div className="stat-card primary">
          <div className="stat-icon">
            <FaCalendarAlt />
          </div>
          <div className="stat-info">
            <div className="stat-number">{stats.activeEvents}</div>
            <div className="stat-label">Eventos Activos</div>
          </div>
        </div>

        <div className="stat-card secondary">
          <div className="stat-icon">
            <FaBuilding />
          </div>
          <div className="stat-info">
            <div className="stat-number">{stats.branches}</div>
            <div className="stat-label">Sucursales</div>
          </div>
        </div>

        <div className="stat-card warning">
          <div className="stat-icon">
            <FaHandsHelping />
          </div>
          <div className="stat-info">
            <div className="stat-number">{stats.participations}</div>
            <div className="stat-label">Participaciones</div>
          </div>
        </div>
      </div>

      <div className="quick-actions">
        <h3>Acciones Rápidas</h3>
        <div className="actions-grid">
          <button className="action-card" onClick={goCreateEvent}>
            <FaPlus />
            <span>Crear Evento</span>
          </button>
          <button className="action-card" onClick={goCreateBranch}>
            <FaCodeBranch />
            <span>Crear Sucursal</span>
          </button>
          <button className="action-card" onClick={goManageMembers}>
            <FaUserPlus />
            <span>Gestionar Miembros</span>
          </button>
        </div>
      </div>

      <div className="dashboard-grid">
        <div className="dashboard-card">
          <div className="card-header">
            <h3>Eventos Recientes</h3>
            <button className="btn-link" onClick={goManageEvents}>
              Ver todos <FaArrowRight />
            </button>
          </div>
          <div className="events-list">
            {recentEvents.map((event, index) => (
              <div key={index} className="event-item">
                <div className="event-info">
                  <h4>{event.title}</h4>
                  <p>{event.description}</p>
                  <span className="event-date">{event.date}</span>
                </div>
                <div className="event-status">
                  <span className={`status ${event.status}`}>
                    {event.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="dashboard-card">
          <div className="card-header">
            <h3>Sucursales</h3>
            <button className="btn-link" onClick={goManageBranches}>
              Ver todas <FaArrowRight />
            </button>
          </div>
          <div className="branches-list">
            {topBranches.map((branch, index) => (
              <div key={index} className="branch-item">
                <div className="branch-rank">
                  <FaTrophy className={`trophy rank-${index + 1}`} />
                </div>
                <div className="branch-info">
                  <h4>{branch.name}</h4>
                  <p>{branch.city}, {branch.street}</p>
                </div>
                <div className="branch-stats">
                  <div className="branch-stat">
                    <span className="stat-value">
                      {branch.event_count}
                    </span>
                    <span className="stat-label">Eventos</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  const renderManagement = () => (
    <div className="management-content">
      <div className="management-grid">
        <button className="management-card" onClick={goManageEvents}>
          <div className="card-icon">
            <FaCalendarAlt />
          </div>
          <div className="card-content">
            <h3>Gestionar Eventos</h3>
            <p>Administra todos los eventos de la organización</p>
            <div className="card-stats">
              <span>{stats.activeEvents} eventos activos</span>
            </div>
          </div>
          <FaArrowRight className="card-arrow" />
        </button>

        <button className="management-card" onClick={goManageBranches}>
          <div className="card-icon">
            <FaBuilding />
          </div>
          <div className="card-content">
            <h3>Gestionar Sucursales</h3>
            <p>Administra las sucursales y sus administradores</p>
            <div className="card-stats">
              <span>{stats.branches} sucursales</span>
            </div>
          </div>
          <FaArrowRight className="card-arrow" />
        </button>

        <button className="management-card" onClick={goManageMembers}>
          <div className="card-icon">
            <FaUsers />
          </div>
          <div className="card-content">
            <h3>Gestionar Miembros</h3>
            <p>Administra miembros, voluntarios y permisos</p>
            <div className="card-stats">
              <span>{stats.members} miembros</span>
            </div>
          </div>
          <FaArrowRight className="card-arrow" />
        </button>
      </div>
    </div>
  );

  return (
    <div className="admin-panel-container">
      <div className="bg-decoration">
        <div className="floating-shape shape-1"></div>
        <div className="floating-shape shape-2"></div>
        <div className="floating-shape shape-3"></div>
      </div>

      <NavarCompleto login={true} />

      <div className={`admin-panel ${isLoaded ? "loaded" : ""}`}>
        <div className="panel-header">
          <div className="header-content">
            <div className="admin-badge">
              <FaUserTie />
              <span>Administrador de Organización</span>
            </div>
            <h1>
              <span className="text-primary">Panel de</span>
              <span className="text-gradient">Administración</span>
            </h1>
            <p className="header-description">
              Gestiona tu organización, sucursales y miembros desde un solo
              lugar.
              <span className="highlight-text"> Maximiza el impacto</span> de tu
              comunidad.
            </p>
          </div>

          <div className="org-logo">
            <img
              src={logo || "/AdminDashboard.jpg"}
              alt="Logo de la organización"
              className="logo-image"
            />
          </div>
        </div>

        <div className="panel-nav">
          <button
            className={`nav-item ${
              activeTab === "dashboard" ? "active" : ""
            }`}
            onClick={() => setActiveTab("dashboard")}
          >
            <FaChartBar />
            <span>Dashboard</span>
          </button>
          <button
            className={`nav-item ${
              activeTab === "management" ? "active" : ""
            }`}
            onClick={() => setActiveTab("management")}
          >
            <FaCog />
            <span>Gestión</span>
          </button>
        </div>

        <div className="panel-content">
          {activeTab === "dashboard" && renderDashboard()}
          {activeTab === "management" && renderManagement()}
        </div>
      </div>
    </div>
  );
};

export default OrganizationAdminPanel;
