// // Login.js
// import React, { useEffect, useState } from "react";
// import { FaEye, FaEyeSlash, FaLock, FaUser } from "react-icons/fa";
// import "../assets/style/Login.css";
// import NavarCompleto from "../Components/NavarCompleto";
// import { useAuth } from "../contex/AuthProvider";
// import { useNavigate } from "react-router-dom";
// import { getUserInfo } from "../services/authService";

// const Login = () => {
//   const { login } = useAuth();
//   const navigate = useNavigate();
//   const [organization, setOrganization] = useState(null);

//   const [showPassword, setShowPassword] = useState(false);
//   const [formData, setFormData] = useState({
//     username: "",
//     password: "",
//   });
//   const [isLoading, setIsLoading] = useState(false);
//   const [errorMsg, setErrorMsg] = useState("");

//   const handleInputChange = (e) => {
//     setFormData({
//       ...formData,
//       [e.target.name]: e.target.value,
//     });
//   };

//   const handleSubmit = async (e) => {
//   e.preventDefault();
//   setIsLoading(true);
//   setErrorMsg("");

//   try {
//     await login(formData.username, formData.password);

//     const data = await getUserInfo();
//     const username = localStorage.getItem("username");
//     const user = data.find((u) => u.username === username);

//     if (!user) {
//       setErrorMsg("Usuario no encontrado.");
//       setIsLoading(false);
//       return;
//     }

//     const rol = user.global_role.role;
//     const statusOrg = user.organization?.status; // aquí el status de la organización

//     switch (rol) {
//       case "volunteer":
//         navigate("/events");
//         break;

//       case "organization_staff":
//           navigate("/branchAdminPanel");
//         break;

//       case "organization_admin":
//         if (statusOrg === "approved") {
//           navigate("/organizationAdminPanel");
//         } else {
//           //setErrorMsg("Tu organización no está aprobada aún.");
//           navigate("/events");
//         }
//         break;

//       default:
//         break;
//     }
//   } catch (error) {
//     console.error("Error en login:", error.message);
//     setErrorMsg("Credenciales incorrectas o error de conexión.");
//   } finally {
//     setIsLoading(false);
//   }
// };

//   return (
//     <>
//       <NavarCompleto />
//       <div className="login-container">
//         <div className="background-decorations">
//           <div className="decoration decoration-1"></div>
//           <div className="decoration decoration-2"></div>
//           <div className="decoration decoration-3"></div>
//         </div>

//         <div className="login-wrapper">
//           <div className="login-card">
//             <div className="login-header">
//               <div className="avatar-container">
//                 <FaUser className="avatar-icon" />
//               </div>
//               <h1 className="login-title">Bienvenido</h1>
//               <p className="login-subtitle">Inicia sesión en tu cuenta</p>
//             </div>

//             <form className="login-form" onSubmit={handleSubmit}>
//               {/* Campo de usuario */}
//               <div className="input-group">
//                 <div className="input-icon">
//                   <FaUser className="icon" />
//                 </div>
//                 <input
//                   type="text"
//                   name="username"
//                   value={formData.username}
//                   onChange={handleInputChange}
//                   placeholder="Usuario"
//                   className="form-input"
//                   required
//                 />
//               </div>

//               {/* Campo de contraseña */}
//               <div className="input-group">
//                 <div className="input-icon">
//                   <FaLock className="icon" />
//                 </div>
//                 <input
//                   type={showPassword ? "text" : "password"}
//                   name="password"
//                   value={formData.password}
//                   onChange={handleInputChange}
//                   placeholder="Contraseña"
//                   className="form-input password-input"
//                   required
//                 />
//                 <button
//                   type="button"
//                   onClick={() => setShowPassword(!showPassword)}
//                   className="password-toggle"
//                 >
//                   {showPassword ? (
//                     <FaEyeSlash className="toggle-icon" />
//                   ) : (
//                     <FaEye className="toggle-icon" />
//                   )}
//                 </button>
//               </div>

//               {/* Recordar y recuperar contraseña */}
//               <div className="form-options">
//                 <label className="checkbox-label">
//                   <input type="checkbox" className="checkbox" />
//                   <span className="checkbox-text">Recordarme</span>
//                 </label>
//                 <a href="/" className="forgot-password">
//                   ¿Olvidaste tu contraseña?
//                 </a>
//               </div>

//               {/* Botón de login */}
//               <button
//                 type="submit"
//                 disabled={isLoading}
//                 className="submit-button"
//               >
//                 {isLoading ? (
//                   <div className="loading-container">
//                     <div className="spinner"></div>
//                     Procesando...
//                   </div>
//                 ) : (
//                   "Iniciar Sesión"
//                 )}
//               </button>

//               {/* Mensaje de error */}
//               {errorMsg && <p className="login-error">{errorMsg}</p>}
//             </form>
//           </div>
//         </div>
//       </div>
//     </>
//   );
// };

// export default Login;

// Login.js
import React, { useEffect, useState } from "react";
import { FaEye, FaEyeSlash, FaLock, FaUser, FaExclamationTriangle } from "react-icons/fa";
import "../assets/style/Login.css";
import NavarCompleto from "../Components/NavarCompleto";
import { useAuth } from "../contex/AuthProvider";
import { useNavigate } from "react-router-dom";
import { getUserInfo } from "../services/authService";

const Login = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [organization, setOrganization] = useState(null);

  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    username: "",
    password: "",
  });
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
    // Limpiar error cuando el usuario empiece a escribir
    if (errorMsg) {
      setErrorMsg("");
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMsg("");

    try {
      await login(formData.username, formData.password);

      const data = await getUserInfo();
      const username = localStorage.getItem("username");
      const user = data.find((u) => u.username === username);

      if (!user) {
        setErrorMsg("Usuario no encontrado.");
        setIsLoading(false);
        return;
      }

      const rol = user.global_role.role;
      const statusOrg = user.organization?.status; // aquí el status de la organización

      switch (rol) {
        case "volunteer":
          navigate("/events");
          break;

        case "organization_staff":
          navigate("/branchAdminPanel");
          break;

        case "organization_admin":
          if (statusOrg === "approved") {
            navigate("/organizationAdminPanel");
          } else {
            //setErrorMsg("Tu organización no está aprobada aún.");
            navigate("/events");
          }
          break;

        default:
          break;
      }
    } catch (error) {
      console.error("Error en login:", error.message);
      setErrorMsg("Credenciales incorrectas o error de conexión.");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <NavarCompleto />
      <div className="login-container">
        <div className="background-decorations">
          <div className="decoration decoration-1"></div>
          <div className="decoration decoration-2"></div>
          <div className="decoration decoration-3"></div>
        </div>

        <div className="login-wrapper">
          <div className="login-card">
            <div className="login-header">
              <div className="avatar-container">
                <FaUser className="avatar-icon" />
              </div>
              <h1 className="login-title">Bienvenido</h1>
              <p className="login-subtitle">Inicia sesión en tu cuenta</p>
            </div>

            <form className="login-form" onSubmit={handleSubmit}>
              {/* Mensaje de error */}
              {errorMsg && (
                <div className="error-container">
                  <div className="error-icon">
                    <FaExclamationTriangle className="error-icon-svg" />
                  </div>
                  <p className="error-message">{errorMsg}</p>
                </div>
              )}

              {/* Campo de usuario */}
              <div className="input-group">
                <div className="input-icon">
                  <FaUser className="icon" />
                </div>
                <input
                  type="text"
                  name="username"
                  value={formData.username}
                  onChange={handleInputChange}
                  placeholder="Usuario"
                  className="form-input"
                  required
                />
              </div>

              {/* Campo de contraseña */}
              <div className="input-group">
                <div className="input-icon">
                  <FaLock className="icon" />
                </div>
                <input
                  type={showPassword ? "text" : "password"}
                  name="password"
                  value={formData.password}
                  onChange={handleInputChange}
                  placeholder="Contraseña"
                  className="form-input password-input"
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="password-toggle"
                >
                  {showPassword ? (
                    <FaEyeSlash className="toggle-icon" />
                  ) : (
                    <FaEye className="toggle-icon" />
                  )}
                </button>
              </div>

              {/* Recordar y recuperar contraseña */}
              <div className="form-options">
                <label className="checkbox-label">
                  <input type="checkbox" className="checkbox" />
                  <span className="checkbox-text">Recordarme</span>
                </label>
                <a href="/password-reset" className="forgot-password">
                  ¿Olvidaste tu contraseña?
                </a>
              </div>

              {/* Botón de login */}
              <button
                type="submit"
                disabled={isLoading}
                className="submit-button"
              >
                {isLoading ? (
                  <div className="loading-container">
                    <div className="spinner"></div>
                    Procesando...
                  </div>
                ) : (
                  "Iniciar Sesión"
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default Login;