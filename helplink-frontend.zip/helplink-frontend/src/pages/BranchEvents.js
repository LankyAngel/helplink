// src/pages/BranchEvents.js
import React, { useEffect, useState } from "react";
import {
  FaCalendarAlt,
  FaEdit,
  FaTrash,
  FaPlus,
  FaArrowLeft,
  FaMapMarkerAlt,
  FaClock,
  FaUsers,
  FaStar,
  FaSearch,
  FaFilter,
  FaSort,
  FaEye,
  FaTicketAlt,
  FaCalendarDay,
  FaCalendarWeek,
  FaChartLine,
  FaCheckCircle,
  FaExclamationTriangle,
  FaPause,
  FaTags,
} from "react-icons/fa";
import { getBranchDashboard, deleteEvent, getBranchDashboardEvents } from "../services/api";
import NavarCompleto from "../Components/NavarCompleto";
import { useNavigate } from "react-router-dom";
import "../assets/style/BranchEvents.css";

const BranchEvents = () => {
  const [events, setEvents] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [sortBy, setSortBy] = useState("date");
  const [sortOrder, setSortOrder] = useState("asc");
  const [showFilters, setShowFilters] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const navigate = useNavigate();
  const [stats, setStats] = useState({
  total_events: 0,
  pending_events: 0,
  published_events: 0,
  canceled_events: 0,
  finished_events: 0,
  progress_events: 0,
  total_attendees: 0,
});

  const fetchEvents = async () => {
  try {
    const dashboardData = await getBranchDashboardEvents();
    setEvents(dashboardData.events || []);
    setStats(dashboardData.stats || {});
    setTimeout(() => setIsLoaded(true), 300);
  } catch (error) {
    console.error("Error fetching events:", error);
    setEvents([]);
    setStats({
      total_events: 0,
      pending_events: 0,
      published_events: 0,
      canceled_events: 0,
      finished_events: 0,
      progress_events: 0,
      total_attendees: 0,
    });
    setTimeout(() => setIsLoaded(true), 300);
  }
};


  const handleDelete = async (eventId) => {
    if (window.confirm("¿Estás seguro de eliminar este evento?")) {
      try {
        await deleteEvent(eventId);
        fetchEvents();
      } catch (error) {
        console.error("Error deleting event:", error);
      }
    }
  };

  const handleEdit = (eventId) => {
    navigate(`/editEvent/${eventId}`);
  };

  const handleView = (eventId) => {
    navigate(`/events/${eventId}`);
  };

  const handleCreateEvent = () => {
    navigate("/addBranchEvent");
  };

  const handleBack = () => {
    navigate("/branchAdminPanel");
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("es-ES", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const formatTime = (timeString) => {
    if (!timeString) return "Sin hora";
    return timeString.slice(0, 5);
  };

  const getEventStatus = (event) => {
    const now = new Date();
    const eventDate = new Date(event.date);

    if (event.status === "cancelled") {
      return {
        text: "Cancelado",
        class: "cancelled",
        icon: FaExclamationTriangle,
      };
    }
    if (event.status === "draft") {
      return { text: "Borrador", class: "draft", icon: FaPause };
    }
    if (eventDate < now) {
      return { text: "Finalizado", class: "finished", icon: FaCheckCircle };
    }
    if (event.status === "published") {
      return { text: "Publicado", class: "published", icon: FaCheckCircle };
    }
    return { text: "Programado", class: "scheduled", icon: FaClock };
  };

  const filteredAndSortedEvents = events
    .filter((event) => {
      const matchesSearch =
        event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        event.description.toLowerCase().includes(searchTerm.toLowerCase());

      const matchesStatus =
        statusFilter === "all" || event.status === statusFilter;
      const matchesCategory =
        categoryFilter === "all" || event.category === categoryFilter;

      return matchesSearch && matchesStatus && matchesCategory;
    })
    .sort((a, b) => {
      let aValue, bValue;

      switch (sortBy) {
        case "title":
          aValue = a.title.toLowerCase();
          bValue = b.title.toLowerCase();
          break;
        case "date":
          aValue = new Date(a.date);
          bValue = new Date(b.date);
          break;
        case "status":
          aValue = a.status;
          bValue = b.status;
          break;
        case "attendees":
          aValue = a.attendees_count || 0;
          bValue = b.attendees_count || 0;
          break;
        default:
          aValue = new Date(a.date);
          bValue = new Date(b.date);
      }

      if (sortOrder === "asc") {
        return aValue > bValue ? 1 : -1;
      } else {
        return aValue < bValue ? 1 : -1;
      }
    });

  const {
    total_events,
    published_events,
    pending_events,
    canceled_events,
    finished_events,
    progress_events,
    total_attendees,
    } = stats;

  const categories = [
    ...new Set(events.map((e) => e.category).filter(Boolean)),
  ];

  useEffect(() => {
    fetchEvents();
  }, []);

  return (
    <div className="branch-event-container">
      <div className="branch-event-bg-decoration">
        <div className="branch-event-floating-shape branch-event-shape-1"></div>
        <div className="branch-event-floating-shape branch-event-shape-2"></div>
        <div className="branch-event-floating-shape branch-event-shape-3"></div>
      </div>

      <NavarCompleto login={true} />

      <div className={`branch-event-panel ${isLoaded ? "loaded" : ""}`}>
        <div className="branch-event-header">
          <div className="branch-event-header-content">
            <button
              onClick={handleBack}
              className="branch-event-back-btn"
            >
              <FaArrowLeft />
              Volver al Panel
            </button>

            <div className="branch-event-title-section">
              <h1>
                <FaCalendarAlt className="branch-event-title-icon" />
                <span className="branch-event-text-primary">
                  Eventos de la
                </span>
                <span className="branch-event-text-gradient">
                  Sucursal
                </span>
              </h1>
              <p className="branch-event-subtitle">
                Administra todos los eventos de tu sucursal
              </p>
            </div>

            <button
              onClick={handleCreateEvent}
              className="branch-event-create-btn"
            >
              <FaPlus />
              Nuevo Evento
            </button>
          </div>
        </div>

        <div className="branch-event-stats-grid">
            <div className="branch-event-stat-card primary">
                <div className="branch-event-stat-icon">
                <FaCalendarAlt />
                </div>
                <div className="branch-event-stat-info">
                <div className="branch-event-stat-number">
                    {total_events}
                </div>
                <div className="branch-event-stat-label">Total Eventos</div>
                </div>
            </div>

            <div className="branch-event-stat-card success">
                <div className="branch-event-stat-icon">
                <FaCheckCircle />
                </div>
                <div className="branch-event-stat-info">
                <div className="branch-event-stat-number">
                    {published_events}
                </div>
                <div className="branch-event-stat-label">Publicados</div>
                </div>
            </div>

            <div className="branch-event-stat-card warning">
                <div className="branch-event-stat-icon">
                <FaPause />
                </div>
                <div className="branch-event-stat-info">
                <div className="branch-event-stat-number">
                    {pending_events}
                </div>
                <div className="branch-event-stat-label">Pendientes</div>
                </div>
            </div>

            <div className="branch-event-stat-card danger">
                <div className="branch-event-stat-icon">
                <FaExclamationTriangle />
                </div>
                <div className="branch-event-stat-info">
                <div className="branch-event-stat-number">
                    {canceled_events}
                </div>
                <div className="branch-event-stat-label">Cancelados</div>
                </div>
            </div>

            <div className="branch-event-stat-card info">
                <div className="branch-event-stat-icon">
                <FaUsers />
                </div>
                <div className="branch-event-stat-info">
                <div className="branch-event-stat-number">
                    {total_attendees}
                </div>
                <div className="branch-event-stat-label">Total Asistentes</div>
                </div>
            </div>
            </div>

        <div className="branch-event-list">
          {filteredAndSortedEvents.length === 0 ? (
            <div className="branch-event-empty-state">
              <FaCalendarAlt />
              <h3>No hay eventos</h3>
              <p>
                {searchTerm ||
                statusFilter !== "all" ||
                categoryFilter !== "all"
                  ? "No se encontraron eventos con los filtros aplicados."
                  : "Aún no has creado ningún evento. ¡Crea tu primer evento para comenzar!"}
              </p>
              {!searchTerm &&
                statusFilter === "all" &&
                categoryFilter === "all" && (
                  <button
                    onClick={handleCreateEvent}
                    className="branch-event-create-first-btn"
                  >
                    <FaPlus />
                    Crear Primer Evento
                  </button>
                )}
            </div>
          ) : (
            <div className="branch-event-grid">
              {filteredAndSortedEvents.map((event, index) => {
                const status = getEventStatus(event);
                const StatusIcon = status.icon;

                return (
                  <div key={event.id} className="branch-event-card">
                    <div className="branch-event-card-header">
                      <div className="branch-event-card-meta">
                        <div
                          className={`branch-event-status ${status.class}`}
                        >
                          <StatusIcon />
                          {status.text}
                        </div>
                      </div>

                      <h3 className="branch-event-card-title">
                        {event.title}
                      </h3>

                      <div className="branch-event-card-info">
                        <div className="branch-event-card-date">
                          <FaCalendarDay />
                          <span>{formatDate(event.date)}</span>
                        </div>

                        {event.time && (
                          <div className="branch-event-card-time">
                            <FaClock />
                            <span>{formatTime(event.time)}</span>
                          </div>
                        )}

                        {event.location && (
                          <div className="branch-event-card-location">
                            <FaMapMarkerAlt />
                            <span>{event.location}</span>
                          </div>
                        )}

                        {event.category && (
                          <div className="branch-event-card-category">
                            <FaTags />
                            <span>{event.category}</span>
                          </div>
                        )}
                      </div>

                      {event.description && (
                        <p className="branch-event-card-description">
                          {event.description.length > 120
                            ? `${event.description.substring(0, 120)}...`
                            : event.description}
                        </p>
                      )}
                    </div>

                    <div className="branch-event-card-actions">
                      <button
                        onClick={() => handleView(event.id)}
                        className="branch-event-action-btn view"
                        title="Ver detalles"
                      >
                        <FaEye />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {filteredAndSortedEvents.length > 0 && (
          <div className="branch-event-bulk-actions">
            <button
              onClick={handleCreateEvent}
              className="branch-event-bulk-btn"
            >
              <FaPlus />
              Agregar Otro Evento
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default BranchEvents;