import React, { useState } from "react";
import {
  FaUser,
  FaEnvelope,
  FaLock,
  FaPhone,
  FaUserPlus, FaExclamationTriangle, FaCheckCircle, FaEye, FaEyeSlash
} from "react-icons/fa";
import "../assets/style/Register.css";
import NavarCompleto from "../Components/NavarCompleto";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const Register = () => {
  const apiURL = process.env.REACT_APP_API_URL;
  const _apiURL = `${apiURL}/register/`;
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [firstname, setFirstname] = useState("");
  const [lastName, setLastName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [emailError, setEmailError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [successMsg, setSuccessMsg] = useState("");
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [passwordTouched, setPasswordTouched] = useState(false);

  const passwordRequirements = [
    { label: "Mínimo 8 caracteres", test: (pw) => pw.length >= 8 },
    { label: "Una mayúscula", test: (pw) => /[A-Z]/.test(pw) },
    { label: "Una minúscula", test: (pw) => /[a-z]/.test(pw) },
    { label: "Un número", test: (pw) => /[0-9]/.test(pw) },
    { label: "Un símbolo", test: (pw) => /[^A-Za-z0-9]/.test(pw) },
  ];

  const registerUser = async (
    username,
    email,
    password,
    firstname,
    lastName,
    phoneNumber
  ) => {
    const data = {
      first_name: firstname,
      last_name: lastName,
      email,
      username,
      password,
      phone_number: phoneNumber,
    };

    setIsLoading(true);
    try {
      const response = await axios.post(_apiURL, data);
      setSuccessMsg("¡Registro exitoso!");
      setTimeout(() => {
        setSuccessMsg("");
        navigate("/login");
      }, 2000);
      //navigate("/login");
    } catch (error) {
      if (error.response) {
        const errors = error.response.data;

        // Mostrar error personalizado si el backend lo devuelve
        if (
          errors.email &&
          errors.email[0] === "Enter a valid email address."
        ) {
          setEmailError("Ingrese un correo válido");
        } else {
          setEmailError("");
        }

        // Puedes hacer lo mismo con otros campos si deseas
        console.error("Error en la respuesta del servidor:", errors);
        setErrorMsg(error.message);
        setTimeout(() => setErrorMsg(""), 6000);
      } else {
        console.error("Error de red:", error.message);
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <NavarCompleto />
      <div className="register-container">
        <div className="background-decorations">
          <div className="decoration decoration-1"></div>
          <div className="decoration decoration-2"></div>
          <div className="decoration decoration-3"></div>
        </div>

        <div className="register-wrapper">
          <div className="register-card">
            <div className="register-header">
              <div className="avatar-container">
                <FaUserPlus className="avatar-icon" />
              </div>
              <h1 className="register-title">Crear Cuenta</h1>
              <p className="register-subtitle">Regístrate para comenzar</p>
            </div>

            <form
              className="register-form"
              onSubmit={(e) => {
                e.preventDefault();
                if (password !== confirmPassword) {
                  setPasswordError("Las contraseñas no coinciden.");
                  return;
                }

                setPasswordError(""); // limpia el mensaje si ya coincide
                registerUser(
                  username,
                  email,
                  password,
                  firstname,
                  lastName,
                  phoneNumber
                );
              }}
            >
              {/* Campo de usuario */}
              <div className="input-group">
                <div className="input-icon">
                  <FaUser className="icon" />
                </div>
                <input
                  type="text"
                  placeholder="Nombre de usuario"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="form-input"
                  required
                />
              </div>

              {/* Campo de nombre */}
              <div className="input-group">
                <div className="input-icon">
                  <FaUser className="icon" />
                </div>
                <input
                  type="text"
                  placeholder="Nombre"
                  value={firstname}
                  onChange={(e) => setFirstname(e.target.value)}
                  className="form-input"
                  required
                />
              </div>

              {/* Campo de apellidos */}
              <div className="input-group">
                <div className="input-icon">
                  <FaUser className="icon" />
                </div>
                <input
                  type="text"
                  placeholder="Apellidos"
                  value={lastName}
                  onChange={(e) => setLastName(e.target.value)}
                  className="form-input"
                  required
                />
              </div>

              {/* Campo de teléfono */}
              <div className="input-group">
                <div className="input-icon">
                  <FaPhone className="icon" />
                </div>
                <input
                  type="tel"
                  maxLength={10}
                  minLength={10}
                  pattern="\d{10}"
                  placeholder="Número de teléfono"
                  value={phoneNumber}
                  onChange={(e) => {
                    // Solo permitir números
                    const valor = e.target.value;
                    if (/^\d*$/.test(valor)) {
                      setPhoneNumber(valor);
                    }
                  }}
                  onInvalid={(e) => {
                    e.target.setCustomValidity(
                      "El número de teléfono debe contener 10 dígitos"
                    );
                  }}
                  onInput={(e) => {
                    e.target.setCustomValidity("");
                  }}
                  className="form-input"
                />
              </div>

              {/* Campo de email */}
              <div className="input-group">
                <div className="input-icon">
                  <FaEnvelope className="icon" />
                </div>
                <input
                  type="email"
                  placeholder="Correo electrónico"
                  value={email}
                  onChange={(e) => {
                    setEmail(e.target.value);
                    setEmailError("");
                  }}
                  className="form-input"
                  required
                />
              </div>
              {emailError && <p className="register-error">{emailError}</p>}

              {/* Campo de contraseña */}
              <div className="input-group">
                <div className="input-icon">
                  <FaLock className="icon" />
                </div>
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="Contraseña"
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setPasswordTouched(true);
                  }}
                  className="form-input password-input"
                  minLength={8}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="password-toggle"
                >
                  {showPassword ? <FaEyeSlash className="toggle-icon" /> : <FaEye className="toggle-icon" />}
                </button>
              </div>

              {passwordTouched && (
                <div className="text-sm text-gray-700 mb-3 mt-2 space-y-1">
                  {passwordRequirements.map((req, idx) => {
                    const passed = req.test(password);
                    return (
                      <p key={idx} className={`flex items-center gap-2 ${passed ? "text-green-600" : "text-red-500"}`}>
                        {passed ? "✔" : "✖"} {req.label}
                      </p>
                    );
                  })}
                </div>
              )}

              {/* Campo de confirmar contraseña */}
              <div className="input-group">
                <div className="input-icon">
                  <FaLock className="icon" />
                </div>
                <input
                  type={showConfirmPassword ? "text" : "password"}
                  placeholder="Confirmar contraseña"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className={`form-input password-input ${confirmPassword && password !== confirmPassword ? "ring-2 ring-red-500" : ""
                    }`}
                  minLength={8}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="password-toggle"
                >
                  {showConfirmPassword ? <FaEyeSlash className="toggle-icon" /> : <FaEye className="toggle-icon" />}
                </button>
              </div>

              {confirmPassword && password !== confirmPassword && (
                <p className="register-error">Las contraseñas no coinciden.</p>
              )}

              {passwordError && (
                <p className="register-error">{passwordError}</p>
              )}

              {errorMsg && (
                <div className="toast-error">
                  <FaExclamationTriangle style={{ marginRight: "0.5rem" }} />
                  {errorMsg}
                </div>
              )}
              {successMsg && (
                <div className="toast-success">
                  <FaCheckCircle style={{ marginRight: "0.5rem" }} />
                  {successMsg}
                </div>
              )}

              {/* Botón de registro */}
              <button
                type="submit"
                disabled={isLoading}
                className="submit-button"
              >
                {isLoading ? (
                  <div className="loading-container">
                    <div className="spinner"></div>
                    Procesando...
                  </div>
                ) : (
                  "Crear Cuenta"
                )}
              </button>
            </form>

            <div className="register-footer">
              <p className="register-footer-text">
                ¿Ya tienes una cuenta?{" "}
                <a href="/login" className="login-link">
                  Inicia Sesión
                </a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Register;
