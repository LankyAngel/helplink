import React, { useState, useEffect } from "react";
import {FaUser,FaCalendarAlt,FaComment, FaStar,FaThumbsUp,FaCheckCircle,FaExclamationTriangle
} from "react-icons/fa";
import "../assets/style/EventDetail.css";
import NavarCompleto from "../Components/NavarCompleto";
import { useParams,useNavigate } from "react-router-dom";
import { useAuth } from "../contex/AuthProvider";
import axios from "axios";
import { getUserInfo } from "../services/authService";


const AddFeedback = () => {
  const apiURL = process.env.REACT_APP_API_URL;
  const _apiURL = `${apiURL}/feedback/`;
  const { access, org_code, isAuthenticated } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const { id } = useParams();
  const navigate = useNavigate();
  const [errorMsg, setErrorMsg] = useState("");
  const [successMsg, setSuccessMsg] = useState("");

  const getUserId = async () => {
      if (isAuthenticated) {
        const data = await getUserInfo();
        const username = localStorage.getItem("username");
        if (!username) return null;
        const user = data.find((u) => u.username === username);
        return user?.id || null;
      }
      return null;
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const StarRating = ({ rating, onRatingChange }) => {
  return (
    <div style={{ display: "flex", gap: "5px", cursor: "pointer" }}>
      {[1, 2, 3, 4, 5].map((value) => (
        <FaStar
          key={value}
          size={24}
          onClick={() => onRatingChange(value)}
          color={value <= rating ? "#ffc107" : "#e4e5e9"} // amarillo o gris
        />
      ))}
    </div>
  );
};


  const [formData, setFormData] = useState({
    comment: "",
    rating: "",
    user: "",
    event: "",
  });

  const submitForm = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const userId = await getUserId();
      const eventId = id;
      if (!userId) throw new Error("No se pudo obtener el ID del usuario");

      // Actualizar el formData con el user ID
      const completeFormData = {
        ...formData,
        user: userId,
        event: eventId,
      };

      const formDataToSend = new FormData();
      Object.entries(completeFormData).forEach(([key, value]) =>
        formDataToSend.append(key, value)
      );

      const resInsert = await fetch(_apiURL, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${access}`,
        },
        body: formDataToSend,
      });

      if (!resInsert.ok) throw new Error("Error al insertar feedback");

      //alert("Feedback enviado correctamente");
      setSuccessMsg("¡Has calificado correctamente al evento!");
      setTimeout(() => {
        setSuccessMsg("");
        navigate("/profile");
      }, 2000);
      //navigate("/profile");
      setFormData({
        comment: "",
        rating: "",
        user: "",
        event: 11,
      });
    } catch (error) {
      console.error("Error:", error);
      setErrorMsg(error.message);
      setTimeout(() => setErrorMsg(""), 6000);
    } finally {
      setIsLoading(false);
    }
  };


  return (
    <>
      <NavarCompleto />
      <div className="register-container">
        <div className="background-decorations">
          <div className="decoration decoration-1"></div>
          <div className="decoration decoration-2"></div>
          <div className="decoration decoration-3"></div>
        </div>

        <div className="register-wrapper">
          <div className="register-card">
            <div className="register-header">
              <div className="avatar-container">
                <FaCalendarAlt className="avatar-icon" />
              </div>
              <h1 className="register-title">Dar feedback</h1>
              <p className="register-subtitle"></p>
            </div>

            <form className="register-form" onSubmit={submitForm}>
              {/* Campo de comentarios */}
              <div className="input-group">
                <div className="input-icon">
                  <FaComment className="icon" />
                </div>
                <input
                  type="text"
                  name="comment"
                  placeholder="Comentarios"
                  value={formData.comment}
                  onChange={handleInputChange}
                  className="form-input"
                  //required
                />
              </div>

              {/* Campo de rating */}
              <div className="input-group">
                <div className="input-icon">
                  <FaThumbsUp className="icon" />
                </div>
                {/* <label htmlFor="rating-stars">Rating</label> */}
                <div id="rating-stars" className="form-input">
                  <StarRating
                    rating={formData.rating}
                    onRatingChange={(value) =>
                      setFormData((prevData) => ({
                        ...prevData,
                        rating: value,
                      }))
                    }
                    required
                  />
                  
                </div>
              </div>

              {errorMsg && (
                <div className="toast-error">
                  <FaExclamationTriangle style={{ marginRight: "0.5rem" }} />
                  {errorMsg}
                </div>
              )}
              {successMsg && (
                <div className="toast-success">
                  <FaCheckCircle style={{ marginRight: "0.5rem" }} />
                  {successMsg}
                </div>
              )}


              {/* Botón */}
              <button
                type="submit"
                disabled={isLoading}
                className="submit-button"
              >
                {isLoading ? (
                  <div className="loading-container">
                    <div className="spinner"></div>
                    Procesando...
                  </div>
                ) : (
                  "Enviar"
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default AddFeedback;
