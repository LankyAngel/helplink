import React, { useState, useEffect } from "react";
import {
  FaUser, FaClock, FaImage, FaCalendarAlt, FaRegStickyNote,
  FaStore, FaUsers, FaTags, FaExclamationTriangle, FaCheckCircle,
  FaMapMarkerAlt, FaCity, FaGlobe, FaMailBulk, FaHourglassEnd, FaEdit
} from "react-icons/fa";
import "../assets/style/EditEvent.css";
import NavarCompleto from "../Components/NavarCompleto";
import { useNavigate, useParams } from "react-router-dom";
import { useAuth } from "../contex/AuthProvider";

const EditEvent = () => {
  const { access, org_code } = useAuth();
  const { eventId } = useParams();
  const navigate = useNavigate();
  const apiURL = process.env.REACT_APP_API_URL;
  const _apiURLUpdate = `${apiURL}/events/${eventId}/`;
  const _apiURLGet = `${apiURL}/events/${eventId}/`;
  const _apiURLGetBranches = `${apiURL}/branches/`;
  const _apiURLEVENTCATEGORIES = `${apiURL}/event-categories/`;
  const _apiURLGetCategories = `${apiURL}/categories/`;
  const _apiInsertLocationEvent = `${apiURL}/event-locations/`;
  const _apiUpdateLocationEvent = `${apiURL}/event-locations/`;
  const _apiGetLocationEvent = `${apiURL}/events/${eventId}/location/`;

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    capacity: "",
    image: null,
    event_date: "",
    start_time: "",
    end_time: "",
    status: "published",
    branch: "",
  });

  const [originalData, setOriginalData] = useState(null);
  const [currentImageUrl, setCurrentImageUrl] = useState(null);
  const [sucursales, setSucursales] = useState([]);
  const [categorias, setCategorias] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("");
  const [originalCategory, setOriginalCategory] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingData, setIsLoadingData] = useState(true);
  const [errorMsg, setErrorMsg] = useState("");
  const [successMsg, setSuccessMsg] = useState("");
  const today = new Date().toISOString().split("T")[0];

  // Estados para búsqueda de direcciones
  const [street, setStreet] = useState('');
  const [city, setCity] = useState('Tijuana');
  const [stateName, setStateName] = useState('Baja California');
  const [postalcode, setPostalcode] = useState('');
  const [country, setCountry] = useState('Mexico');
  const [searchResults, setSearchResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [selectedAddress, setSelectedAddress] = useState(null);
  const [currentLocation, setCurrentLocation] = useState(null);
  const _apiSendNoticationTopic = `${apiURL}/notifications/send/topic/`;

  // Cargar datos del evento
  useEffect(() => {
    if (!org_code || !eventId) return;

    const fetchEventData = async () => {
      setIsLoadingData(true);
      try {
        // Obtener datos del evento
        const eventResponse = await fetch(_apiURLGet, {
          headers: { Authorization: `Bearer ${access}` },
        });
        if (!eventResponse.ok) throw new Error("Error al cargar el evento");
        const eventData = await eventResponse.json();
        
        setOriginalData(eventData);
        setFormData({
          title: eventData.title || "",
          description: eventData.description || "",
          capacity: eventData.capacity || "",
          image: null, // No establecer la imagen existente aquí
          event_date: eventData.event_date || "",
          start_time: eventData.start_time || "",
          end_time: eventData.end_time || "",
          status: eventData.status || "published",
          branch: eventData.branch || "",
        });
        
        if (eventData.image) {
          setCurrentImageUrl(eventData.image);
        }

        // Obtener categoría actual del evento
        try {
          const categoryResponse = await fetch(`${apiURL}/event/${eventId}/category/`, {
            headers: { Authorization: `Bearer ${access}` },
          });
          if (categoryResponse.ok) {
            const categoryData = await categoryResponse.json();
            if (categoryData && categoryData.length > 0) {
              setSelectedCategory(categoryData[0].category.id?.toString() || "");
              setOriginalCategory(categoryData[0].category.id?.toString() || "");
            }
          }
        } catch (error) {
          console.warn("No se pudo obtener la categoría actual:", error);
        }

        // Obtener ubicación actual del evento
        try {
          const locationResponse = await fetch(_apiGetLocationEvent, {
            headers: { Authorization: `Bearer ${access}` },
          });
          if (locationResponse.ok) {
            const locationData = await locationResponse.json();
            if (locationData && locationData.length > 0) {
              setCurrentLocation(locationData[0]);
              setSelectedAddress({
                display_name: locationData[0].address,
                lat: locationData[0].latitude,
                lon: locationData[0].longitude,
                place_id: `current_${locationData[0].id}`
              });
            }
          }
        } catch (error) {
          console.warn("No se pudo obtener la ubicación actual:", error);
        }

      } catch (error) {
        console.error("Error al cargar datos del evento:", error);
        setErrorMsg("No se pudieron cargar los datos del evento.");
      } finally {
        setIsLoadingData(false);
      }
    };

    fetchEventData();
  }, [eventId, org_code, access, _apiURLGet, apiURL, _apiGetLocationEvent]);

  // Cargar sucursales
  useEffect(() => {
    if (!org_code) return;

    const fetchBranches = async () => {
      try {
        const response = await fetch(_apiURLGetBranches, {
          headers: { Authorization: `Bearer ${access}` },
        });
        if (!response.ok) throw new Error("Error al cargar sucursales");
        const data = await response.json();
        const sucursalesFiltradas = data.filter(
          (sucursal) => sucursal.organization === Number(org_code)
        );
        setSucursales(sucursalesFiltradas);
      } catch (error) {
        console.error("Error al cargar las sucursales:", error);
        setErrorMsg("No se pudieron cargar las sucursales.");
      }
    };

    fetchBranches();
  }, [org_code, access, _apiURLGetBranches]);

  // Cargar categorías
  useEffect(() => {
    const fetchCategorias = async () => {
      try {
        const res = await fetch(_apiURLGetCategories);
        if (!res.ok) throw new Error("Error al obtener categorías");
        const data = await res.json();
        setCategorias(data);
      } catch (error) {
        console.error("Error al cargar categorías:", error);
        setErrorMsg("No se pudieron cargar las categorías.");
      }
    };

    fetchCategorias();
  }, [_apiURLGetCategories]);

  useEffect(() => {
    // Obtener ubicación del evento si existe eventId
    if (!eventId) return;

    const fetchEventLocation = async () => {
      try {
        const res = await fetch(`${apiURL}/events/${eventId}/location/`, {
          headers: { Authorization: `Bearer ${access}` }
        });
        if (!res.ok) throw new Error("No se pudo obtener la ubicación del evento");
        const data = await res.json();
        setSelectedAddress({
          display_name: data.address,
          lat: data.latitude,
          lon: data.longitude,
          place_id: 'event-location',
        });
      } catch (error) {
        console.error(error);
        setErrorMsg(error.message);
      }
    };

    fetchEventLocation();
  }, [eventId, access, apiURL]);

  const handleInputChange = (e) => {
    const { name, value, files } = e.target;
    if (name === "image") {
      setFormData({ ...formData, [name]: files[0] });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const submitEventForm = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMsg("");
    setSuccessMsg("");

    try {
      // Paso 1: Actualizar datos del evento
      const formDataEvento = new FormData();
      Object.entries(formData).forEach(([key, value]) => {
        if (key === "image" && value === null) {
          return;
        }
        formDataEvento.append(key, value);
      });

      const resUpdate = await fetch(_apiURLUpdate, {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${access}`
        },
        body: formDataEvento,
      });

      if (!resUpdate.ok) {
        const errorData = await resUpdate.json();
        throw new Error(errorData.detail || `Error al actualizar el evento: ${resUpdate.statusText}`);
      }

      const eventoActualizado = await resUpdate.json();

      // Paso 2: Actualizar categoría si cambió
      if (selectedCategory !== originalCategory) {
        // Primero eliminar la relación anterior si existe
        if (originalCategory) {
          try {
             const url = `${_apiURLEVENTCATEGORIES}delete/${eventId}/`
            await fetch(url, {
              method: "DELETE",
              headers: {
                Authorization: `Bearer ${access}`,
              },
            });
          } catch (error) {
            console.warn("No se pudo eliminar la categoría anterior:", error);
          }
        }

        // Crear nueva relación
        if (selectedCategory) {
          const bodyRelacion = {
            event_id: parseInt(eventId),
            category_id: parseInt(selectedCategory),
          };

          const resRelacion = await fetch(_apiURLEVENTCATEGORIES, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${access}`,
            },
            body: JSON.stringify(bodyRelacion),
          });

          if (!resRelacion.ok) {
            const errorData = await resRelacion.json();
            throw new Error(errorData.detail || "Error al actualizar la categoría.");
          }
        }
      }

      // Paso 3: Actualizar ubicación del evento
      if (selectedAddress) {
        const bodyLocationEvent = {
          event_id: parseInt(eventId),
          address: selectedAddress.display_name,
          latitude: selectedAddress.lat,
          longitude: selectedAddress.lon,
        };

        let locationResponse;
        if (currentLocation) {
          // Actualizar ubicación existente
          locationResponse = await fetch(`${_apiUpdateLocationEvent}${currentLocation.id}/`, {
            method: "PUT",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${access}`,
            },
            body: JSON.stringify(bodyLocationEvent),
          });
        } else {
          // Crear nueva ubicación
          locationResponse = await fetch(_apiInsertLocationEvent, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${access}`,
            },
            body: JSON.stringify(bodyLocationEvent),
          });
        }

        if (!locationResponse.ok) {
          const errorData = await locationResponse.json();
          console.warn("Advertencia: El evento se actualizó, pero falló la actualización de ubicación.", errorData);
        }
      } else if (currentLocation) {
        // Eliminar ubicación si se deseleccionó
        try {
          await fetch(`${_apiUpdateLocationEvent}${currentLocation.id}/`, {
            method: "DELETE",
            headers: {
              Authorization: `Bearer ${access}`,
            },
          });
        } catch (error) {
          console.warn("No se pudo eliminar la ubicación:", error);
        }
      }

      const topicName = `${org_code}OrgTopic-Event${eventoActualizado.id}`;

      const notificationPayload = {
        topic: topicName,
        title: eventoActualizado.title,
        body: `¡El evento al que estabas registrado fue actualizado! "${eventoActualizado.title}". Revisa los detalles para ver los cambios.`,
        path: `/events/${eventoActualizado.id}`
      };

      const resNotification = await fetch(_apiSendNoticationTopic, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${access}`,
        },
        body: JSON.stringify(notificationPayload),
      });

      if (!resNotification.ok) {
        const errorData = await resNotification.json();
        console.warn("Advertencia: El evento se actualizó, pero la notificación falló.", errorData);
        setErrorMsg("Evento actualizado, pero falló el envío de la notificación.");
      }

      setSuccessMsg("¡Evento actualizado exitosamente!");
      setTimeout(() => {
        navigate("/organizationAdminPanel/events");
      }, 2000);

    } catch (error) {
      console.error("Error detallado en la actualización del evento:", error);
      setErrorMsg(error.message || "Ocurrió un error desconocido. Inténtalo de nuevo.");
      setTimeout(() => setErrorMsg(""), 8000);
    } finally {
      setIsLoading(false);
    }
  };

  // Manejador para búsqueda de dirección
  const handleAddressSearch = async (e) => {
    e.preventDefault();
    setIsSearching(true);
    const params = new URLSearchParams({
      street, city, state: stateName, postalcode, country,
      format: 'jsonv2',
      addressdetails: '1',
      limit: '5'
    });

    const url = `https://nominatim.openstreetmap.org/search?${params.toString()}`;
    try {
      const resp = await fetch(url, {
        headers: { 'User-Agent': 'MiAppDeEventos/1.0 (tu-email@ejemplo.com)' }
      });
      if (!resp.ok) throw new Error('La respuesta de la red de Nominatim no fue correcta.');
      const data = await resp.json();
      setSearchResults(data);
    } catch (error) {
      console.error("Error al buscar en Nominatim:", error);
      setErrorMsg("Error al buscar la dirección. Intente de nuevo.");
    } finally {
      setIsSearching(false);
    }
  };

  const handleAddressSelect = (address) => {
    setSelectedAddress(address);
    setStreet('');
    setCity('Tijuana');
    setStateName('Baja California');
    setPostalcode('');
    setCountry('Mexico');
    setSearchResults([]);
  };

  const handleRemoveCurrentLocation = () => {
    setSelectedAddress(null);
    setCurrentLocation(null);
  };

  if (isLoadingData) {
    return (
      <>
        <NavarCompleto />
        <div className="edit-event-container">
          <div className="edit-event-loading">
            <div className="spinner"></div>
            <p>Cargando datos del evento...</p>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <NavarCompleto />
      <div className="edit-event-container">
        <div className="edit-event-background-decorations">
          <div className="edit-event-decoration edit-event-decoration-1"></div>
          <div className="edit-event-decoration edit-event-decoration-2"></div>
          <div className="edit-event-decoration edit-event-decoration-3"></div>
        </div>

        <div className="edit-event-wrapper">
          <div className="edit-event-card">
            <div className="edit-event-header">
              <div className="edit-event-avatar-container">
                <FaEdit className="edit-event-avatar-icon" />
              </div>
              <h1 className="edit-event-title">Editar Evento</h1>
              <p className="edit-event-subtitle">Modifica los datos del evento</p>
            </div>

            <form className="edit-event-form" onSubmit={submitEventForm}>
              <div className="edit-event-input-group">
                <div className="edit-event-input-icon"><FaUser className="edit-event-icon" /></div>
                <input 
                  type="text" 
                  name="title" 
                  placeholder="Nombre del Evento" 
                  value={formData.title} 
                  onChange={handleInputChange} 
                  className="edit-event-form-input" 
                  required 
                />
              </div>

              <div className="edit-event-input-group">
                <div className="edit-event-input-icon"><FaRegStickyNote className="edit-event-icon" /></div>
                <input 
                  type="text" 
                  name="description" 
                  placeholder="Descripción" 
                  value={formData.description} 
                  onChange={handleInputChange} 
                  className="edit-event-form-input" 
                  required 
                />
              </div>

              <div className="edit-event-input-group">
                <div className="edit-event-input-icon"><FaUsers className="edit-event-icon" /></div>
                <input 
                  type="number" 
                  name="capacity" 
                  placeholder="Límite de voluntarios" 
                  value={formData.capacity} 
                  onChange={handleInputChange} 
                  className="edit-event-form-input" 
                  min="1" 
                  required 
                />
              </div>

              <div className="edit-event-image-section">
                <p className="edit-event-image-title">Imagen del evento</p>
                {currentImageUrl && (
                  <div className="edit-event-current-image">
                    <img src={currentImageUrl} alt="Imagen actual" />
                    <p>Imagen actual (deja vacío para mantener)</p>
                  </div>
                )}
                <div className="edit-event-input-group">
                  <div className="edit-event-input-icon"><FaImage className="edit-event-icon" /></div>
                  <input 
                    type="file" 
                    name="image" 
                    accept="image/*" 
                    onChange={handleInputChange} 
                    className="edit-event-form-input" 
                  />
                </div>
              </div>

              <div className="edit-event-input-group">
                <div className="edit-event-input-icon"><FaCalendarAlt className="edit-event-icon" /></div>
                <input 
                  type="date" 
                  name="event_date" 
                  min={today} 
                  value={formData.event_date} 
                  onChange={handleInputChange} 
                  className="edit-event-form-input" 
                  required 
                />
              </div>

              <div className="edit-event-input-group">
                <div className="edit-event-input-icon"><FaClock className="edit-event-icon" /></div>
                <input 
                  type="time" 
                  name="start_time" 
                  value={formData.start_time} 
                  onChange={handleInputChange} 
                  className="edit-event-form-input" 
                  required 
                />
              </div>

              <div className="edit-event-input-group">
                <div className="edit-event-input-icon"><FaHourglassEnd className="edit-event-icon" /></div>
                <input
                  type="time"
                  name="end_time"
                  value={formData.end_time}
                  onChange={handleInputChange}
                  className="edit-event-form-input"
                  required
                />
              </div>

              <div className="edit-event-input-group">
                <div className="edit-event-input-icon"><FaStore className="edit-event-icon" /></div>
                <select 
                  name="branch" 
                  value={formData.branch} 
                  onChange={handleInputChange} 
                  className="edit-event-form-input" 
                  required
                >
                  <option value="">-- Selecciona una sucursal --</option>
                  {sucursales.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} - {s.street}, {s.city}
                    </option>
                  ))}
                </select>
              </div>

              <div className="edit-event-input-group">
                <div className="edit-event-input-icon"><FaTags className="edit-event-icon" /></div>
                <select 
                  name="category" 
                  value={selectedCategory} 
                  onChange={(e) => setSelectedCategory(e.target.value)} 
                  className="edit-event-form-input" 
                  required
                >
                  {categorias.map((cat) => (
                    <option key={cat.id} value={cat.id}>{cat.name}</option>
                  ))}
                </select>
              </div>

              {/* Sección de Búsqueda de Direcciones */}
              <div className="edit-event-address-section">
                <h3 className="edit-event-address-title">
                  <FaMapMarkerAlt />
                  Dirección Alternativa
                </h3>

                {/* Mostrar ubicación actual si existe */}
                {selectedAddress && (
                  <div className="edit-event-current-address">
                    <h4 className="edit-event-current-address-title">
                      <FaCheckCircle />
                      Dirección Actual:
                    </h4>
                    <p className="edit-event-current-address-text">
                      <strong>{selectedAddress.display_name}</strong><br/>
                      Coordenadas: {selectedAddress.lat}, {selectedAddress.lon}
                    </p>
                    <button
                      type="button"
                      onClick={handleRemoveCurrentLocation}
                      className="edit-event-remove-address-btn"
                    >
                      Eliminar Dirección
                    </button>
                  </div>
                )}

                <div className="edit-event-address-search">
                  <div className="edit-event-input-group">
                    <div className="edit-event-input-icon"><FaMapMarkerAlt className="edit-event-icon" /></div>
                    <input  
                      className="edit-event-form-input" 
                      placeholder="Calle #Num" 
                      value={street} 
                      onChange={e => setStreet(e.target.value)} 
                    />
                  </div>

                  <div className="edit-event-input-group">
                    <div className="edit-event-input-icon"><FaMailBulk className="edit-event-icon" /></div>
                    <input 
                      className="edit-event-form-input" 
                      placeholder="Código Postal" 
                      value={postalcode} 
                      onChange={e => setPostalcode(e.target.value)} 
                    />
                  </div>

                  <button 
                    type="button" 
                    onClick={handleAddressSearch} 
                    disabled={isSearching} 
                    className="edit-event-search-button"
                  >
                    {isSearching ? (
                      <>
                        <div className="spinner"></div>
                        <span>Buscando...</span>
                      </>
                    ) : (
                      "Buscar Nueva Dirección"
                    )}
                  </button>
                </div>

                {/* Resultados de búsqueda */}
                {searchResults.length > 0 && (
                  <div className="edit-event-search-results">
                    <h4 className="edit-event-search-results-title">Selecciona una dirección:</h4>
                    <div className="edit-event-search-results-list">
                      {searchResults.map(item => (
                        <button
                          key={item.place_id}
                          className="edit-event-search-result-item"
                          onClick={() => handleAddressSelect(item)}
                        >
                          <strong className="edit-event-search-result-name">
                            {item.display_name}
                          </strong>
                          <small className="edit-event-search-result-details">
                            Lat: {item.lat}, Lon: {item.lon} | {item.category} - {item.type}
                          </small>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {errorMsg && (
                <div className="edit-event-toast-error">
                  <FaExclamationTriangle />
                  {errorMsg}
                </div>
              )}

              {successMsg && (
                <div className="edit-event-toast-success">
                  <FaCheckCircle />
                  {successMsg}
                </div>
              )}

              <div className="edit-event-form-actions">
                <button 
                  type="button" 
                  onClick={() => navigate("/organizationAdminPanel/events")}
                  className="edit-event-cancel-button"
                >
                  Cancelar
                </button>
                <button 
                  type="submit" 
                  disabled={isLoading} 
                  className="edit-event-submit-button"
                >
                  {isLoading ? (
                    <>
                      <div className="spinner"></div>
                      <span>Actualizando...</span>
                    </>
                  ) : (
                    "Actualizar Evento"
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default EditEvent;