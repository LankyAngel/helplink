// PasswordResetRequest.js
import React, { useState } from "react";
import { FaEnvelope, FaExclamationTriangle } from "react-icons/fa";
import "../assets/style/Login.css";
import NavarCompleto from "../Components/NavarCompleto";

const PasswordResetRequest = () => {
  const [email, setEmail] = useState("");
  const [isSending, setIsSending] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [successMsg, setSuccessMsg] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSending(true);
    setErrorMsg("");
    setSuccessMsg("");

    try {
      const response = await fetch(`${process.env.REACT_APP_API_URL}/password_reset/`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ email }),
      });

      if (!response.ok) {
        throw new Error("No se pudo enviar el correo de recuperación.");
      }

      setSuccessMsg("Se ha enviado un correo con instrucciones para recuperar tu contraseña.");
    } catch (error) {
      console.error("Error al enviar solicitud:", error);
      setErrorMsg("Hubo un problema al procesar tu solicitud. Verifica tu correo e intenta de nuevo.");
    } finally {
      setIsSending(false);
    }
  };

  return (
    <>
      <NavarCompleto />
      <div className="login-container">
        <div className="background-decorations">
          <div className="decoration decoration-1"></div>
          <div className="decoration decoration-2"></div>
          <div className="decoration decoration-3"></div>
        </div>

        <div className="login-wrapper">
          <div className="login-card">
            <div className="login-header">
              <div className="avatar-container">
                <FaEnvelope className="avatar-icon" />
              </div>
              <h1 className="login-title">Recuperar Contraseña</h1>
              <p className="login-subtitle">
                Ingresa tu correo y te enviaremos instrucciones
              </p>
            </div>

            <form className="login-form" onSubmit={handleSubmit}>
              {errorMsg && (
                <div className="error-container">
                  <div className="error-icon">
                    <FaExclamationTriangle className="error-icon-svg" />
                  </div>
                  <p className="error-message">{errorMsg}</p>
                </div>
              )}

              {successMsg && (
                <div className="success-container">
                  <p className="success-message">{successMsg}</p>
                </div>
              )}

              <div className="input-group">
                <div className="input-icon">
                  <FaEnvelope className="icon" />
                </div>
                <input
                  type="email"
                  name="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Correo electrónico"
                  className="form-input"
                  required
                />
              </div>

              <button type="submit" disabled={isSending} className="submit-button">
                {isSending ? (
                  <div className="loading-container">
                    <div className="spinner"></div>
                    Enviando...
                  </div>
                ) : (
                  "Enviar correo"
                )}
              </button>
            </form>

            <div className="form-options" style={{ justifyContent: "center", marginTop: "1rem" }}>
              <a href="/login" className="forgot-password">Volver al inicio de sesión</a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default PasswordResetRequest;
