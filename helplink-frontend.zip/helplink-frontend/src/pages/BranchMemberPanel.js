import React, { useState, useEffect } from "react";
import "../assets/style/BranchMemberPanel.css";
import { useAuth } from "../contex/AuthProvider";
import { useNavigate } from "react-router-dom";
import NavarCompleto from "../Components/NavarCompleto";
import { getUserInfo } from "../services/authService";
import {
  FaUsers,
  FaCalendarAlt,
  FaUserCog,
  FaChartBar,
  FaClipboardList,
  FaBuilding,
  FaEye,
  FaMapMarkerAlt,
  FaStar,
  FaHandsHelping,
  FaCheckCircle,
  FaClock,
  FaExclamationTriangle
} from "react-icons/fa";
import {
  getBranchEvents,
  getBranchMembers,
  getVolunteerEvents,
} from "../services/api";

const BranchMemberPanel = () => {
  const [isLoaded, setIsLoaded] = useState(false);
  const { user, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [branchInfo, setBranchInfo] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [activeTab, setActiveTab] = useState('dashboard');

  // Estado para almacenar las estadísticas de la sucursal
  const [branchStats, setBranchStats] = useState({
    branchEvents: 0,
    branchMembers: 0,
    myParticipations: 0,
    completedEvents: 0,
    branchRating: 4.6,
  });

  // Estado para datos detallados
  const [recentEvents, setRecentEvents] = useState([]);
  const [branchMembers, setBranchMembers] = useState([]);
  const [myActivities, setMyActivities] = useState([]);

  // Función para obtener información de la sucursal y estadísticas
  const fetchBranchData = async () => {
    try {
      // Obtener información del usuario
      const userData = await getUserInfo();
      const userInfo = Array.isArray(userData)
        ? userData.find(u => u.username === localStorage.getItem("username"))
        : userData;

      setCurrentUser(userInfo);

      if (userInfo && userInfo.branch) {
        setBranchInfo(userInfo.branch);

        // Obtener datos específicos
        const [branchEventsData, branchMembersData, volunteerEventsData] = await Promise.all([
          getBranchEvents(userInfo.branch.id),
          getBranchMembers(userInfo.branch.id),
          getVolunteerEvents(),
        ]);

        // Eventos activos
        const activeBranchEvents = branchEventsData?.filter(
          (event) => event.status === "published"
        ).length || 0;

        //FILTRO POR ORGANIZACIÓN, NO SUCURSAL
        const filteredMembers = branchMembersData?.filter(
          (member) => member.user?.organization?.id === userInfo.organization?.id
        );
        const branchMembersCount = filteredMembers?.length || 0;

        // Mis participaciones
        const myParticipationsCount = volunteerEventsData?.filter(
          (ve) => ve.user_id === userInfo.id && branchEventsData?.some(be => be.id === ve.event_id)
        ).length || 0;

        // Eventos completados
        const completedEventsCount = branchEventsData?.filter(
          (event) => event.status === "completed"
        ).length || 0;

        setBranchStats({
          branchEvents: activeBranchEvents,
          branchMembers: branchMembersCount,
          myParticipations: myParticipationsCount,
          completedEvents: completedEventsCount,
          branchRating: 4.6,
        });

        // Eventos recientes
        const recentBranchEvents = branchEventsData
          ?.sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
          .slice(0, 5) || [];

        setRecentEvents(recentBranchEvents);
        setBranchMembers(filteredMembers || []);

        // Mis actividades
        const myRecentActivities = volunteerEventsData
          ?.filter(ve => ve.user_id === userInfo.id)
          .slice(0, 4) || [];

        setMyActivities(myRecentActivities);
      }

    } catch (error) {
      console.error("Error al cargar los datos de la sucursal:", error);
    }
  };


  useEffect(() => {
    setIsLoaded(true);
    fetchBranchData();
  }, [user]);

  // Navegación
  const goViewEvents = () => navigate("/branch/events");
  const goViewMembers = () => navigate("/branch/members");
  const goEventDetails = (eventId) => navigate(`/event/${eventId}`);

  const renderDashboard = () => (
    <div className="member-dashboard">
      {/* Estadísticas principales */}
      <div className="member-stats-grid">
        <div className="member-stat-card primary">
          <div className="stat-icon">
            <FaCalendarAlt />
          </div>
          <div className="stat-content">
            <div className="stat-number">{branchStats.branchEvents}</div>
            <div className="stat-label">Eventos Disponibles</div>
            <div className="stat-change">De mi sucursal</div>
          </div>
        </div>

        <div className="member-stat-card secondary">
          <div className="stat-icon">
            <FaUsers />
          </div>
          <div className="stat-content">
            <div className="stat-number">{branchStats.branchMembers}</div>
            <div className="stat-label">Compañeros</div>
            <div className="stat-change">En la sucursal</div>
          </div>
        </div>

        <div className="member-stat-card success">
          <div className="stat-icon">
            <FaHandsHelping />
          </div>
          <div className="stat-content">
            <div className="stat-number">{branchStats.myParticipations}</div>
            <div className="stat-label">Mis Participaciones</div>
            <div className="stat-change">Eventos activos</div>
          </div>
        </div>
      </div>

      {/* Acciones rápidas para miembros */}
      <div className="member-actions-section">
        <h3>Acciones Disponibles</h3>
        <div className="member-actions-grid">
          <button className="member-action-btn primary" onClick={goViewEvents}>
            <FaEye />
            <span>Ver Eventos</span>
          </button>
          <button className="member-action-btn secondary" onClick={goViewMembers}>
            <FaUsers />
            <span>Ver Miembros</span>
          </button>
          <button className="member-action-btn tertiary">
            <FaClipboardList />
            <span>Mis Actividades</span>
          </button>
        </div>
      </div>

      {/* Contenido en grid */}
      <div className="member-content-grid">
        {/* Eventos disponibles */}
        <div className="content-card">
          <div className="card-header">
            <h3>Eventos de la Sucursal</h3>
            <button className="header-action" onClick={goViewEvents}>
              Ver todos
            </button>
          </div>
          <div className="events-container">
            {recentEvents.length > 0 ? (
              recentEvents.map((event, index) => (
                <button key={index} className="event-card" onClick={() => goEventDetails(event.id)}>
                  <div className="event-header">
                    <h4>{event.title || event.name || `Evento ${index + 1}`}</h4>
                    <span className={`event-status ${event.status || 'draft'}`}>
                      {event.status === 'published' ? 'Disponible' :
                        event.status === 'completed' ? 'Completado' : 'Próximamente'}
                    </span>
                  </div>
                  <p className="event-description">
                    {event.description || 'Descripción del evento de la sucursal'}
                  </p>
                  <div className="event-meta">
                    <span className="event-date">
                      <FaClock /> {event.date || event.start_date || 'Fecha por confirmar'}
                    </span>
                    <span className="event-location">
                      <FaMapMarkerAlt /> {event.location || 'Ubicación TBD'}
                    </span>
                  </div>
                </button>
              ))
            ) : (
              <div className="empty-state">
                <FaCalendarAlt />
                <p>No hay eventos disponibles</p>
                <p className="empty-subtitle">Los eventos aparecerán aquí cuando estén publicados</p>
              </div>
            )}
          </div>
        </div>

        {/* Miembros de la sucursal */}
        <div className="content-card">
          <div className="card-header">
            <h3>Miembros de la organización</h3>
            <button className="header-action" onClick={goViewMembers}>
              Ver todos
            </button>
          </div>
          <div className="members-container">
            {branchMembers.length > 0 ? (
              branchMembers.map((member, index) => (
                <div key={index} className="member-card">
                  <div className="member-avatar">
                    <img
                      src={member.avatar || `https://ui-avatars.com/api/?name=${member.first_name || `Miembro`} ${member.last_name || index + 1}&background=2563eb&color=fff`}
                      alt={`${member.first_name || 'Miembro'} ${member.last_name || index + 1}`}
                    />
                  </div>
                  <div className="member-info">
                    <h4>{`${member.first_name || 'Miembro'} ${member.last_name || index + 1}`}</h4>
                    <p>{member.role || 'Miembro'}</p>
                    <span className="member-status active">Activo</span>
                  </div>
                </div>
              ))
            ) : (
              <div className="empty-state">
                <FaUsers />
                <p>Cargando miembros...</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Mis actividades recientes */}
      <div className="content-card full-width">
        <div className="card-header">
          <h3>Mis Actividades Recientes</h3>
          <span className="activity-counter">{myActivities.length} actividades</span>
        </div>
        <div className="activities-container">
          {myActivities.length > 0 ? (
            myActivities.map((activity, index) => (
              <div key={index} className="activity-item">
                <div className="activity-icon">
                  <FaCheckCircle />
                </div>
                <div className="activity-content">
                  <h4>Participación en evento</h4>
                  <p>Te registraste para participar en un evento</p>
                  <span className="activity-date">
                    <FaClock /> {new Date().toLocaleDateString()}
                  </span>
                </div>
                <div className="activity-status">
                  <span className="status-badge active">Activa</span>
                </div>
              </div>
            ))
          ) : (
            <div className="empty-state">
              <FaHandsHelping />
              <p>Aún no tienes actividades</p>
              <p className="empty-subtitle">Únete a eventos para ver tu historial aquí</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );

  const renderProfile = () => (
    <div className="member-profile">
      <div className="profile-card">
        <div className="profile-header">
          <div className="profile-avatar">
            <img
              src={currentUser?.avatar || `https://ui-avatars.com/api/?name=${currentUser?.first_name || 'Usuario'}&background=2563eb&color=fff`}
              alt={currentUser?.first_name || 'Usuario'}
            />
          </div>
          <div className="profile-info">
            <h3>{`${currentUser?.first_name || 'Nombre'} ${currentUser?.last_name || 'Apellido'}`}</h3>
            <p>Miembro de Sucursal</p>
            <span className="profile-status">
              <FaCheckCircle /> Activo
            </span>
          </div>
        </div>

        <div className="profile-stats">
          <div className="profile-stat">
            <span className="stat-value">{branchStats.myParticipations}</span>
            <span className="stat-label">Participaciones</span>
          </div>
          <div className="profile-stat">
            <span className="stat-value">{branchStats.completedEvents}</span>
            <span className="stat-label">Eventos Completados</span>
          </div>
          <div className="profile-stat">
            <span className="stat-value">{branchStats.branchRating}</span>
            <span className="stat-label">Rating Sucursal</span>
          </div>
        </div>

        <div className="profile-branch">
          <h4>Mi Sucursal</h4>
          <div className="branch-info-display">
            <FaBuilding />
            <div>
              <h5>{branchInfo?.name || 'Nombre de la sucursal'}</h5>
              <p>
                <FaMapMarkerAlt />
                {branchInfo?.location || 'Ubicación de la sucursal'}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="branch-member-container">
      {/* Elementos decorativos */}
      <div className="bg-decoration">
        <div className="floating-shape shape-1"></div>
        <div className="floating-shape shape-2"></div>
        <div className="floating-shape shape-3"></div>
      </div>

      <NavarCompleto login={true} />

      <div className={`member-panel ${isLoaded ? "loaded" : ""}`}>
        {/* Header del miembro */}
        <div className="member-header">
          <div className="member-info-section">
            <div className="member-badge">
              <FaUsers />
              <span>Miembro de Sucursal</span>
            </div>
            <h1>
              Panel de <span className="text-primary">Miembro</span>
            </h1>
            <div className="member-details">
              <span className="member-branch">
                <FaBuilding />
                {branchInfo?.name || 'Mi Sucursal'}
              </span>
              <span className="member-location">
                <FaMapMarkerAlt />
                {branchInfo?.location || 'Ubicación de la sucursal'}
              </span>
              <span className="branch-rating">
                <FaStar />
                {branchStats.branchRating} Rating
              </span>
            </div>
          </div>
        </div>

        {/* Navegación */}
        <div className="member-nav">
          <button
            className={`branch-nav-tab ${activeTab === 'dashboard' ? 'active' : ''}`}
            onClick={() => setActiveTab('dashboard')}
          >
            <FaChartBar />
            <span>Dashboard</span>
          </button>
          <button
            className={`branch-nav-tab ${activeTab === 'profile' ? 'active' : ''}`}
            onClick={() => setActiveTab('profile')}
          >
            <FaUserCog />
            <span>Mi Perfil</span>
          </button>
        </div>

        {/* Contenido */}
        <div className="member-content">
          {!currentUser?.branch ? (
            <div className="no-branch">
              <FaExclamationTriangle />
              <h3>Sin Sucursal Asignada</h3>
              <p>No estás asignado a una sucursal. Contacta al administrador para obtener acceso.</p>
            </div>
          ) : (
            <>
              {activeTab === 'dashboard' && renderDashboard()}
              {activeTab === 'profile' && renderProfile()}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default BranchMemberPanel;