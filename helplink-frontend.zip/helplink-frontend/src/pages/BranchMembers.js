// src/pages/OrganizationMembers.js
import React, { useEffect, useState } from "react";
import {
  FaUsers,
  FaEdit,
  FaTrash,
  FaPlus,
  FaArrowLeft,
  FaEnvelope,
  FaUserTie,
  FaSearch,
  FaFilter,
  FaSort,
  FaEye,
  FaUserCheck,
  FaUserClock,
  FaUserShield,
  FaCrown,
  FaCalendarAlt,
  FaPhone,
  FaMapMarkerAlt,
} from "react-icons/fa";
import NavarCompleto from "../Components/NavarCompleto";
import { getUserInfo, deleteUser } from "../services/authService";
import { useNavigate } from "react-router-dom";
import "../assets/style/BranchMembers.css";

const BranchMembers = () => {
  const [members, setMembers] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [roleFilter, setRoleFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState("all");
  const [sortBy, setSortBy] = useState("name");
  const [sortOrder, setSortOrder] = useState("asc");
  const [showFilters, setShowFilters] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const navigate = useNavigate();

  const fetchMembers = async () => {
    try {
      const allUsers = await getUserInfo();
      const orgId = localStorage.getItem("organizationId");
      const orgMembers = allUsers.filter(
        (user) => user.organization?.id === parseInt(orgId)
      );
      setMembers(orgMembers);
      setTimeout(() => setIsLoaded(true), 300);
    } catch (error) {
      console.error("Error fetching members:", error);
      setMembers([]);
      setTimeout(() => setIsLoaded(true), 300);
    }
  };

  const handleDelete = async (userId) => {
    if (window.confirm("¿Eliminar este miembro permanentemente?")) {
      try {
        await deleteUser(userId);
        fetchMembers();
      } catch (error) {
        console.error("Error deleting member:", error);
      }
    }
  };

  const handleEdit = (userId) => {
    navigate(`/editMember/${userId}`);
  };

  const handleView = (userId) => {
    navigate(`/member/${userId}`);
  };

  const handleCreateMember = () => {
    navigate("/branchMemberPanel/add");
  };

  const handleBack = () => {
    navigate("/branchAdminPanel");
  };

  const formatDate = (dateString) => {
    if (!dateString) return "Sin fecha";
    const date = new Date(dateString);
    return date.toLocaleDateString("es-ES", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const getMemberRole = (member) => {
    const role = member.role || "Staff";
    const roleMap = {
      admin: { text: "Administrador", class: "admin", icon: FaCrown },
      manager: { text: "Gerente", class: "manager", icon: FaUserShield },
      coordinator: {
        text: "Coordinador",
        class: "coordinator",
        icon: FaUserTie,
      },
      volunteer: { text: "Voluntario", class: "volunteer", icon: FaUsers },
      member: { text: "Miembro", class: "member", icon: FaUserCheck },
    };

    const roleKey = role.toLowerCase();
    return roleMap[roleKey] || { text: role, class: "default", icon: FaUsers };
  };

  const getMemberStatus = (member) => {
    // Simulamos estado basado en datos disponibles
    const isActive = member.is_active !== false;
    const hasRecentActivity = member.last_login; // Si existe último login

    if (!isActive) {
      return { text: "Inactivo", class: "inactive", icon: FaUserClock };
    }
    if (hasRecentActivity) {
      return { text: "Activo", class: "active", icon: FaUserCheck };
    }
    return { text: "Pendiente", class: "pending", icon: FaUserClock };
  };

  const filteredAndSortedMembers = members
    .filter((member) => {
      const matchesSearch =
        `${member.first_name} ${member.last_name}`
          .toLowerCase()
          .includes(searchTerm.toLowerCase()) ||
        member.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (member.role &&
          member.role.toLowerCase().includes(searchTerm.toLowerCase()));

      const memberRole = getMemberRole(member);
      const matchesRole =
        roleFilter === "all" || memberRole.class === roleFilter;

      const memberStatus = getMemberStatus(member);
      const matchesStatus =
        statusFilter === "all" || memberStatus.class === statusFilter;

      return matchesSearch && matchesRole && matchesStatus;
    })
    .sort((a, b) => {
      let aValue, bValue;

      switch (sortBy) {
        case "name":
          aValue = `${a.first_name} ${a.last_name}`.toLowerCase();
          bValue = `${b.first_name} ${b.last_name}`.toLowerCase();
          break;
        case "email":
          aValue = a.email.toLowerCase();
          bValue = b.email.toLowerCase();
          break;
        case "role":
          aValue = a.role || "volunteer";
          bValue = b.role || "volunteer";
          break;
        case "joined":
          aValue = new Date(a.date_joined || a.created_at || 0);
          bValue = new Date(b.date_joined || b.created_at || 0);
          break;
        default:
          aValue = `${a.first_name} ${a.last_name}`.toLowerCase();
          bValue = `${b.first_name} ${b.last_name}`.toLowerCase();
      }

      if (sortOrder === "asc") {
        return aValue > bValue ? 1 : -1;
      } else {
        return aValue < bValue ? 1 : -1;
      }
    });

  const totalMembers = members.length;
  const activeMembers = members.filter(
    (m) => getMemberStatus(m).class === "active"
  ).length;
  const adminMembers = members.filter(
    (m) => getMemberRole(m).class === "admin"
  ).length;
  const volunteerMembers = members.filter(
    (m) => getMemberRole(m).class === "volunteer"
  ).length;

  const roles = [...new Set(members.map((m) => getMemberRole(m).class))];

  useEffect(() => {
    fetchMembers();
  }, []);

  return (
    <div className="organization-member-container">
      <div className="organization-member-bg-decoration">
        <div className="organization-member-floating-shape organization-member-shape-1"></div>
        <div className="organization-member-floating-shape organization-member-shape-2"></div>
        <div className="organization-member-floating-shape organization-member-shape-3"></div>
      </div>

      <NavarCompleto login={true} />

      <div className={`organization-member-panel ${isLoaded ? "loaded" : ""}`}>
        <div className="organization-member-header">
          <div className="organization-member-header-content">
            <button
              onClick={handleBack}
              className="organization-member-back-btn"
            >
              <FaArrowLeft />
              Volver al Panel
            </button>

            <div className="organization-member-title-section">
              <h1>
                <FaUsers className="organization-member-title-icon" />
                <span className="organization-member-text-primary">
                  Gestión de
                </span>
                <span className="organization-member-text-gradient">
                  Miembros
                </span>
              </h1>
              <p className="organization-member-subtitle">
                Administra todos los miembros de tu organización
              </p>
            </div>

            <button
              onClick={handleCreateMember}
              className="organization-member-create-btn"
            >
              <FaPlus />
              Nuevo Miembro
            </button>
          </div>
        </div>

        <div className="organization-member-stats-grid">
          <div className="organization-member-stat-card primary">
            <div className="organization-member-stat-icon">
              <FaUsers />
            </div>
            <div className="organization-member-stat-info">
              <div className="organization-member-stat-number">
                {totalMembers}
              </div>
              <div className="organization-member-stat-label">
                Total Miembros
              </div>
            </div>
          </div>

          <div className="organization-member-stat-card secondary">
            <div className="organization-member-stat-icon">
              <FaUserCheck />
            </div>
            <div className="organization-member-stat-info">
              <div className="organization-member-stat-number">
                {activeMembers}
              </div>
              <div className="organization-member-stat-label">Gerente</div>
            </div>
          </div>
        </div>

        <div className="organization-member-list">
          {filteredAndSortedMembers.length === 0 ? (
            <div className="organization-member-empty-state">
              <FaUsers />
              <h3>No hay miembros</h3>
              <p>
                {searchTerm || roleFilter !== "all" || statusFilter !== "all"
                  ? "No se encontraron miembros con los filtros aplicados."
                  : "Aún no has agregado ningún miembro. ¡Agrega tu primer miembro para comenzar!"}
              </p>
              {!searchTerm &&
                roleFilter === "all" &&
                statusFilter === "all" && (
                  <button
                    onClick={handleCreateMember}
                    className="organization-member-create-first-btn"
                  >
                    <FaPlus />
                    Agregar Primer Miembro
                  </button>
                )}
            </div>
          ) : (
            <div className="organization-member-grid">
              {filteredAndSortedMembers.map((member, index) => {
                const role = getMemberRole(member);
                const status = getMemberStatus(member);
                const RoleIcon = role.icon;
                const StatusIcon = status.icon;

                return (
                  <div key={member.id} className="organization-member-card">
                    <div className="organization-member-card-header">

                      <h3 className="organization-member-card-title">
                        {member.first_name} {member.last_name}
                      </h3>

                      <div className="organization-member-card-info">
                        <div className="organization-member-card-email">
                          <FaEnvelope />
                          <span>{member.email}</span>
                        </div>

                        <div className="organization-member-card-role">
                          <RoleIcon />
                          <span>{role.text}</span>
                        </div>

                        {member.phone && (
                          <div className="organization-member-card-phone">
                            <FaPhone />
                            <span>{member.phone}</span>
                          </div>
                        )}

                        {member.address && (
                          <div className="organization-member-card-location">
                            <FaMapMarkerAlt />
                            <span>{member.address}</span>
                          </div>
                        )}

                        {(member.date_joined || member.created_at) && (
                          <div className="organization-member-card-joined">
                            <FaCalendarAlt />
                            <span>
                              Se unió:{" "}
                              {formatDate(
                                member.date_joined || member.created_at
                              )}
                            </span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {filteredAndSortedMembers.length > 0 && (
          <div className="organization-member-bulk-actions">
            <button
              onClick={handleCreateMember}
              className="organization-member-bulk-btn"
            >
              <FaPlus />
              Agregar Otro Miembro
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default BranchMembers;