import React, { useState, useEffect } from "react";
import "../assets/style/OrganizationAdmin.css";
import Header from "../Components/Header";
import Events from "./Events";
import { useAuth } from "../contex/AuthProvider";
import { useNavigate } from "react-router-dom";
import NavarCompleto from "../Components/NavarCompleto";
import { getUserInfo } from "../services/authService";
import {
  FaHeart,
  FaUsers,
  FaHandsHelping,
  FaArrowRight,
  FaCalendarAlt,
  FaUserTie,
  FaPlus,
  FaChartBar,
  FaCog,
  FaClipboardList,
  FaChartLine,
  FaRocket,
} from "react-icons/fa";
import { getAllUsers, getAllEvents, getVolunteerEvents } from "../services/api";

const OrganizationAdmin = () => {
  const [isLoaded, setIsLoaded] = useState(false);
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [logo, setLogo] = useState();

  // Estado para almacenar las estadísticas
  const [stats, setStats] = useState({
    activeEvents: 0,
    volunteers: 0,
    participations: 0,
    rating: 4.8, // Este dato es estático por ahora
  });

  // Función para obtener y procesar todos los datos
  const fetchAdminStats = async () => {
    try {
      // Obtener todos los datos en paralelo
      const [usersData, eventsData, volunteerEventsData] = await Promise.all([
        getAllUsers(),
        getAllEvents(),
        getVolunteerEvents(),
      ]);

      // Filtrar eventos con status "published"
      const activeEventsCount = eventsData.filter(
        (event) => event.status === "published"
      ).length;

      // Filtrar usuarios con el rol "volunteer"
      const volunteersCount = usersData.filter(
        (user) => user.global_role && user.global_role.role === "volunteer"
      ).length;

      // Contar el total de participaciones
      const participationsCount = volunteerEventsData.length;

      // Actualizar el estado con los datos reales
      setStats({
        activeEvents: activeEventsCount,
        volunteers: volunteersCount,
        participations: participationsCount,
        rating: 4.8, // El rating sigue siendo estático, necesita una fuente de datos
      });
    } catch (error) {
      console.error("Error al cargar las estadísticas del admin:", error);
    }
  };

  const findOrganizationLogo = async () => {
    const data = await getUserInfo();
    const user = data.find(
      (u) => u.username === localStorage.getItem("username")
    );
    if (user && user.organization) {
      setLogo(user.organization.logo);
    }
  };

  useEffect(() => {
    setIsLoaded(true);
    findOrganizationLogo();
    fetchAdminStats(); // Llama a la función para obtener estadísticas
  }, []);

  const goManageEvents = (e) => {
    e.preventDefault();
    navigate("/admin/events");
  };

  const goCreateBranch = (e) => {
    e.preventDefault();
    navigate("/addBranch");
  };

  const goCreateEvent = (e) => {
    e.preventDefault();
    navigate("/addEvent");
  };

  return (
    <div className="admin-home-container">
      {/* Elementos decorativos de fondo */}
      <div className="bg-decoration">
        <div className="floating-shape shape-1"></div>
        <div className="floating-shape shape-2"></div>
        <div className="floating-shape shape-3"></div>
      </div>

      <NavarCompleto login={true} />

      <main className={`admin-main ${isLoaded ? "loaded" : ""}`}>
        <div className="content-section">
          <div className="content-wrapper">
            <div className="admin-badge">
              <FaUserTie />
              <span>Panel de Administración</span>
            </div>

            <h1>
              <span className="text-primary">Gestiona</span>
              <span className="text-gradient">tu</span>
              <span className="text-highlight">Organización</span>
            </h1>

            <p className="description">
              Administra eventos, voluntarios y recursos de tu organización.
              <span className="highlight-text"> Maximiza el impacto</span> de tu
              comunidad con herramientas poderosas y fáciles de usar.
            </p>

            <div className="admin-actions">
              <button className="btn-primary" onClick={goCreateEvent}>
                <FaPlus />
                <span>Crear Evento</span>
                <div className="btn-glow"></div>
              </button>
              <button className="btn-secondary" onClick={goCreateBranch}>
                <FaPlus />
                <span>Crear sucursales</span>
              </button>
              {/* <button className="btn-secondary" >
                <FaUsers />
                <span>Gestionar Voluntarios</span>
              </button> */}
            </div>

            {/* Sección de estadísticas con datos dinámicos */}
            <div className="admin-stats">
              <div className="stat-item">
                <div className="stat-number">{stats.activeEvents}</div>
                <div className="stat-label">Eventos Activos</div>
              </div>
              <div className="stat-item">
                <div className="stat-number">{stats.volunteers}</div>
                <div className="stat-label">Voluntarios</div>
              </div>
              <div className="stat-item">
                <div className="stat-number">{stats.participations}</div>
                <div className="stat-label">Participaciones</div>
              </div>
              <div className="stat-item">
                <div className="stat-number">{stats.rating}</div>
                <div className="stat-label">Rating</div>
              </div>
            </div>
          </div>
        </div>

        <div className="image-section">
          <div className="image-wrapper">
            <div className="image-glow"></div>
            <img
              src={logo ? logo : "/AdminDashboard.jpg"}
              alt="Dashboard de la organización"
              className="hero-image"
            />
            <div className="image-overlay"></div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default OrganizationAdmin;
