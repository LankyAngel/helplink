import React, { useEffect, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import "../assets/style/EventDetail.css";
import "../assets/style/Buttons.css";
import NavarCompleto from "../Components/NavarCompleto";
import { getUserInfo } from "../services/authService";
import {
  FaCalendarAlt,
  FaClock,
  FaMapMarkerAlt,
  FaUsers,
  FaArrowLeft,
  FaChair,
  FaPhone,
  FaEnvelope,
  FaBuilding,
  FaSpinner,
  FaCheckCircle,
  FaExclamationTriangle,
  FaStore,
  FaPlayCircle,
  FaTimesCircle,
  FaInfoCircle,
  FaHourglassHalf,
  FaLock,
  FaHourglassEnd,
} from "react-icons/fa";
import { useAuth } from "../contex/AuthProvider";
import GoogleMapEmbed from "../Components/GoogleMapEmbed";
import ButtonVolver, { ButtonGoOrganization } from "../Components/Buttons";
import { formatearFecha } from "../Components/Filtrers";

const EventDetail = () => {
  const { id } = useParams();
  const [evento, setEvento] = useState(null);
  const [loading, setLoading] = useState(false);
  const [pageLoading, setPageLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState("");
  const [successMsg, setSuccessMsg] = useState("");
  const navigate = useNavigate();
  const { access, isAuthenticated, org_code } = useAuth();
  const apiURL = process.env.REACT_APP_API_URL;
  const orgCode = org_code > 0;
  const _apiSendNoticationTopic = `${apiURL}/notifications/send/device/`;
  const _apiSubscribeToTopic = `${apiURL}/notifications/subscribe/`;
  const pushNotificationToken = localStorage.getItem("FCMToken");
  const [eventAlerts, setEventAlerts] = useState(false);
  

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  useEffect(() => {
    const loadEvent = async () => {
      try {
        setPageLoading(true);
        const response = await fetch(`${apiURL}/events/${id}`);
        if (!response.ok) throw new Error("Error al cargar el evento");
        const data = await response.json();
        setEvento(data);
      } catch (err) {
        console.error("Error al cargar el evento:", err);
        setErrorMsg("No se pudo cargar la información del evento");
      } finally {
        setPageLoading(false);
      }
    };
    loadEvent();
  }, [id, apiURL]);

  const getUserId = async () => {
    if (isAuthenticated) {
      const data = await getUserInfo();
      const username = localStorage.getItem("username");
      if (!username) return null;
      const user = data.find((u) => u.username === username);
      return user?.id || null;
    }
    return null;
  };

  const handlePostular = async () => {
    try {
      const uid = await getUserId();
      if (!uid) {
        setErrorMsg("Necesitas estar logueado para postularte.");
        setTimeout(() => setErrorMsg(""), 5000);
        return;
      }

      setLoading(true);
      setErrorMsg("");
      setSuccessMsg("");

      const response = await fetch(`${apiURL}/voluntaries-events/`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${access}`,
        },
        body: JSON.stringify({
          event_id: parseInt(id),
          user_id: uid,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        const msg =
          data && typeof data === "object"
            ? Object.values(data).flat().join(", ")
            : "Error desconocido al postularte";
        throw new Error(msg);
      }

      const newAlertState = !eventAlerts;
      const topicName = `${evento.branch.organization.id}OrgTopic-Event${id}`;

      try {
      const response = await fetch(`${apiURL}/notifications/subscribe/`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${localStorage.getItem("access")}`,
        },

        body: JSON.stringify({
          "token": pushNotificationToken,
          "topic": topicName,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || `Error al ${newAlertState ? 'suscribirse' : 'desuscribirse'}`);
      }

    } catch (err) {
      alert(`Error: ${err.message}`);
    }

      const notificationPayload = {
        token: pushNotificationToken,
        title: evento.title,
        body: `¡Te has registrado al evento "${evento.title}!". Revisa los detalles.`,
        path: `/events/${id}`
      };

      const resNotification = await fetch(_apiSendNoticationTopic, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${access}`,
        },
        body: JSON.stringify(notificationPayload),
      });

      if (!resNotification.ok) {
        const errorData = await resNotification.json();
        console.warn("Advertencia: El usuario se postulo al evento, pero la notificación falló.", errorData);
        setErrorMsg("Postulacion a evento correcta, pero falló el envío de la notificación.");
      }

      setSuccessMsg("¡Te has postulado correctamente al evento!");
      setTimeout(() => {
        setSuccessMsg("");
        navigate("/Events");
      }, 2000);
    } catch (err) {
      setErrorMsg(err.message);
      setTimeout(() => setErrorMsg(""), 6000);
    } finally {
      setLoading(false);
    }
  };

  const traducirStatus = (status) => {
    switch (status?.toLowerCase()) {
      case "published":
        return { label: "Publicado", icon: <FaCheckCircle className="icon" /> };
      case "pending":
        return {
          label: "Pendiente",
          icon: <FaHourglassHalf className="icon" />,
        };
      case "finished":
        return { label: "Finalizado", icon: <FaLock className="icon" /> };
      case "progress":
        return { label: "En curso", icon: <FaPlayCircle className="icon" /> };
      case "canceled":
        return { label: "Cancelado", icon: <FaTimesCircle className="icon" /> };
      default:
        return {
          label: "Desconocido",
          icon: <FaInfoCircle className="icon" />,
        };
    }
  };

  if (pageLoading) {
    return (
      <>
        <NavarCompleto />
        <div
          className="event-detail-container"
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <FaSpinner
            className="loading-spinner"
            style={{ fontSize: "2.5rem", color: "white" }}
          />
        </div>
      </>
    );
  }

  if (!evento) {
    return (
      <>
        <NavarCompleto />
        <div
          className="event-detail-container"
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          <div style={{ textAlign: "center", color: "white" }}>
            <FaExclamationTriangle
              style={{ fontSize: "2rem", marginBottom: "1rem" }}
            />
            <p style={{ fontSize: "1.2rem" }}>
              Evento no encontrado o error al cargar.
            </p>
            <Link to="/Events" className="event-detail-back">
              <FaArrowLeft className="icon" />
              Volver a eventos
            </Link>
          </div>
        </div>
      </>
    );
  }

  return (
    <>
      <NavarCompleto />
      <div className="event-detail-container">
        <div className="event-detail-banner">
          <img
            src={evento.banner || "/simple_logo.svg"}
            alt={evento.title}
            className="event-detail-image"
          />
        </div>

        <div className="event-detail-content">
          {/* Columna Izquierda */}
          <div className="event-detail-left">
            <ButtonVolver />
            <h1 className="event-detail-title">{evento.title}</h1>
            <p className="event-detail-description">{evento.description}</p>
            <div className="event-detail-info">
              <div className="event-detail-info-item">
                <FaCalendarAlt className="icon" />
                <span>{formatearFecha(evento.event_date)}</span>
              </div>
              <div className="event-detail-info-item">
                <FaClock className="icon" />
                <span>
                  Inicia: {evento.start_time?.substring(0, 5) || "00:00"}
                </span>
              </div>
              <div className="event-detail-info-item">
                <FaHourglassEnd className="icon" />
                <span>
                  Finaliza: {evento.end_time?.substring(0, 5) || "00:00"}
                </span>
              </div>
              <div className="event-detail-info-item">
                <FaMapMarkerAlt className="icon" />
                <span>
                  {evento.locations?.[0]?.address ||
                    evento.branch?.address ||
                    "Ubicación no disponible"}
                </span>
              </div>
              <div className="event-detail-info-item">
                <FaUsers className="icon" />
                <span>Capacidad: {evento.capacity || "No especificada"}</span>
              </div>
              <div className="event-detail-info-item">
                <FaChair className="icon vacantes-icon" />
                <span>
                  Vacantes: {evento.vacantes_restantes ?? "No especificado"}
                </span>
              </div>
              <div className="event-detail-info-item">
                {traducirStatus(evento.status).icon}
                <span>Estatus: {traducirStatus(evento.status).label}</span>
              </div>
            </div>
            {errorMsg && (
              <div className="toast-error">
                <FaExclamationTriangle style={{ marginRight: "0.5rem" }} />
                {errorMsg}
              </div>
            )}
            {successMsg && (
              <div className="toast-success">
                <FaCheckCircle style={{ marginRight: "0.5rem" }} />
                {successMsg}
              </div>
            )}
            {!orgCode && (
              <button
                onClick={handlePostular}
                disabled={loading}
                className="button-postulate"
              >
                {loading ? (
                  <>
                    <FaSpinner className="loading-spinner" />
                    Enviando...
                  </>
                ) : (
                  "Postularse al evento"
                )}
              </button>
            )}
            <ButtonGoOrganization
              organizationId={evento.branch?.organization?.id}
            />
          </div>

          {/* Columna Derecha */}
          <div className="event-detail-right">
            <div className="event-detail-meta">
              <h3>Información de la Organización</h3>
              <div className="event-detail-meta-grid">
                <div className="event-detail-meta-item">
                  <FaBuilding className="icon" />
                  <div>
                    <strong>Organización:</strong>
                    <span>
                      {evento.branch?.organization?.name || "No disponible"}
                    </span>
                  </div>
                </div>
                <div className="event-detail-meta-item">
                  <FaEnvelope className="icon" />
                  <div>
                    <strong>Email:</strong>
                    <span>
                      {evento.branch?.organization?.email || "No disponible"}
                    </span>
                  </div>
                </div>
                <div className="event-detail-meta-item">
                  <FaStore className="icon" />
                  <div>
                    <strong>Sucursal:</strong>
                    <span>{evento.branch?.name || "Sucursal desconocida"}</span>
                  </div>
                </div>
                <div className="event-detail-meta-item">
                  <FaPhone className="icon" style={{ rotate: "90deg" }} />
                  <div>
                    <strong>Teléfono:</strong>
                    <span>
                      {evento.branch?.organization?.phone || "No disponible"}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div className="google-map-container">
              {evento.locations?.[0]?.latitude &&
                evento.locations?.[0]?.longitude ? (
                <GoogleMapEmbed
                  lat={evento.locations[0].latitude}
                  lng={evento.locations[0].longitude}
                  address={evento.locations[0].address}
                />
              ) : (
                <div
                  style={{
                    height: "100%",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "#6b7280",
                  }}
                >
                  <FaMapMarkerAlt style={{ marginRight: "0.5rem" }} />
                  Ubicación no disponible
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default EventDetail;
