import React, { useEffect, useState } from "react";
import {
  FaUsers,
  FaArrowLeft,
  FaSearch,
  FaPlus,
  FaUser,
  FaEnvelope,
  FaBuilding,
  FaCheck,
  FaSpinner,
  FaTimes,
  FaUserPlus,
  FaFilter,FaExclamationTriangle, FaCheckCircle
} from "react-icons/fa";
import NavarCompleto from "../Components/NavarCompleto";
import { getUserInfo, addUserToOrganization } from "../services/authService";
import { useNavigate } from "react-router-dom";
import "../assets/style/AddOrganizationMember.css";
import { useAuth } from "../contex/AuthProvider";

const AddOrganizationMember = () => {
  const apiURL = process.env.REACT_APP_API_URL;
  const _apiURLGETBRANCHES = `${apiURL}/branches/`;
  const _apiURLinsert = `${apiURL}/branch-memberships/`;
  const { access, org_code, user_id } = useAuth();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedBranch, setSelectedBranch] = useState("");
  const [allUsers, setAllUsers] = useState([]);
  const [filteredUsers, setFilteredUsers] = useState([]);
  const [organizationBranches, setOrganizationBranches] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [successMsg, setSuccessMsg] = useState("");
  const [searchFocused, setSearchFocused] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [sucursales, setSucursales] = useState([]);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [pendingMember, setPendingMember] = useState(null); // Guarda temporalmente el usuario que se quiere agregar
  

  const navigate = useNavigate();

  useEffect(() => {
    if (!org_code) return;
    const fetchOrganization = async () => {
      try {
        const response = await fetch(`${apiURL}/organizations/${org_code}/`);
        if (!response.ok) throw new Error("Error al cargar organización");
        const data = await response.json();
        // branches es un array de sucursales
        setSucursales(data.branches || []);
        setOrganizationBranches(data.branches || []);
      } catch (error) {
        console.error("Error al cargar la organización:", error);
        setSucursales([]);
        setOrganizationBranches([]);
      }
    };
    fetchOrganization();
  }, [org_code, apiURL]);

  const fetchUsers = async () => {
    setIsSearching(true);
    try {
      const users = await getUserInfo();
      // Filtrar solo los usuarios con global_role.role === 'volunteer'
      const volunteers = users.filter(
        (user) =>
          user.global_role &&
          user.global_role.role &&
          user.global_role.role.toLowerCase() === "volunteer"
      );
      setAllUsers(volunteers);
      setTimeout(() => setIsLoaded(true), 300);
    } catch (error) {
      console.error("Error fetching users:", error);
      setAllUsers([]);
      setTimeout(() => setIsLoaded(true), 300);
    } finally {
      setIsSearching(false);
    }
  };

  const handleSearch = (term) => {
    setSearchTerm(term);
    if (term.length >= 2) {
      const filtered = allUsers.filter(
        (user) =>
          `${user.first_name} ${user.last_name}`
            .toLowerCase()
            .includes(term.toLowerCase()) ||
          user.email.toLowerCase().includes(term.toLowerCase())
      );
      setFilteredUsers(filtered);
      setShowResults(true);
    } else {
      setFilteredUsers([]);
      setShowResults(false);
    }
  };

  const handleUserSelect = (user) => {
    setSelectedUser(user);
    setSearchTerm(`${user.first_name} ${user.last_name}`);
    setShowResults(false);
  };

  const handleClearSelection = () => {
    setSelectedUser(null);
    setSearchTerm("");
    setSelectedBranch("");
    setShowResults(false);
  };
  //user_id : es el usuario seleccionado en el form
  //branch_id : del formulario, pone el id directamente
  //role : "staff"
  //created_by: user_id de localstorage

  const handleStartAddMember = () => {
  if (!selectedUser || !selectedBranch) {
    setErrorMsg("Por favor selecciona un usuario y una sucursal");
    setTimeout(() => setErrorMsg(""), 4000);
    return;
  }

  // Mostrar el modal
  setShowConfirmModal(true);
};


  const handleAddMember = async () => {
  setIsLoading(true);
  try {
    const formDataMember = {
      user_id: selectedUser.id,
      branch_id: selectedBranch,
      role: "staff",
    };

    const resInsert = await fetch(_apiURLinsert, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${access}`,
      },
      body: JSON.stringify(formDataMember),
    });

    if (!resInsert.ok) {
      const errorData = await resInsert.json();
      console.error("Detalles del error:", errorData);
      throw new Error("Error al insertar miembro");
    }

    setSuccessMsg("¡Miembro agregado exitosamente!");
    setTimeout(() => {
      setSuccessMsg("");
      navigate("/organizationAdminPanel/members");
    }, 2000);
  } catch (error) {
    console.error("Error adding member:", error);
    setErrorMsg(error.message);
    setTimeout(() => setErrorMsg(""), 6000);
  } finally {
    setIsLoading(false);
    setShowConfirmModal(false); // Ocultar modal aunque falle
  }
};


  // const handleAddMember = async () => {
  //   if (!selectedUser || !selectedBranch) {
  //     //alert("Por favor selecciona un usuario y una sucursal");
  //       setErrorMsg("Por favor selecciona un usuario y una sucursal");
  //       setTimeout(() => setErrorMsg(""), 4000);
  //     return;
  //   }

  //   setPendingMember(selectedUser); // Guardar temporalmente el usuario seleccionado
  //   setShowConfirmModal(true); // Mostrar modal

  //   if (
  //     window.confirm(
  //       `¿Agregar a ${selectedUser.first_name} ${selectedUser.last_name} a la sucursal seleccionada?`
  //     )
  //   ) {
  //     setIsLoading(true);
  //     try {
  //       const formDataMember = {
  //         user_id: selectedUser.id,
  //         branch_id: selectedBranch,
  //         role: "staff",
  //       };

  //       const resInsert = await fetch(_apiURLinsert, {
  //         method: "POST",
  //         headers: {
  //           "Content-Type": "application/json",
  //           Authorization: `Bearer ${access}`,
  //         },
  //         body: JSON.stringify(formDataMember),
  //       });

  //       if (!resInsert.ok) {
  //         const errorData = await resInsert.json();
  //         console.error("Detalles del error:", errorData);
  //         throw new Error("Error al insertar miembro");
  //       }

  //       // Aquí iría la lógica para agregar el usuario a la organización
  //       //await new Promise(resolve => setTimeout(resolve, 2000)); // Simulamos API call

  //       //alert("¡Miembro agregado exitosamente!");
  //       setSuccessMsg("¡Miembro agregado exitosamente!");
  //       setTimeout(() => {
  //         setSuccessMsg("");
  //         navigate("/organizationAdminPanel/members");
  //       }, 2000);
  //       //navigate("/organizationAdminPanel/members");
  //     } catch (error) {
  //       console.error("Error adding member:", error);
  //       //alert("Error al agregar el miembro. Inténtalo de nuevo.");
  //       setErrorMsg(error.message);
  //       setTimeout(() => setErrorMsg(""), 6000);
  //     } finally {
  //       setIsLoading(false);
  //     }
  //   }
  // };

  const handleBack = () => {
    navigate("/organizationAdminPanel/members");
  };

  const getUserStatus = (user) => {
    if (user.is_active === false)
      return { text: "Inactivo", class: "inactive" };
    if (user.last_login) return { text: "Activo", class: "active" };
    return { text: "Nuevo", class: "new" };
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  return (
    
    <div className="add-member-org-container">
      {/* Aquí insertas el modal */}
      {showConfirmModal && (
  <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-40">
    <div className="bg-white p-6 rounded-lg shadow-md w-full max-w-md">
      <h2 className="text-lg font-semibold mb-4">
        Confirmar acción
      </h2>
      <p className="mb-6">
        ¿Agregar a <strong>{selectedUser?.first_name} {selectedUser?.last_name}</strong> a la sucursal seleccionada?
      </p>
      <div className="flex justify-end space-x-4">
        <button
          onClick={() => setShowConfirmModal(false)}
          className="px-4 py-2 rounded-md border border-gray-300 text-gray-600 hover:bg-gray-100"
        >
          Cancelar
        </button>
        <button
          onClick={async () => {
            await handleAddMember();
            setShowConfirmModal(false);
          }}
          className="px-4 py-2 rounded-md bg-blue-600 text-white hover:bg-blue-700"
        >
          Confirmar
        </button>
      </div>
    </div>
  </div>
        )}

      <div className="add-member-org-bg-decoration">
        <div className="add-member-org-floating-shape add-member-org-shape-1"></div>
        <div className="add-member-org-floating-shape add-member-org-shape-2"></div>
        <div className="add-member-org-floating-shape add-member-org-shape-3"></div>
      </div>

      <NavarCompleto login={true} />

      <div className={`add-member-org-panel ${isLoaded ? "loaded" : ""}`}>
        <div className="add-member-org-header">
          <div className="add-member-org-header-content">
            <button onClick={handleBack} className="add-member-org-back-btn">
              <FaArrowLeft />
              Volver a Miembros
            </button>

            <div className="add-member-org-title-section">
              <h1>
                <FaUserPlus className="add-member-org-title-icon" />
                <span className="add-member-org-text-primary">Agregar</span>
                <span className="add-member-org-text-gradient">Miembro</span>
              </h1>
              <p className="add-member-org-subtitle">
                Busca y agrega nuevos miembros a tu organización
              </p>
            </div>
          </div>
        </div>

        <div className="add-member-org-form-container">
          <div className="add-member-org-form-card">
            <div className="add-member-org-form-header">
              <h2>
                <FaSearch />
                Información del Miembro
              </h2>
              <p>
                Busca el usuario que deseas agregar y selecciona la sucursal
              </p>
            </div>

            <div className="add-member-org-form-content">
              {successMsg && (
                  <div className="toast-success">
                    <FaCheckCircle style={{ marginRight: "0.5rem" }} />
                    {successMsg}
                  </div>
                )}
              {/* BUSCADOR DE USUARIOS */}
              <div className="add-member-org-field-group">
                <label
                  htmlFor="add-member-org-field-group"
                  className="add-member-org-field-label"
                >
                  <FaUser />
                  Buscar Usuario
                </label>
                <div className="add-member-org-search-container">
                  <div
                    className={`add-member-org-search-wrapper ${searchFocused ? "focused" : ""} ${selectedUser ? "selected" : ""}`}
                  >
                    <FaSearch className="add-member-org-search-icon" />
                    <input
                      type="text"
                      placeholder="Buscar por nombre o email..."
                      value={searchTerm}
                      onChange={(e) => handleSearch(e.target.value)}
                      onFocus={() => {
                        setSearchFocused(true);
                        if (searchTerm.length >= 2) setShowResults(true);
                      }}
                      onBlur={() => {
                        setTimeout(() => {
                          setSearchFocused(false);
                          setShowResults(false);
                        }, 200);
                      }}
                      className="add-member-org-search-input"
                      disabled={selectedUser}
                    />
                    {selectedUser && (
                      <button
                        onClick={handleClearSelection}
                        className="add-member-org-clear-btn"
                        type="button"
                      >
                        <FaTimes />
                      </button>
                    )}
                    {isSearching && (
                      <FaSpinner className="add-member-org-loading-icon" />
                    )}
                  </div>

                  {showResults && filteredUsers.length > 0 && (
                    <div className="add-member-org-search-results">
                      {filteredUsers.slice(0, 5).map((user) => {
                        const status = getUserStatus(user);
                        return (
                          <button
                            key={user.id}
                            onClick={() => handleUserSelect(user)}
                            className="add-member-org-search-result-item"
                          >
                            <div className="add-member-org-user-info">
                              <div className="add-member-org-user-name">
                                {user.first_name} {user.last_name}
                              </div>
                              <div className="add-member-org-user-email">
                                <FaEnvelope />
                                {user.email}
                              </div>
                            </div>
                            <div
                              className={`add-member-org-user-status ${status.class}`}
                            >
                              {status.text}
                            </div>
                          </button>
                        );
                      })}
                      {filteredUsers.length > 5 && (
                        <div className="add-member-org-search-more">
                          +{filteredUsers.length - 5} usuarios más...
                        </div>
                      )}
                    </div>
                  )}

                  {showResults &&
                    filteredUsers.length === 0 &&
                    searchTerm.length >= 2 && (
                      <div className="add-member-org-search-empty">
                        <FaUser />
                        <span>No se encontraron usuarios</span>
                      </div>
                    )}
                </div>
              </div>

              {/* INFORMACIÓN DEL USUARIO SELECCIONADO */}
              {selectedUser && (
                <div className="add-member-org-selected-user">
                  <div className="add-member-org-selected-user-header">
                    <h3>
                      <FaCheck />
                      Usuario Seleccionado
                    </h3>
                  </div>
                  <div className="add-member-org-selected-user-info">
                    <div className="add-member-org-selected-user-details">
                      <div className="add-member-org-selected-user-name">
                        {selectedUser.first_name} {selectedUser.last_name}
                      </div>
                      <div className="add-member-org-selected-user-email">
                        <FaEnvelope />
                        {selectedUser.email}
                      </div>
                      {selectedUser.phone && (
                        <div className="add-member-org-selected-user-phone">
                          Teléfono: {selectedUser.phone}
                        </div>
                      )}
                    </div>
                    <div
                      className={`add-member-org-selected-user-status ${getUserStatus(selectedUser).class}`}
                    >
                      {getUserStatus(selectedUser).text}
                    </div>
                  </div>
                </div>
              )}

              {/* SELECTOR DE SUCURSAL */}
              <div className="add-member-org-field-group">
                <label
                  htmlFor="add-member-org-field-group"
                  className="add-member-org-field-label"
                >
                  <FaBuilding />
                  Seleccionar Sucursal
                </label>

                <select
                  name="branch"
                  value={selectedBranch}
                  onChange={(e) => setSelectedBranch(e.target.value)}
                  className="add-member-org-select"
                  required
                >
                  <option value="">-- Selecciona una sucursal --</option>
                  {sucursales.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} – {s.street}, {s.city} ({s.zip_code})
                    </option>
                  ))}
                </select>
              </div>

              {/* INFORMACIÓN DE LA SUCURSAL SELECCIONADA */}
              {selectedBranch && (
                <div className="add-member-org-selected-branch">
                  <div className="add-member-org-selected-branch-header">
                    <h3>
                      <FaBuilding />
                      Sucursal Seleccionada
                    </h3>
                  </div>
                  <div className="add-member-org-selected-branch-info">
                    {(() => {
                      const branch = organizationBranches.find(
                        (b) => b.id === parseInt(selectedBranch)
                      );
                      return branch ? (
                        <>
                          <div className="add-member-org-selected-branch-name">
                            {branch.name}
                          </div>
                          <div className="add-member-org-selected-branch-location">
                            {branch.street}
                          </div>
                        </>
                      ) : null;
                    })()}
                  </div>
                </div>
              )}
            </div>

                {errorMsg && (
                  <div className="toast-error">
                    <FaExclamationTriangle style={{ marginRight: "0.5rem" }} />
                    {errorMsg}
                  </div>
                )}

            <div className="add-member-org-form-actions">
              <button
                onClick={handleBack}
                className="add-member-org-cancel-btn"
                disabled={isLoading}
              >
                <FaTimes />
                Cancelar
              </button>

              <button
                onClick={handleAddMember}
                className="add-member-org-submit-btn"
                disabled={!selectedUser || !selectedBranch || isLoading}
              >
                {isLoading ? (
                  <>
                    <FaSpinner className="add-member-org-loading-spinner" />
                    Agregando...
                  </>
                ) : (
                  <>
                    <FaPlus />
                    Agregar Miembro
                  </>
                )}
              </button>
            </div>
          </div>

          {/* PANEL DE AYUDA */}
          <div className="add-member-org-help-panel">
            <div className="add-member-org-help-header">
              <h3>
                <FaUsers />
                Instrucciones
              </h3>
            </div>
            <div className="add-member-org-help-content">
              <div className="add-member-org-help-step">
                <div className="add-member-org-help-step-number">1</div>
                <div className="add-member-org-help-step-text">
                  <strong>Buscar Usuario</strong>
                  <p>
                    Escribe el nombre o email del usuario que deseas agregar
                  </p>
                </div>
              </div>

              <div className="add-member-org-help-step">
                <div className="add-member-org-help-step-number">2</div>
                <div className="add-member-org-help-step-text">
                  <strong>Seleccionar Usuario</strong>
                  <p>Haz clic en el usuario correcto de los resultados</p>
                </div>
              </div>

              <div className="add-member-org-help-step">
                <div className="add-member-org-help-step-number">3</div>
                <div className="add-member-org-help-step-text">
                  <strong>Elegir Sucursal</strong>
                  <p>Selecciona la sucursal donde trabajará el nuevo miembro</p>
                </div>
              </div>

              <div className="add-member-org-help-step">
                <div className="add-member-org-help-step-number">4</div>
                <div className="add-member-org-help-step-text">
                  <strong>Confirmar</strong>
                  <p>
                    Revisa la información y confirma para agregar el miembro
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AddOrganizationMember;
