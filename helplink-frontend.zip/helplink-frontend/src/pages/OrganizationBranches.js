// src/pages/OrganizationBranches.js
import React, { useEffect, useState } from "react";
import {
  FaBuilding,
  FaEdit,
  FaTrash,
  FaPlus,
  FaArrowLeft,
  FaMapMarkerAlt,
  FaPhone,
  FaUser,
  FaCalendarAlt,
  FaUsers,
  FaStar,
  FaSearch,
  FaFilter,
  FaSort,
  FaEye,
  FaGlobe,
} from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import { getOrganizationDashboard, deleteBranch } from "../services/api";
import NavarCompleto from "../Components/NavarCompleto";
import "../assets/style/OrganizationBranches.css";

const OrganizationBranches = () => {
  const [branches, setBranches] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [sortBy, setSortBy] = useState("name");
  const [sortOrder, setSortOrder] = useState("asc");
  const [showFilters, setShowFilters] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const navigate = useNavigate();

  const fetchBranches = async () => {
    const orgId = localStorage.getItem("organizationId");
    if (!orgId) return;

    try {
      const dashboardData = await getOrganizationDashboard(orgId);
      setBranches(dashboardData.branches || []);
      setTimeout(() => setIsLoaded(true), 300);
    } catch (error) {
      console.error("Error fetching branches:", error);
      setBranches([]);
      setTimeout(() => setIsLoaded(true), 300);
    }
  };

  const handleDelete = async (branchId) => {
    if (window.confirm("¿Estás seguro de eliminar esta sucursal?")) {
      try {
        await deleteBranch(branchId);
        fetchBranches();
      } catch (error) {
        console.error("Error deleting branch:", error);
      }
    }
  };

  const handleEdit = (branchId) => {
    navigate(`/editBranch/${branchId}`);
  };

  const handleView = (branchId) => {
    navigate(`/branch/${branchId}`);
  };

  const handleCreateBranch = () => {
    navigate("/addBranch");
  };

  const handleBack = () => {
    navigate("/organizationAdminPanel");
  };

  const filteredAndSortedBranches = branches
    .filter((branch) => {
      const matchesSearch =
        branch.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        branch.city.toLowerCase().includes(searchTerm.toLowerCase()) ||
        branch.street.toLowerCase().includes(searchTerm.toLowerCase());

      if (statusFilter === "all") return matchesSearch;

      const hasEvents = (branch.events_count || 0) > 0;
      if (statusFilter === "active") return matchesSearch && hasEvents;
      if (statusFilter === "inactive") return matchesSearch && !hasEvents;

      return matchesSearch;
    })
    .sort((a, b) => {
      let aValue, bValue;

      switch (sortBy) {
        case "name":
          aValue = a.name.toLowerCase();
          bValue = b.name.toLowerCase();
          break;
        case "city":
          aValue = a.city.toLowerCase();
          bValue = b.city.toLowerCase();
          break;
        case "events":
          aValue = a.events_count || 0;
          bValue = b.events_count || 0;
          break;
        default:
          aValue = a.name.toLowerCase();
          bValue = b.name.toLowerCase();
      }

      if (sortOrder === "asc") {
        return aValue > bValue ? 1 : -1;
      } else {
        return aValue < bValue ? 1 : -1;
      }
    });

  const getBranchRank = (index) => {
    if (index === 0)
      return { icon: FaStar, class: "organization-branch-rank-1", text: "#1" };
    if (index === 1)
      return { icon: FaStar, class: "organization-branch-rank-2", text: "#2" };
    if (index === 2)
      return { icon: FaStar, class: "organization-branch-rank-3", text: "#3" };
    return {
      icon: FaBuilding,
      class: "organization-branch-rank-default",
      text: `#${index + 1}`,
    };
  };

  const getBranchStatus = (branch) => {
    const hasEvents = (branch.events_count || 0) > 0;
    return hasEvents
      ? { text: "Activa", class: "success", icon: "●" }
      : { text: "Inactiva", class: "warning", icon: "●" };
  };

  const totalBranches = branches.length;
  const activeBranches = branches.filter(
    (b) => (b.events_count || 0) > 0
  ).length;
  const totalEvents = branches.reduce(
    (sum, b) => sum + (b.events_count || 0),
    0
  );
  const avgEventsPerBranch =
    totalBranches > 0 ? Math.round(totalEvents / totalBranches) : 0;

  useEffect(() => {
    fetchBranches();
  }, []);

  return (
    <div className="organization-branch-container">
      <div className="organization-branch-bg-decoration">
        <div className="organization-branch-floating-shape organization-branch-shape-1"></div>
        <div className="organization-branch-floating-shape organization-branch-shape-2"></div>
        <div className="organization-branch-floating-shape organization-branch-shape-3"></div>
      </div>

      <NavarCompleto login={true} />

      <div className={`organization-branch-panel ${isLoaded ? "loaded" : ""}`}>
        <div className="organization-branch-header">
          <div className="organization-branch-header-content">
            <button
              onClick={handleBack}
              className="organization-branch-back-btn"
            >
              <FaArrowLeft />
              Volver al Panel
            </button>

            <div className="organization-branch-title-section">
              <h1>
                <FaBuilding className="organization-branch-title-icon" />
                <span className="organization-branch-text-primary">
                  Gestión de
                </span>
                <span className="organization-branch-text-gradient">
                  Sucursales
                </span>
              </h1>
              <p className="organization-branch-subtitle">
                Administra todas las sucursales de tu organización
              </p>
            </div>

            <button
              onClick={handleCreateBranch}
              className="organization-branch-create-btn"
            >
              <FaPlus />
              Nueva Sucursal
            </button>
          </div>
        </div>

        <div className="organization-branch-stats-grid">
          <div className="organization-branch-stat-card primary">
            <div className="organization-branch-stat-icon">
              <FaBuilding />
            </div>
            <div className="organization-branch-stat-info">
              <div className="organization-branch-stat-number">
                {totalBranches}
              </div>
              <div className="organization-branch-stat-label">
                Total Sucursales
              </div>
            </div>
          </div>

          <div className="organization-branch-stat-card success">
            <div className="organization-branch-stat-icon">
              <FaGlobe />
            </div>
            <div className="organization-branch-stat-info">
              <div className="organization-branch-stat-number">
                {activeBranches}
              </div>
              <div className="organization-branch-stat-label">
                Sucursales Activas
              </div>
            </div>
          </div>

          <div className="organization-branch-stat-card warning">
            <div className="organization-branch-stat-icon">
              <FaCalendarAlt />
            </div>
            <div className="organization-branch-stat-info">
              <div className="organization-branch-stat-number">
                {totalEvents}
              </div>
              <div className="organization-branch-stat-label">
                Total Eventos
              </div>
            </div>
          </div>

          <div className="organization-branch-stat-card info">
            <div className="organization-branch-stat-icon">
              <FaStar />
            </div>
            <div className="organization-branch-stat-info">
              <div className="organization-branch-stat-number">
                {avgEventsPerBranch}
              </div>
              <div className="organization-branch-stat-label">
                Promedio por Sucursal
              </div>
            </div>
          </div>
        </div>

        <div className="organization-branch-controls">
          <div className="organization-branch-search-section">
            <div className="organization-branch-search-box">
              <FaSearch />
              <input
                type="text"
                placeholder="Buscar sucursales por nombre, ciudad o dirección..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`organization-branch-filter-toggle ${showFilters ? "active" : ""}`}
            >
              <FaFilter />
              Filtros
            </button>
          </div>

          {showFilters && (
            <div className="organization-branch-filters">
              <div className="organization-branch-filter-group">
                <label htmlFor="organization-branch-filter-group">
                  Estado:
                </label>
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                >
                  <option value="all">Todas</option>
                  <option value="active">Activas</option>
                  <option value="inactive">Inactivas</option>
                </select>
              </div>

              <div className="organization-branch-filter-group">
                <label htmlFor="organization-branch-filter-group">
                  Ordenar por:
                </label>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                >
                  <option value="name">Nombre</option>
                  <option value="city">Ciudad</option>
                  <option value="events">Eventos</option>
                </select>
              </div>

              <button
                onClick={() =>
                  setSortOrder(sortOrder === "asc" ? "desc" : "asc")
                }
                className="organization-branch-sort-order"
              >
                <FaSort />
                {sortOrder === "asc" ? "Ascendente" : "Descendente"}
              </button>
            </div>
          )}
        </div>

        <div className="organization-branch-list">
          {filteredAndSortedBranches.length === 0 ? (
            <div className="organization-branch-empty-state">
              <FaBuilding />
              <h3>No hay sucursales</h3>
              <p>
                {searchTerm || statusFilter !== "all"
                  ? "No se encontraron sucursales con los filtros aplicados."
                  : "Aún no has creado ninguna sucursal. ¡Crea tu primera sucursal para comenzar!"}
              </p>
              {!searchTerm && statusFilter === "all" && (
                <button
                  onClick={handleCreateBranch}
                  className="organization-branch-create-first-btn"
                >
                  <FaPlus />
                  Crear Primera Sucursal
                </button>
              )}
            </div>
          ) : (
            <div className="organization-branch-grid">
              {filteredAndSortedBranches.map((branch, index) => {
                const rank = getBranchRank(index);
                const status = getBranchStatus(branch);
                const RankIcon = rank.icon;

                return (
                  <div key={branch.id} className="organization-branch-card">
                    <div className="organization-branch-card-header">
                      <div className="organization-branch-card-meta">
                        <div
                          className={`organization-branch-rank ${rank.class}`}
                        >
                          <RankIcon />
                          <span className="organization-branch-rank-number">
                            {rank.text}
                          </span>
                        </div>
                        {/* <div
                          className={`organization-branch-status ${status.class}`}
                        >
                          <span>{status.icon}</span>
                          {status.text}
                        </div> */}
                      </div>

                      <h3 className="organization-branch-card-title">
                        {branch.name}
                      </h3>

                      <div className="organization-branch-card-info">
                        <div className="organization-branch-card-location">
                          <FaMapMarkerAlt />
                          <span>
                            {branch.city}, {branch.street}
                          </span>
                        </div>

                        {branch.phone && (
                          <div className="organization-branch-card-contact">
                            <FaPhone />
                            <span>{branch.phone}</span>
                          </div>
                        )}

                        {branch.manager && (
                          <div className="organization-branch-card-manager">
                            <FaUser />
                            <span>{branch.manager}</span>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="organization-branch-card-actions">
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {filteredAndSortedBranches.length > 0 && (
          <div className="organization-branch-bulk-actions">
            <button
              onClick={handleCreateBranch}
              className="organization-branch-bulk-btn"
            >
              <FaPlus />
              Agregar Otra Sucursal
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default OrganizationBranches;
