import React, { useState, useEffect } from "react";
import {
  FaUser,
  FaClock,
  FaImage,
  FaCalendarAlt,
  FaRegStickyNote,
  FaStore,
  FaUsers,
  FaTags,
  FaExclamationTriangle,
  FaCheckCircle,
  FaMapMarkerAlt,
  FaCity,
  FaGlobe,
  FaMailBulk,
  FaHourglassEnd, // Icono añadido
} from "react-icons/fa";
import "../assets/style/AddEvent.css";
import NavarCompleto from "../Components/NavarCompleto";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../contex/AuthProvider";

const AddEventAndSearch = () => {
  const { access, org_code, branch__id } = useAuth();
  const apiURL = process.env.REACT_APP_API_URL;
  const _apiURLInsert = `${apiURL}/events/`;
  const _apiURLGET = `${apiURL}/branches/`;
  const _apiURLEVENTCATEGORIES = `${apiURL}/event-categories/`;
  const _apiURLGetCategories = `${apiURL}/categories/`;
  const _apiInsertLocationEvent = `${apiURL}/event-locations/`;
  const _apiSendNoticationTopic = `${apiURL}/notifications/send/topic/`;

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    capacity: "",
    image: null,
    event_date: "",
    start_time: "",
    end_time: "",
    status: "published",
    branch: branch__id,
  });

  const [sucursales, setSucursales] = useState([]);
  const [categorias, setCategorias] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [successMsg, setSuccessMsg] = useState("");
  const today = new Date().toISOString().split("T")[0];
  const navigate = useNavigate();

  const [street, setStreet] = useState("");
  const [city, setCity] = useState("");
  const [stateName, setStateName] = useState("");
  const [postalcode, setPostalcode] = useState("");
  const [country, setCountry] = useState("");
  const [searchResults, setSearchResults] = useState([]);
  const [isSearching, setIsSearching] = useState(false);
  const [selectedAddress, setSelectedAddress] = useState(null);

  useEffect(() => {
    if (!org_code) return;

    const fetchBranches = async () => {
      try {
        const response = await fetch(_apiURLGET, {
          headers: { Authorization: `Bearer ${access}` },
        });
        if (!response.ok) throw new Error("Error al cargar sucursales");
        const data = await response.json();
        const sucursalesFiltradas = data.filter(
          (sucursal) => sucursal.organization === Number(org_code)
        );
        setSucursales(sucursalesFiltradas);
      } catch (error) {
        console.error("Error al cargar las sucursales:", error);
        setErrorMsg("No se pudieron cargar las sucursales.");
      }
    };

    fetchBranches();
  }, [org_code, access, _apiURLGET]);

  useEffect(() => {
    const fetchCategorias = async () => {
      try {
        const res = await fetch(_apiURLGetCategories, {});
        if (!res.ok) throw new Error("Error al obtener categorías");
        const data = await res.json();
        setCategorias(data);
      } catch (error) {
        console.error("Error al cargar categorías:", error);
        setErrorMsg("No se pudieron cargar las categorías.");
      }
    };

    fetchCategorias();
  }, [access, _apiURLGetCategories]);

  const handleInputChange = (e) => {
    const { name, value, files } = e.target;
    if (name === "image") {
      setFormData({ ...formData, [name]: files[0] });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const submitEventForm = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMsg("");
    setSuccessMsg("");

    try {
      // Paso 1: Preparar y enviar los datos del evento.
      const formDataEvento = new FormData();
      Object.entries(formData).forEach(([key, value]) => {
        formDataEvento.append(key, value);
      });

      const resInsert = await fetch(_apiURLInsert, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${access}`,
        },
        body: formDataEvento,
      });

      if (!resInsert.ok) {
        const errorData = await resInsert.json();
        throw new Error(
          errorData.detail ||
            `Error al crear el evento: ${resInsert.statusText}`
        );
      }

      const eventoCreado = await resInsert.json();

      // Paso 2: Asociar la categoría seleccionada con el evento recién creado.
      const bodyRelacion = {
        event_id: parseInt(eventoCreado.id),
        category_id: parseInt(selectedCategory),
      };

      const resRelacion = await fetch(_apiURLEVENTCATEGORIES, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${access}`,
        },
        body: JSON.stringify(bodyRelacion),
      });

      if (!resRelacion.ok) {
        const errorData = await resRelacion.json();
        throw new Error(errorData.detail || "Error al asociar la categoría.");
      }

      // Paso 3: Guardar la ubicación del evento si se seleccionó una dirección alternativa.
      if (selectedAddress) {
        const bodyInsertLocationEvent = {
          event_id: eventoCreado.id,
          address: selectedAddress.display_name,
          latitude: selectedAddress.lat,
          longitude: selectedAddress.lon,
        };

        const insertLocation = await fetch(_apiInsertLocationEvent, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${access}`,
          },
          body: JSON.stringify(bodyInsertLocationEvent),
        });

        if (!insertLocation.ok) {
          const errorData = await insertLocation.json();
          throw new Error(errorData.detail || "Error al guardar la ubicación.");
        }
      }

      // Paso 4: Enviar la notificación a los suscriptores del tema (topic).
      const topicName = `${org_code}OrgTopic`;

      const notificationPayload = {
        topic: topicName,
        title: eventoCreado.title,
        body: `¡Nuevo evento! "${eventoCreado.title}". Revisa los detalles y participa.`,
        path: `/events/${eventoCreado.id}`,
      };

      const resNotification = await fetch(_apiSendNoticationTopic, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${access}`,
        },
        body: JSON.stringify(notificationPayload),
      });

      if (!resNotification.ok) {
        const errorData = await resNotification.json();
        console.warn(
          "Advertencia: El evento se creó, pero la notificación falló.",
          errorData
        );
        setErrorMsg("Evento creado, pero falló el envío de la notificación.");
      }

      setSuccessMsg("¡Evento creado y notificado exitosamente!");
      setTimeout(() => {
        navigate("/branchAdminPanel");
      }, 2000);
    } catch (error) {
      console.error(
        "Error detallado en el proceso de creación del evento:",
        error
      );
      setErrorMsg(
        error.message || "Ocurrió un error desconocido. Inténtalo de nuevo."
      );
      setTimeout(() => setErrorMsg(""), 8000);
    } finally {
      setIsLoading(false);
    }
  };
  // Manejador para el formulario de búsqueda de dirección (Nominatim)
  const handleAddressSearch = async (e) => {
    e.preventDefault();
    setIsSearching(true);
    const params = new URLSearchParams({
      street,
      city,
      state: stateName,
      postalcode,
      country,
      format: "jsonv2",
      addressdetails: "1",
      limit: "5",
    });

    const url = `https://nominatim.openstreetmap.org/search?${params.toString()}`;
    try {
      const resp = await fetch(url, {
        headers: { "User-Agent": "MiAppDeEventos/1.0 (tu-email@ejemplo.com)" },
      });
      if (!resp.ok)
        throw new Error("La respuesta de la red de Nominatim no fue correcta.");
      const data = await resp.json();
      setSearchResults(data);
    } catch (error) {
      console.error("Error al buscar en Nominatim:", error);
      setErrorMsg("Error al buscar la dirección. Intente de nuevo.");
    } finally {
      setIsSearching(false);
    }
  };

  const handleAddressSelect = (address) => {
    setSelectedAddress(address);
    // Limpiar campos de búsqueda después de seleccionar
    setStreet("");
    setCity("Tijuana");
    setStateName("Baja California");
    setPostalcode("");
    setCountry("Mexico");
    setSearchResults([]);
  };

  return (
    <>
      <NavarCompleto />
      <div className="register-container">
        <div className="background-decorations">
          <div className="decoration decoration-1"></div>
          <div className="decoration decoration-2"></div>
          <div className="decoration decoration-3"></div>
        </div>

        <div className="register-wrapper">
          {/* --- Tarjeta Combinada para Crear Evento y Búsqueda de Direcciones --- */}
          <div className="register-card">
            <div className="register-header">
              <div className="avatar-container">
                <FaCalendarAlt className="avatar-icon" />
              </div>
              <h1 className="register-title">Crear un evento</h1>
            </div>

            <form className="register-form" onSubmit={submitEventForm}>
              <div className="input-group">
                <div className="input-icon">
                  <FaUser className="icon" />
                </div>
                <input
                  type="text"
                  name="title"
                  placeholder="Nombre del Evento"
                  value={formData.title}
                  onChange={handleInputChange}
                  className="form-input"
                  required
                />
              </div>
              <div className="input-group">
                <div className="input-icon">
                  <FaRegStickyNote className="icon" />
                </div>
                <input
                  type="text"
                  name="description"
                  placeholder="Descripción"
                  value={formData.description}
                  onChange={handleInputChange}
                  className="form-input"
                  required
                />
              </div>
              <div className="input-group">
                <div className="input-icon">
                  <FaUsers className="icon" />
                </div>
                <input
                  type="number"
                  name="capacity"
                  placeholder="Límite de voluntarios"
                  value={formData.capacity}
                  onChange={handleInputChange}
                  className="form-input"
                  min="1"
                  required
                />
              </div>
              <p
                className="register-subtitle"
                style={{ textAlign: "center", margin: "10px 0" }}
              >
                Imagen del evento
              </p>
              <div className="input-group">
                <div className="input-icon">
                  <FaImage className="icon" />
                </div>
                <input
                  type="file"
                  name="image"
                  accept="image/*"
                  onChange={handleInputChange}
                  className="form-input"
                  required
                />
              </div>
              <div className="input-group">
                <div className="input-icon">
                  <FaCalendarAlt className="icon" />
                </div>
                <input
                  type="date"
                  name="event_date"
                  min={today}
                  value={formData.event_date}
                  onChange={handleInputChange}
                  className="form-input"
                  required
                />
              </div>
              <div className="input-group">
                <div className="input-icon">
                  <FaClock className="icon" />
                </div>
                <input
                  type="time"
                  name="start_time"
                  value={formData.start_time}
                  onChange={handleInputChange}
                  className="form-input"
                  required
                />
              </div>

              {/* --- INICIO: CAMBIO AÑADIDO --- */}
              <div className="input-group">
                <div className="input-icon">
                  <FaHourglassEnd className="icon" />
                </div>
                <input
                  type="time"
                  name="end_time"
                  value={formData.end_time}
                  onChange={handleInputChange}
                  className="form-input"
                  required
                />
              </div>
              {/* --- FIN: CAMBIO AÑADIDO --- */}

              <div className="input-group">
                <div className="input-icon">
                  <FaTags className="icon" />
                </div>
                <select
                  name="category"
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="form-input"
                  required
                >
                  <option value="">-- Selecciona una categoría --</option>
                  {categorias.map((cat) => (
                    <option key={cat.id} value={cat.id}>
                      {cat.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* --- Sección de Búsqueda de Direcciones dentro del mismo formulario --- */}
              <div
                style={{
                  marginTop: "2rem",
                  paddingTop: "1rem",
                  borderTop: "1px solid #e0e0e0",
                }}
              >
                <h3
                  style={{
                    textAlign: "center",
                    marginBottom: "1rem",
                    color: "#333",
                  }}
                >
                  <FaMapMarkerAlt style={{ marginRight: "0.5rem" }} />
                  Buscar Dirección Alternativa
                </h3>

                <div
                  style={{
                    display: "flex",
                    flexWrap: "wrap",
                    gap: "0.5rem",
                    marginBottom: "1rem",
                  }}
                >
                  <div
                    className="input-group"
                    style={{ flex: "1", minWidth: "200px" }}
                  >
                    <div className="input-icon">
                      <FaMapMarkerAlt className="icon" />
                    </div>
                    <input
                      className="form-input"
                      placeholder="Calle #Num"
                      value={street}
                      onChange={(e) => setStreet(e.target.value)}
                    />
                  </div>
                </div>

                <div
                  style={{
                    display: "flex",
                    flexWrap: "wrap",
                    gap: "0.5rem",
                    marginBottom: "1rem",
                  }}
                >
                  <div
                    className="input-group"
                    style={{ flex: "1", minWidth: "120px" }}
                  >
                    <div className="input-icon">
                      <FaMailBulk className="icon" />
                    </div>
                    <input
                      className="form-input"
                      placeholder="Código Postal"
                      value={postalcode}
                      onChange={(e) => setPostalcode(e.target.value)}
                    />
                  </div>
                </div>

                <button
                  type="button"
                  onClick={handleAddressSearch}
                  disabled={isSearching}
                  className="submit-button"
                  style={{ backgroundColor: "#28a745", marginBottom: "1rem" }}
                >
                  {isSearching ? (
                    <>
                      <div className="spinner"></div>
                      <span>Buscando...</span>
                    </>
                  ) : (
                    "Buscar Dirección"
                  )}
                </button>

                {/* Resultados de búsqueda como opciones seleccionables */}
                {searchResults.length > 0 && (
                  <div style={{ marginBottom: "1rem" }}>
                    <h4 style={{ marginBottom: "0.5rem", color: "#555" }}>
                      Selecciona una dirección:
                    </h4>
                    <div
                      style={{
                        maxHeight: "200px",
                        overflowY: "auto",
                        border: "1px solid #ddd",
                        borderRadius: "8px",
                      }}
                    >
                      {searchResults.map((item) => (
                        <div
                          key={item.place_id}
                          role="button"
                          tabIndex={0}
                          onClick={() => handleAddressSelect(item)}
                          onKeyDown={(e) => {
                            if (e.key === "Enter" || e.key === " ") {
                              e.preventDefault();
                              handleAddressSelect(item);
                            }
                          }}
                          style={{
                            padding: "10px",
                            cursor: "pointer",
                            borderBottom: "1px solid #eee",
                            transition: "background-color 0.2s",
                            backgroundColor:
                              selectedAddress?.place_id === item.place_id
                                ? "#e3f2fd"
                                : "transparent",
                          }}
                          onMouseEnter={(e) =>
                            (e.target.style.backgroundColor = "#f5f5f5")
                          }
                          onMouseLeave={(e) =>
                            (e.target.style.backgroundColor =
                              selectedAddress?.place_id === item.place_id
                                ? "#e3f2fd"
                                : "transparent")
                          }
                        >
                          <strong
                            style={{
                              display: "block",
                              marginBottom: "4px",
                              color: "#333",
                            }}
                          >
                            {item.display_name}
                          </strong>
                          <small style={{ color: "#666" }}>
                            Lat: {item.lat}, Lon: {item.lon} | {item.category} -{" "}
                            {item.type}
                          </small>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Dirección seleccionada */}
                {selectedAddress && (
                  <div
                    style={{
                      padding: "10px",
                      backgroundColor: "#d4edda",
                      border: "1px solid #c3e6cb",
                      borderRadius: "8px",
                      marginBottom: "1rem",
                    }}
                  >
                    <h4 style={{ margin: "0 0 8px 0", color: "#155724" }}>
                      <FaCheckCircle style={{ marginRight: "0.5rem" }} />
                      Dirección Seleccionada:
                    </h4>
                    <p
                      style={{
                        margin: "0",
                        color: "#155724",
                        fontSize: "14px",
                      }}
                    >
                      <strong>{selectedAddress.display_name}</strong>
                      <br />
                      Coordenadas: {selectedAddress.lat}, {selectedAddress.lon}
                    </p>
                    <button
                      type="button"
                      onClick={() => setSelectedAddress(null)}
                      style={{
                        marginTop: "8px",
                        padding: "4px 8px",
                        backgroundColor: "#dc3545",
                        color: "white",
                        border: "none",
                        borderRadius: "4px",
                        cursor: "pointer",
                        fontSize: "12px",
                      }}
                    >
                      Deseleccionar
                    </button>
                  </div>
                )}
              </div>

              {errorMsg && (
                <div className="toast-error">
                  <FaExclamationTriangle style={{ marginRight: "0.5rem" }} />
                  {errorMsg}
                </div>
              )}
              {successMsg && (
                <div className="toast-success">
                  <FaCheckCircle style={{ marginRight: "0.5rem" }} />
                  {successMsg}
                </div>
              )}
              <button
                type="submit"
                disabled={isLoading}
                className="submit-button"
              >
                {isLoading ? (
                  <>
                    <div className="spinner"></div>
                    <span>Procesando...</span>
                  </>
                ) : (
                  "Crear evento"
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default AddEventAndSearch;
