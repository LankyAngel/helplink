import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { FaCheckCircle, FaTimesCircle, FaSpinner, FaQrcode, FaCalendarCheck, FaUserCheck } from 'react-icons/fa';
import '../assets/style/AttendanceValidator.css';
import { validateAttendance as validateAttendanceAPI } from '../services/api';

const AttendanceValidator = () => {
  const [status, setStatus] = useState('loading'); // loading, success, error, expired
  const [message, setMessage] = useState('');
  const [eventData, setEventData] = useState(null);
  const [volunteerData, setVolunteerData] = useState(null);
  const [countdown, setCountdown] = useState(5);
  
  const navigate = useNavigate();
  const { validationToken } = useParams(); // Token único del link QR

  useEffect(() => {
    validateAttendance();
  }, []);

  // Countdown para redirección automática
  useEffect(() => {
    let timer;
    if (status === 'success' && countdown > 0) {
      timer = setTimeout(() => {
        setCountdown(countdown - 1);
      }, 1000);
    } else if (status === 'success' && countdown === 0) {
      navigate('/events'); // O la página que prefieras
    }
    return () => clearTimeout(timer);
  }, [status, countdown, navigate]);

    const validateAttendance = async () => {
        try {
            const data = await validateAttendanceAPI(validationToken);

            if (data.message === "Ya habías registrado tu asistencia para este evento.") {
            setStatus('expired');
            setMessage(data.message);
            } else if (data.message === "Asistencia registrada correctamente.") {
            setStatus('success');
            setMessage(data.message);
            setEventData({ name: `Evento #${validationToken}` });
            setVolunteerData({ name: "Tú" });
            } else {
            setStatus('error');
            setMessage(data.error || 'Error desconocido al registrar la asistencia');
            }
        } catch (error) {
            setStatus('error');
            setMessage('Error de conexión al registrar la asistencia');
        }
    };

  const handleRetry = () => {
    setStatus('loading');
    setMessage('');
    validateAttendance();
  };

  const handleGoHome = () => {
    navigate('/');
  };

  const handleGoEvents = () => {
    navigate('/events');
  };

  const renderLoadingState = () => (
    <div className="validation-container validation-loading">
      <div className="validation-card">
        <div className="icon-container loading-icon">
          <FaSpinner className="spinner-icon" />
        </div>
        <h2 className="validation-title">Validando Asistencia</h2>
        <p className="validation-message">Procesando tu registro de asistencia...</p>
        <div className="loading-bar">
          <div className="loading-progress"></div>
        </div>
      </div>
    </div>
  );

  const renderSuccessState = () => (
    <div className="validation-container validation-success">
      <div className="validation-card">
        <div className="icon-container success-icon">
          <FaCheckCircle />
        </div>
        <h2 className="validation-title">¡Asistencia Confirmada!</h2>
        <p className="validation-message success-message">{message}</p>
        
        {eventData && (
          <div className="event-details">
            <div className="detail-item">
              <FaCalendarCheck />
              <span className="detail-text">{eventData.name}</span>
            </div>
            <div className="detail-item">
              <FaUserCheck />
              <span className="detail-text">{volunteerData?.name || 'Voluntario'}</span>
            </div>
          </div>
        )}

        <div className="countdown-container">
          <p className="countdown-text">Serás redirigido en {countdown} segundos</p>
          <div className="countdown-bar">
            <div 
              className="countdown-progress" 
              style={{ width: `${((5 - countdown) / 5) * 100}%` }}
            ></div>
          </div>
        </div>

        <button 
          className="action-btn redirect-btn"
          onClick={handleGoEvents}
        >
          Ir a Eventos Ahora
        </button>
      </div>
    </div>
  );

  const renderErrorState = () => (
    <div className="validation-container validation-error">
      <div className="validation-card">
        <div className="icon-container error-icon">
          <FaTimesCircle />
        </div>
        <h2 className="validation-title">Error de Validación</h2>
        <p className="validation-message error-message">{message}</p>
        
        <div className="error-actions">
          <button 
            className="action-btn retry-btn"
            onClick={handleRetry}
          >
            Reintentar
          </button>
          <button 
            className="action-btn home-btn"
            onClick={handleGoHome}
          >
            Ir al Inicio
          </button>
        </div>
      </div>
    </div>
  );

  const renderExpiredState = () => (
    <div className="validation-container validation-expired">
      <div className="validation-card">
        <div className="icon-container expired-icon">
          <FaQrcode />
        </div>
        <h2 className="validation-title">Validación Expirada</h2>
        <p className="validation-message expired-message">{message}</p>
        <p className="validation-submessage">Este código QR ya fue utilizado y no puede ser usado nuevamente.</p>
        
        <button 
          className="action-btn events-btn"
          onClick={handleGoEvents}
        >
          Ver Eventos
        </button>
      </div>
    </div>
  );

  return (
    <div className="validator-wrapper">
      {/* Elementos decorativos */}
      <div className="validator-bg-decoration">
        <div className="validator-floating-shape validator-shape-1"></div>
        <div className="validator-floating-shape validator-shape-2"></div>
        <div className="validator-floating-shape validator-shape-3"></div>
      </div>

      {status === 'loading' && renderLoadingState()}
      {status === 'success' && renderSuccessState()}
      {status === 'error' && renderErrorState()}
      {status === 'expired' && renderExpiredState()}
    </div>
  );
};

export default AttendanceValidator;