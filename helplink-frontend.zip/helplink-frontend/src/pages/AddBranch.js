import React, { useState, useEffect } from "react";
import {FaUser,FaClock,FaPhone,FaImage,FaCalendarAlt,FaRegStickyNote,FaStore,
  FaExclamationTriangle,FaCheckCircle,
  FaUsers,FaCity, FaRoad, FaMailBulk,
} from "react-icons/fa";
import "../assets/style/AddBranch.css";
import NavarCompleto from "../Components/NavarCompleto";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../contex/AuthProvider";
import axios from "axios";
import { getCategories } from "../services/api";

export const AddBranch = () => {
    const apiURL = process.env.REACT_APP_API_URL;
    const _apiURL = `${apiURL}/branches/`;
    const { access, org_code } = useAuth();
    const [name, setName] = useState("");
    const [imagen, setImagen] = useState(null);
    const [fecha, setFecha] = useState("");
    const today = new Date().toISOString().split("T")[0];
    const [hora, setHora] = useState("");
    const [isLoading, setIsLoading] = useState(false);
    const [eventos, setEventos] = useState([]);
    const [sucursalSeleccionada, setSucursalSeleccionada] = useState("");
    const [sucursales, setSucursales] = useState([]);
    const [errorMsg, setErrorMsg] = useState("");
    const [successMsg, setSuccessMsg] = useState("");
    var orgCode = org_code;

    const navigate = useNavigate();

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData((prevData) => ({
          ...prevData,
          [name]: value, // Aquí se guarda el ID de la sucursal seleccionada
        }));
    };
    
    const handleImageChange = (e) => {
        setFormData({ ...formData, image: e.target.files[0] });
    };
    
    const [formData, setFormData] = useState({
        name: "",
        logo: "",
        street: "",
        city: "",
        zip_code: "",
    });
    
    useEffect(() => {
        if (eventos.length > 0) {
          const sucursalesUnicas = Array.from(
            new Map(
              eventos
                .filter((e) => e.branch && e.branch.id)
                .map((e) => [e.branch.id, e.branch])
            ).values()
          );
          setSucursales(sucursalesUnicas);
        }
    }, [eventos]);

    useEffect(() => {
    if (org_code) {
      setFormData((prevData) => ({
        ...prevData,
        organization: Number(org_code),
      }));
    }
  }, [org_code]);


    const handleImagenChange = (e) => {
        const file = e.target.files[0];
        if (file) {
        setImagen(file);
        }
    };

    const submitForm = async (e) => {
    e.preventDefault();

    const data = new FormData();
    const orgCode = org_code;
    data.append("name", formData.name);
    data.append("logo", formData.logo);
    data.append("street", formData.street);
    data.append("city", formData.city);
    data.append("zip_code", formData.zip_code);
    data.append("organization", Number(org_code));

    for (let pair of data.entries()) {
      console.log(`${pair[0]}: ${pair[1]}`);
    }

    try {
      const response = await fetch(_apiURL, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${access}`,
        },
        body: data,
      });

      if (!response.ok) {
        const errorData = await response.json();
        console.error(errorData);
        throw new Error("Error al agregar sucursal");
      }

      const result = await response.json();
      setSuccessMsg("¡Sucursal creada con éxito!");
      setTimeout(() => {
        setSuccessMsg("");
        navigate("/organizationAdminPanel");
      }, 2000);
    } catch (err) {
      console.error(err.message);
      setErrorMsg(err.message);
      setTimeout(() => setErrorMsg(""), 6000);
    }
  };



  return (
    <>
      <NavarCompleto />
      <div className="register-container">
        <div className="background-decorations">
          <div className="decoration decoration-1"></div>
          <div className="decoration decoration-2"></div>
          <div className="decoration decoration-3"></div>
        </div>

        <div className="register-wrapper">
          <div className="register-card">
            <div className="register-header">
              <div className="avatar-container">
                <FaCalendarAlt className="avatar-icon" />
              </div>
              <h1 className="register-title">Crear una sucursal</h1>
              <p className="register-subtitle"></p>
            </div>

            <form className="register-form" onSubmit={submitForm}>
              {/* Campo de nombre */}
              <div className="input-group">
                <div className="input-icon">
                  <FaUser className="icon" />
                </div>
                <input
                  type="text"
                  name="name"
                  placeholder="Nombre"
                  value={formData.name}
                  onChange={handleInputChange}
                  className="form-input"
                  required
                />
              </div>

              <center>
                <p className="register-subtitle" >Logo de la sucursal</p>
              </center>
              {/* Campo de imagen */}
              <div className="input-group">
                <div className="input-icon">
                  <FaImage className="icon" />
                </div>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageChange}
                  className="form-input"
                  required
                />
              </div>

              {/* Campo de street */}
              <div className="input-group">
                <div className="input-icon">
                  <FaRoad className="icon" />
                </div>
                <input
                  type="text"
                  name="street"
                  placeholder="Calle"
                  value={formData.street}
                  onChange={handleInputChange}
                  className="form-input"
                  required
                />
              </div>

              {/* Campo de city */}
              <div className="input-group">
                <div className="input-icon">
                  <FaCity className="icon" />
                </div>
                <input
                  type="text"
                  name="city"
                  placeholder="Ciudad"
                  value={formData.city}
                  onChange={handleInputChange}
                  className="form-input"
                  required
                />
              </div>

              {/* Campo de zip_code */}
              <div className="input-group">
                <div className="input-icon">
                  <FaMailBulk className="icon" />
                </div>
                <input
                  type="number"
                  name="zip_code"
                  placeholder="Código postal"
                  value={formData.zip_code}
                  onChange={handleInputChange}
                  className="form-input"
                  required
                />
              </div>

              {errorMsg && (
                <div className="toast-error">
                  <FaExclamationTriangle style={{ marginRight: "0.5rem" }} />
                  {errorMsg}
                </div>
              )}
              {successMsg && (
                <div className="toast-success">
                  <FaCheckCircle style={{ marginRight: "0.5rem" }} />
                  {successMsg}
                </div>
              )}
              
              {/* Botón */}
              <button
                type="submit"
                disabled={isLoading}
                className="submit-button"
              >
                {isLoading ? (
                  <div className="loading-container">
                    <div className="spinner"></div>
                    Procesando...
                  </div>
                ) : (
                  "Agregar sucursal"
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </>
  );
}
