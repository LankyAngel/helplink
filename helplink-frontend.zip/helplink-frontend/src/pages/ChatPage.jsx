import React, { useState, useEffect } from "react";
import Sidebar from "../Components/chat/Sidebar";
import MessageInput from "../Components/chat/MessageInput";
import MessageList from "../Components/chat/MessageList";
import ServerLanding from "../Components/chat/ServerLanding";
import useChat from "../hooks/useChat";
import ServerAdminPanel from "../Components/chat/ServerAdminPanel";
import { v4 as uuidv4 } from "uuid";
import "../assets/style/Chat.css";
import NavarCompleto from "../Components/NavarCompleto";

export default function ChatPage() {
    const [activeChannel, setActiveChannel] = useState(null);
    const { messages, setMessages, sendMessage, sendReaction, reactionMap } = useChat(activeChannel);
    const [replyTo, setReplyTo] = useState(null);
    const [activeServer, setActiveServer] = useState(null);
    const currentUser = localStorage.getItem("username") || "Invitado";
    const [showAdminPanel, setShowAdminPanel] = useState(false);
    const [refreshSidebar, setRefreshSidebar] = useState(false);
    const rawRoles = JSON.parse(localStorage.getItem("server_roles") || "[]");

    const handleSelectChannel = (channelId) => {
        setReplyTo(null);
        setActiveChannel(channelId);
        localStorage.setItem("active_channel", channelId);
    };

    const updateActiveServerMedia = ({ banner, logo }) => {
        setActiveServer((prev) => ({
            ...prev,
            ...(banner && { banner }),
            ...(logo && { logo }),
        }));
    };

    const handleReaction = (msg, emoji) => {
        if (!msg.id || msg.isOptimistic) {
            console.warn("No se puede reaccionar a un mensaje no confirmado aún");
            return;
        }
        sendReaction(String(msg.id), emoji);  // fuerza string
    };

    const myRoleInServer = activeServer
        ? rawRoles.find((r) => r.server__id === activeServer.id)?.role
        : null;

    useEffect(() => {
        if (activeChannel) {
            localStorage.setItem("active_channel", activeChannel);
        }
    }, [activeChannel]);

    useEffect(() => {
        setReplyTo(null);
    }, [activeChannel]);

    // Manejo de respuesta
    const handleReply = (msg) => setReplyTo(msg);
    const cancelReply = () => setReplyTo(null);

    const handleReturnToLanding = async () => {
        setShowAdminPanel(false); // Oculta el panel

        try {
            const res = await fetch(
                `${process.env.REACT_APP_API_URL}/servers/${activeServer.id}/`,
                {
                    headers: {
                        Authorization: `Bearer ${localStorage.getItem("access")}`
                    }
                }
            );
            const updated = await res.json();
            setActiveServer(updated);
        } catch (err) {
            console.error("Error al recargar el servidor:", err);
        }
    };

    // Enviar mensaje normal
    const handleSend = (text, externalData = null) => {
        if (!text.trim() && !externalData?.attachment) return;

        const clientId = uuidv4();

        const tempMessage = {
            id: externalData?.id || undefined,
            content: text,
            timestamp: externalData?.timestamp || new Date().toISOString(),
            sender_id: externalData?.sender_id || 1,
            sender_name: externalData?.sender_name || currentUser,
            reactions: [],
            isOptimistic: !externalData,
            clientId,
            attachment: externalData?.attachment || null,
            original_filename: externalData?.original_filename || null,
            reply_to: replyTo
                ? { id: replyTo.id, content: replyTo.content, sender_name: replyTo.sender_name }
                : null
        };

        setMessages((prev) => [...prev, tempMessage]);

        if (!externalData) {
            sendMessage({
                message: text,
                client_id: clientId,
                ...(replyTo && { reply_to: replyTo.id }),
                ...(externalData?.attachment && {
                    attachment: externalData.attachment,
                    original_filename: externalData.original_filename
                })
            });
        }

        setReplyTo(null);
    };

    return (
        <>
            <NavarCompleto />
            <div className="chat-container">
                <Sidebar
                    onSelectServer={(serverObj) => {
                        setReplyTo(null);
                        setActiveChannel(null);
                        setActiveServer(null);
                        setShowAdminPanel(false);
                        setTimeout(() => {
                            setActiveServer(serverObj);
                        }, 0);
                    }}
                    onSelectChannel={setActiveChannel}
                    refreshTrigger={refreshSidebar}
                    activeServerId={activeServer?.id}
                    activeChannel={activeChannel}
                />

                {activeServer && !activeChannel ? (
                    <div className="server-landing-wrapper">
                        {showAdminPanel ? (
                            <ServerAdminPanel
                                server={activeServer}
                                token={localStorage.getItem("access")}
                                onMediaUpdate={updateActiveServerMedia}
                                onReturn={handleReturnToLanding}
                            />
                        ) : (
                            <ServerLanding
                                server={activeServer}
                                onJoinMainChannel={() => {
                                    const firstChannel = activeServer.channels?.[0];
                                    if (firstChannel) {
                                        setActiveChannel(firstChannel.id);
                                    } else {
                                        alert("Este servidor aún no tiene canales disponibles.");
                                    }
                                }}
                                setShowAdminPanel={setShowAdminPanel}
                                onExitSuccess={() => {
                                    setActiveChannel(null);
                                    setActiveServer(null);
                                    setRefreshSidebar(prev => !prev);
                                }}
                            />
                        )}
                    </div>
                ) : (
                    <div className="chat-main">
                        <header className="chat-header">
                            {activeChannel
                                ? `# ${activeServer?.channels?.find((c) => c.id === activeChannel)?.name || "Canal"}`
                                : "Selecciona un canal"}
                        </header>

                        <section className="chat-messages">
                            <MessageList
                                messages={messages}
                                onReact={handleReaction}
                                onReply={handleReply}
                                reactionMap={reactionMap}
                                currentUser={currentUser}
                            />
                        </section>

                        {activeChannel && (
                            <footer>
                                <MessageInput
                                    onSend={handleSend}
                                    onAttach={() => console.log("Adjuntar aún no implementado")}
                                    replyTo={replyTo}
                                    onCancelReply={cancelReply}
                                    isReadOnly={(() => {
                                        const ch = activeServer?.channels?.find(c => c.id === activeChannel);
                                        return ch ? (!ch.is_event && ch.is_private) : false;
                                    })()}
                                />
                            </footer>
                        )}
                    </div>
                )}
            </div>
        </>
    );
}
