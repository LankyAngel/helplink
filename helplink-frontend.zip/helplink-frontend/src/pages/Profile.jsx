import React, { useState, useEffect } from "react";
import {
  FaUser,
  FaHeart,
  FaCalendarAlt,
  FaEdit,
  FaUsers,
  FaTrophy,
  FaClock,
  FaMapMarkerAlt,
  FaSignOutAlt,
  FaPlus,
  FaLock,
  FaCheckCircle,
} from "react-icons/fa";
import "../assets/style/Profile.css";
import NavarCompleto from "../Components/NavarCompleto";
import { useAuth } from "../contex/AuthProvider";
import {
  getUserInfo,
  getUserEvents,
  getUserAchievements,
} from "../services/authService";
import { useNavigate } from "react-router-dom";
import { rol, getAchievements } from "../services/api";
import { ButtonEditProfile } from "../Components/Buttons";
import { Link } from "react-router-dom";

const Profile = () => {
  const { isAuthenticated, logout } = useAuth();
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("Eventos Participados");
  const [profile, setProfile] = useState(null);
  const [userEvents, setUserEvents] = useState([]);
  const [userAchievements, setUserAchievements] = useState([]);
  const [allAchievements, setAllAchievements] = useState([]);
  const [userRol, setUserRol] = useState(null);
  const [feedbacks, setFeedbacks] = useState([]);
  const [organization, setOrganization] = useState(null);
  const apiURL = process.env.REACT_APP_API_URL;
  const _apiURL = `${apiURL}/feedback/`;

  useEffect(() => {
    const fetchRol = async () => {
      try {
        const r = await rol();
        setUserRol(r);
      } catch (err) {
        console.error("Error obteniendo el rol:", err);
      }
    };
    fetchRol();
  }, []);

  useEffect(() => {
    const fetchProfileAndEvents = async () => {
      const userData = await getUserInfo();
      const username = localStorage.getItem("username");
      if (isAuthenticated) {
        const user = userData.find((u) => u.username === username);
        setProfile(user);

        const events = await getUserEvents();
        const filteredEvents = events.filter(
          (e) => e.user.username === username
        );
        setUserEvents(filteredEvents);

        // const achievements = await getUserAchievements();
        // setUserAchievements(achievements);

        // Obtener todos los logros disponibles
        const allAchievementsData = await getAchievements();
        setAllAchievements(allAchievementsData);

        // Obtener logros del usuario
        const achievements = await getUserAchievements();
        setUserAchievements(achievements);

        //Obtener feedbacks
        const resFeedback = await fetch(_apiURL);
        const dataFeedback = await resFeedback.json();
        setFeedbacks(dataFeedback);
      }
    };

    fetchProfileAndEvents();
  }, [isAuthenticated, navigate]);

  useEffect(() => {
    const fetchOrganizationStatus = async () => {
      const userData = await getUserInfo();
      //console.log("userData completo:", userData);
      const username = localStorage.getItem("username");
      if (isAuthenticated) {
        const user = userData.find((u) => u.username === username);
        const statusOrg = user.organization?.status;
        setOrganization(statusOrg);
      }
    };
    fetchOrganizationStatus();
  }, [isAuthenticated]);

  const handleLogOut = async () => {
    try {
      await logout();
    } catch (error) {
      alert("Error", error.message);
    }
  };

  const renderApprovalStatus = () => {
    let title = "";
    let description = "";

    if (organization === "pending") {
      title = "Organización en Revisión";
      description =
        "Tu organización aún está pendiente de aprobación por un administrador. Serás notificado cuando sea aceptada.";
    } else if (organization === "rejected") {
      title = "Organización Denegada";
      description =
        "Tu solicitud para registrar una organización ha sido denegada. Puede contactar al administrador.";
    } else if (organization === "approved") {
      title = "Organización Aprobada";
      description =
        "Tu solicitud para registrar una organización ha sido aprovada. Cierra sesión e inicia sesión nuevamente";
    } else {
      return null; // No mostrar nada si el estado no es relevante
    }

    return (
      <div className="content-section">
        <div className="content-header">
          <h2 className="content-title">Estatus de Aprobación</h2>
        </div>
        <div className="achievement-card">
          <div className="achievement-content">
            <div className="achievement-icon">
              <span className="icon-emoji">
                <FaClock style={{ fill: "black" }} />
              </span>
            </div>
            <div className="achievement-info">
              <h3 className="achievement-title">{title}</h3>
              <p className="achievement-description">{description}</p>
              <div className="achievement-date">
                <FaCalendarAlt className="detail-icon" />
                <span>
                  {new Date().toLocaleDateString("es-MX", {
                    day: "2-digit",
                    month: "long",
                    year: "numeric",
                  })}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };

  const goAddOrganization = (e) => {
    e.preventDefault();
    navigate("/addOrganization");
  };

  const tabs = [
    { name: "Eventos Participados", icon: <FaUsers /> },
    { name: "Eventos Activos", icon: <FaClock /> },
    { name: "Logros", icon: <FaTrophy /> },
    ...(organization === "pending" || organization === "rejected"
      ? [{ name: "Estatus de Aprobación", icon: <FaClock /> }]
      : []),
  ];

  const renderEvents = (type) => {
    const username = localStorage.getItem("username");

    const filtered = userEvents.filter(
      (e) =>
        e.user.username === username &&
        ((type === "finished" && e.event.status.toLowerCase() === "finished") ||
          (type === "active" && e.event.status.toLowerCase() !== "finished"))
    );

    return (
      <div className="profile-content-section">
        <div className="content-header">
          <h2 className="content-title">
            {type === "finished" ? "Eventos Participados" : "Eventos Activos"}
          </h2>
          <div className="content-badge">
            {filtered.length} {filtered.length === 1 ? "Evento" : "Eventos"}
          </div>
        </div>
        <div className="past-events-grid">
          {filtered.map((info, index) => (
            <div key={index} className="event-card">
              <div className="event-header">
                <h3 className="event-title">{info.event.title}</h3>
              </div>
              <div className="event-details">
                <div className="event-detail">
                  <FaCalendarAlt className="detail-icon" />
                  <span>{info.event.event_date}</span>
                </div>
                <div className="event-detail">
                  <FaClock className="detail-icon" />
                  <span>{info.event.start_time?.substring(0, 5)}</span>
                </div>
                {/* Mostrar botón de Ver Detalles para eventos finalizados sin feedback */}
                {type === "finished" &&
                  !feedbacks.some(
                    (f) => f.user === info.user.id && f.event === info.event.id
                  ) && (
                    <div className="event-actions">
                      <Link to={`/addFeedback/${info.event.id}`}>
                        <button
                          className="events-card-join-btn"
                          style={{ marginLeft: "1rem" }}
                        >
                          Calificar
                        </button>
                      </Link>
                    </div>
                  )}

                {/* Mostrar botón de Ver Detalles para eventos activos */}
                {type === "active" && (
                  <div className="event-actions">
                    <Link to={`/Events/${info.event.id}`}>
                      <button className="events-card-join-btn">
                        Ver Detalles
                      </button>
                    </Link>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderAchievements = () => {
    // Obtener nombres de logros que ya tiene el usuario
    const userAchievementNames = userAchievements.map(
      (achievement) => achievement.name
    );

    // Organizar logros por categorías basándose en el orden de la base de datos
    const categorizedAchievements = {
      "Participación en eventos": { unlocked: [], locked: [] },
      "Asistencia continua": { unlocked: [], locked: [] },
      "Retroalimentaciones positivas": { unlocked: [], locked: [] },
      "Logros de interacción": { unlocked: [], locked: [] },
      "Tiempo en la plataforma": { unlocked: [], locked: [] },
    };

    // Definir rangos de índices para cada categoría (basado en el orden que diste)
    const categoryRanges = {
      "Participación en eventos": [0, 4], // Primer evento a Ejemplo de servicio (5 logros)
      "Asistencia continua": [5, 7], // Constancia básica a Comprometido con la causa (3 logros)
      "Retroalimentaciones positivas": [8, 10], // Primera buena impresión a Voluntario ejemplar (3 logros)
      "Logros de interacción": [11, 13], // Usuario social a Conector comunitario (3 logros)
      "Tiempo en la plataforma": [14, 16], // Recién llegado a Veterano de la ayuda (3 logros)
    };

    // Organizar logros por categoría usando los rangos
    allAchievements.forEach((achievement, index) => {
      Object.entries(categoryRanges).forEach(([categoryName, [start, end]]) => {
        if (index >= start && index <= end) {
          if (userAchievementNames.includes(achievement.name)) {
            // El usuario tiene este logro
            const userAchievement = userAchievements.find(
              (ach) => ach.name === achievement.name
            );
            categorizedAchievements[categoryName].unlocked.push(
              userAchievement
            );
          } else {
            // El usuario no tiene este logro
            categorizedAchievements[categoryName].locked.push(achievement);
          }
        }
      });
    });

    return (
      <div className="content-section">
        <div className="content-header">
          <h2 className="content-title">Logros</h2>
          <div className="content-badge content-badge-yellow">
            {userAchievements.length} de {allAchievements.length} Logros
            Obtenidos
          </div>
        </div>

        {Object.entries(categorizedAchievements).map(
          ([categoryName, achievements]) => (
            <div key={categoryName} className="achievement-category">
              <h3 className="category-title">{categoryName}</h3>

              {/* Logros desbloqueados */}
              {achievements.unlocked.length > 0 && (
                <div className="achievements-section">
                  <h4 className="section-subtitle">
                    <FaCheckCircle className="section-icon unlocked" />
                    Desbloqueados ({achievements.unlocked.length})
                  </h4>
                  <div className="achievements-grid">
                    {achievements.unlocked.map((logro, index) => (
                      <div key={index} className="achievement-card unlocked">
                        <div className="achievement-content">
                          <div className="achievement-icon">
                            <FaTrophy className="icon-emoji unlocked" />
                          </div>
                          <div className="achievement-info">
                            <h3 className="achievement-title">{logro.name}</h3>
                            <p className="achievement-description">
                              {logro.description}
                            </p>
                            <div className="achievement-date">
                              <FaCalendarAlt className="detail-icon" />
                              <span>
                                Desbloqueado el{" "}
                                {new Date(logro.unlocked_at).toLocaleDateString(
                                  "es-MX",
                                  {
                                    day: "2-digit",
                                    month: "long",
                                    year: "numeric",
                                  }
                                )}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Logros bloqueados */}
              {achievements.locked.length > 0 && (
                <div className="achievements-section">
                  <h4 className="section-subtitle">
                    <FaLock className="section-icon locked" />
                    Por desbloquear ({achievements.locked.length})
                  </h4>
                  <div className="achievements-grid">
                    {achievements.locked.map((logro, index) => (
                      <div key={index} className="achievement-card locked">
                        <div className="achievement-content">
                          <div className="achievement-icon locked">
                            <FaLock className="icon-emoji locked" />
                          </div>
                          <div className="achievement-info">
                            <h3 className="achievement-title locked">
                              {logro.name}
                            </h3>
                            <p className="achievement-description locked">
                              {logro.description}
                            </p>
                            <div className="achievement-status">
                              <span>Logro bloqueado</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )
        )}
      </div>
    );
  };

  const renderContent = () => {
    if (activeTab === "Eventos Participados") return renderEvents("finished");
    if (activeTab === "Eventos Activos") return renderEvents("active");
    if (activeTab === "Estatus de Aprobación") return renderApprovalStatus();
    return renderAchievements();
  };

  return (
    <>
      <NavarCompleto login={true} />
      <div className="profile-container">
        <div className="profile-card">
          <div className="profile-header">
            <div className="header-overlay"></div>
            <div className="profile-avatar">
              <div className="avatar-circle">
                <FaUser className="avatar-icon" />
              </div>
            </div>
          </div>

          <div className="profile-content">
            <div className="profile-layout">
              <div className="profile-sidebar">
                <div className="profile-info">
                  <h1 className="profile-name">
                    {profile?.first_name} {profile?.last_name}
                  </h1>
                  <div className="profile-role">
                    <FaHeart className="role-icon" />
                    {profile?.global_role.role === "volunteer"
                      ? "Voluntario"
                      : profile?.global_role.role === "organization_staff"
                        ? "Staff"
                        : profile?.global_role.role === "organization_admin"
                          ? "Administrador"
                          : ""}
                  </div>
                  <div className="profile-date">
                    <FaCalendarAlt className="date-icon" />
                    {profile?.date_joined && (
                      <span>
                        Se unió el{" "}
                        {new Date(profile.date_joined).toLocaleDateString(
                          "es-MX",
                          {
                            day: "2-digit",
                            month: "long",
                            year: "numeric",
                          }
                        )}
                      </span>
                    )}
                  </div>
                </div>

                <ButtonEditProfile />

                {userRol !== 3 && userRol !== 2 && (
                  <a
                    className="logout-link"
                    href="/"
                    onClick={goAddOrganization}
                  >
                    <button className="edit-profile-btn">
                      <FaEdit className="btn-icon" /> Organización
                    </button>
                  </a>
                )}

                <a className="logout-link" href="/home" onClick={handleLogOut}>
                  <button className="logout-btn">
                    <FaSignOutAlt className="btn-icon" /> Cerrar Sesión
                  </button>
                </a>

                <div className="nav-tabs">
                  {tabs.map((tab) => (
                    <button
                      key={tab.name}
                      onClick={() => setActiveTab(tab.name)}
                      className={`nav-tab ${activeTab === tab.name ? "nav-tab-active" : ""}`}
                    >
                      <span className="tab-icon">{tab.icon}</span>
                      <span className="tab-name">{tab.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="profile-main">
                <div className="main-content">{renderContent()}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Profile;
