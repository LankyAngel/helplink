import React, { useState, useEffect } from "react";
import "../assets/style/Events.css"; // Usa el mismo CSS moderno que Events.jsx
import NavarCompleto from "../Components/NavarCompleto";
import {
  FaCalendarAlt,
  FaClock,
  FaMapMarkerAlt,
  FaUsers,
} from "react-icons/fa";
import { Link } from "react-router-dom";
import { useAuth } from "../contex/AuthProvider";
import {
  getCategorias,
  opcionesFecha,
  transformarEventos,
  obtenerFechasReferencia,
  filtrarEventos,
  formatearFecha,
} from "../Components/Filtrers";

const ShowEventsOrganization = () => {
  const { org_code } = useAuth();
  const [eventos, setEventos] = useState([]);
  const [categorias, setCategorias] = useState([]);
  const [filtroCategoria, setFiltroCategoria] = useState("todos");
  const [filtroFecha, setFiltroFecha] = useState("todos");

  const apiURL = process.env.REACT_APP_API_URL;

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [eventRes, categoriasResRaw] = await Promise.all([
          fetch(`${apiURL}/all-events`),
          getCategorias(),
        ]);

        if (!eventRes.ok) throw new Error("Error al cargar eventos");

        const eventosData = await eventRes.json();

        // Filtrar eventos solo de la organización actual y publicados
        const eventosOrg = eventosData.filter(
          (evento) =>
            evento.status === "published" &&
            evento.branch?.organization?.id === Number(org_code)
        );

        const eventosFormateados = transformarEventos(eventosOrg);
        setEventos(eventosFormateados);

        const categoriasTransformadas = [
          { value: "todos", label: "Todas las categorías" },
          ...categoriasResRaw.map((cat) => {
            const nombre = cat.name || cat.label || "Otros";
            const value = nombre
              .toLowerCase()
              .normalize("NFD")
              .replace(/[\u0300-\u036f]/g, "")
              .replace(/\s+/g, "-");
            return { value, label: nombre };
          }),
        ];
        setCategorias(categoriasTransformadas);
      } catch (error) {
        console.error("Error al cargar eventos u obtener categorías:", error);
      }
    };

    fetchData();
  }, [apiURL, org_code]);

  const fechasReferencia = obtenerFechasReferencia();

  const eventosFiltrados = filtrarEventos(
    eventos,
    filtroCategoria,
    filtroFecha,
    fechasReferencia
  );

  return (
    <>
      <NavarCompleto />
      <div className="events-main-container">
        <header className="events-hero-header">
          <div className="events-hero-overlay"></div>
          <div className="events-hero-gradient"></div>
          <div className="events-hero-decoration-1"></div>
          <div className="events-hero-decoration-2"></div>
          <div className="events-hero-content">
            <h1 className="events-hero-title">Eventos de la organización</h1>
            <p className="events-hero-subtitle">
              Gestiona y visualiza tus eventos públicos
            </p>
          </div>
        </header>

        <div className="events-content-container">
          <div className="events-filters-container">
            <div className="events-filters-card">
              <div className="events-filters-content">
                <div className="events-filter-wrapper">
                  <select
                    value={filtroCategoria}
                    onChange={(e) => setFiltroCategoria(e.target.value)}
                    className="events-filter-select"
                  >
                    {categorias.map((c) => (
                      <option key={c.value} value={c.value}>
                        {c.label}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="events-filter-wrapper">
                  <select
                    value={filtroFecha}
                    onChange={(e) => setFiltroFecha(e.target.value)}
                    className="events-filter-select"
                  >
                    {opcionesFecha.map((o) => (
                      <option key={o.value} value={o.value}>
                        {o.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
          </div>

          <div className="events-grid">
            {eventosFiltrados.map((evento) => (
              <Link
                to={`/Events/${evento.id}`}
                key={evento.id}
                className="events-card"
                style={{
                  cursor: "pointer",
                  textDecoration: "none",
                  color: "inherit",
                }}
              >
                <div className="events-card-image">
                  <img
                    src={evento.imagen}
                    alt={evento.titulo}
                    className="events-card-img"
                  />
                  <div
                    className={`events-card-category category-${evento.categoriaCss}`}
                  >
                    {evento.categoriaTexto}
                  </div>
                </div>
                <div className="events-card-content">
                  <h3 className="events-card-title">{evento.titulo}</h3>
                  <p className="events-card-description">
                    {evento.descripcion}
                  </p>
                  <div className="events-card-info">
                    <div className="events-card-info-item">
                      <FaCalendarAlt style={{ marginRight: "6px" }} />
                      {formatearFecha(evento.fecha)}
                    </div>
                    <div className="events-card-info-item">
                      <FaClock style={{ marginRight: "6px" }} />
                      {evento.hora} hrs
                    </div>
                    <div className="events-card-info-item">
                      <FaMapMarkerAlt style={{ marginRight: "6px" }} />
                      {evento.ubicacion}
                    </div>
                    <div className="events-card-info-item">
                      <FaUsers style={{ marginRight: "6px" }} />
                      Capacidad: {evento.capacidad}
                    </div>
                  </div>
                  <div className="events-card-footer">
                    <div className="events-card-organizer">
                      <span className="events-card-organizer-label">
                        Organizado por
                      </span>
                      <span className="events-card-organizer-name">
                        {evento.organizador}
                      </span>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          {eventosFiltrados.length === 0 && (
            <div className="events-empty-state">
              <div className="events-empty-container">
                <span className="events-empty-icon">
                  <FaCalendarAlt />
                </span>
                <h3 className="events-empty-title">
                  No hay eventos disponibles
                </h3>
                <p className="events-empty-text">
                  Intenta cambiar los filtros para ver más eventos
                </p>
              </div>
            </div>
          )}

          <div className="events-cta-section">
            <div className="events-cta-container">
              <div className="events-cta-overlay"></div>
              <div className="events-cta-decoration-1"></div>
              <div className="events-cta-decoration-2"></div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default ShowEventsOrganization;
