import React, { useEffect, useState, memo } from "react";
import { useParams, Link } from "react-router-dom";
import NavarCompleto from "../Components/NavarCompleto"; // Asegúrate de que la ruta sea correcta
import "../assets/style/OrganizationProfile.css";
import {
  FaEnvelope,
  FaPhone,
  FaStore,
  FaArrowLeft,
  FaBuilding,
  FaSpinner,
  FaCalendarAlt,
  FaRoad,
  FaStar,
  FaRegStar,
  FaCommentDots,
  FaComment,
  FaCalendarCheck,
  FaCalendarTimes,
} from "react-icons/fa";
import * as OrgTopic from "postcss-selector-parser";


const formatDate = (dateString) => {
  if (!dateString) return "Fecha no disponible";
  const options = { year: "numeric", month: "long", day: "numeric" };
  return new Date(dateString).toLocaleDateString("es-MX", options);
};

const Rating = memo(({ score, maxScore = 5 }) => (
  <div className="rating-stars">
    {[...Array(maxScore)].map((_, index) =>
      index < score ? (
        <FaStar key={index} color="#ffc107" />
      ) : (
        <FaRegStar key={index} color="#e0e0e0" />
      )
    )}
    <span className="rating-text">{`(${score}/${maxScore})`}</span>
  </div>
));
Rating.displayName = "Rating";

const OrganizationHeader = memo(
  ({ name, eventAlerts, onToggleEventAlerts, onStartChat }) => (
    <header className="organization-header">
      <div className="header-title">
        <FaBuilding className="org-icon" />
        <h1>{name}</h1>
      </div>
      <div className="header-actions">
        <button className="chat-button" onClick={onStartChat}>
          <FaComment /> Iniciar Chat
        </button>
        <button
          className={`alerts-button ${eventAlerts ? "active" : ""}`}
          onClick={onToggleEventAlerts}
        >
          {eventAlerts ? (
            <>
              <FaCalendarCheck /> Alertas ON
            </>
          ) : (
            <>
              <FaCalendarTimes /> Alertas OFF
            </>
          )}
        </button>
      </div>
    </header>
  )
);
OrganizationHeader.displayName = "OrganizationHeader";

const InfoSection = memo(({ email, phone }) => (
  <>
    <h2>Contacto</h2>
    <div className="info-item">
      <FaEnvelope className="icon" />
      <a href={`mailto:${email}`}>{email}</a>
    </div>
    <div className="info-item">
      <FaPhone className="icon" />
      <a href={`tel:${phone}`}>{phone}</a>
    </div>
  </>
));
InfoSection.displayName = "InfoSection";

const BranchList = memo(({ branches }) => (
  <>
    <h2>
      <FaStore className="icon" /> Sucursales
    </h2>
    {branches?.length > 0 ? (
      <ul className="branch-list">
        {branches.map(({ id, name, street }) => (
          <li key={id}>
            <div className="branch-info">
              <FaStore className="icon" />
              <span className="branch-name">{name}</span>
            </div>
            <div className="branch-address">
              <FaRoad className="icon address-icon" />
              <span>{street}</span>
            </div>
          </li>
        ))}
      </ul>
    ) : (
      <p>No hay sucursales registradas.</p>
    )}
  </>
));
BranchList.displayName = "BranchList";

const EventList = memo(({ events }) => (
  <>
    <h2>
      <FaCalendarAlt className="icon" /> Eventos Recientes
    </h2>
    {events?.length > 0 ? (
      <ul className="activity-list">
        {events.map(({ id, title, event_date }) => (
          <li key={id}>
            <Link to={`/events/${id}`}>
              <div className="activity-item">
                <FaCalendarAlt className="icon" />
                <div className="activity-details">
                  <span className="activity-title">{title}</span>
                  <span className="activity-date">{formatDate(event_date)}</span>
                </div>
              </div>
            </Link>
          </li>
        ))}
      </ul>
    ) : (
      <p>No hay eventos recientes.</p>
    )}
  </>
));
EventList.displayName = "EventList";

const FeedbackList = memo(({ feedbacks }) => (
  <>
    <h2>
      <FaCommentDots className="icon" /> Retroalimentación de Usuarios
    </h2>
    {feedbacks?.length > 0 ? (
      <ul className="feedback-list">
        {feedbacks.map(({ id, comment, user_name, event, rating }) => (
          <li key={id} className="feedback-card">
            <p className="feedback-comment">{comment}</p>
            <div className="feedback-footer">
              <span className="feedback-user">
                ~ {user_name} (para {event})
              </span>
              <Rating score={rating} />
            </div>
          </li>
        ))}
      </ul>
    ) : (
      <p>No hay retroalimentación disponible.</p>
    )}
  </>
));
FeedbackList.displayName = "FeedbackList";

const TABS = [
  { key: "contact", label: "Contacto" },
  { key: "branches", label: "Sucursales" },
  { key: "events", label: "Eventos Recientes" },
];

const OrganizationContent = ({
  organization,
  eventAlerts,
  onToggleEventAlerts,
  onStartChat,
}) => {
  const {
    name,
    description,
    email,
    phone_number,
    branches,
    events,
    feedbacks,
  } = organization;

  const [activeView, setActiveView] = useState("contact");

  const renderActiveView = () => {
    switch (activeView) {
      case "contact":
        return <InfoSection email={email} phone={phone_number} />;
      case "branches":
        return <BranchList branches={branches} />;
      case "events":
        return <EventList events={events} />;
      default:
        return <InfoSection email={email} phone={phone_number} />;
    }
  };

  return (
    <>
      <OrganizationHeader
        name={name}
        eventAlerts={eventAlerts}
        onToggleEventAlerts={onToggleEventAlerts}
        onStartChat={onStartChat}
      />

      <div className="profile-grid-container">
        <div className="full-width-section">
          <div className="profile-card">
            <h2>Acerca de la Organización</h2>
            <p>{description}</p>
          </div>
        </div>

        <div className="full-width-section">
          <div className="profile-card">
            <div className="tab-container">
              {TABS.map((tab) => (
                <button
                  key={tab.key}
                  className={`tab-button ${activeView === tab.key ? "active" : ""}`}
                  onClick={() => setActiveView(tab.key)}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <div className="dynamic-content-area">{renderActiveView()}</div>
          </div>
        </div>

        <div className="full-width-section">
          <div className="profile-card">
            <FeedbackList feedbacks={feedbacks} />
          </div>
        </div>
      </div>
    </>
  );
};

const OrganizationDetail = () => {
  const { id } = useParams();
  const apiURL = process.env.REACT_APP_API_URL;

  const [organization, setOrganization] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [eventAlerts, setEventAlerts] = useState(false);

  const handleEventAlertsToggle = async () => {
    const pushNotificationToken = localStorage.getItem("FCMToken");

    if (!pushNotificationToken) {
      alert("No se pudo obtener el token de notificación para las alertas.");
      return;
    }

    const endpoint = eventAlerts ? 'unsubscribe' : 'subscribe';
    const newAlertState = !eventAlerts;
    const orgtopic = organization.id + "OrgTopic";
    try {
      const response = await fetch(`${apiURL}/notifications/${endpoint}/`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${localStorage.getItem("access")}`,
        },

        body: JSON.stringify({
          "token": pushNotificationToken,
          "topic": orgtopic,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.detail || `Error al ${newAlertState ? 'suscribirse' : 'desuscribirse'}`);
      }

      setEventAlerts(newAlertState);
      alert(`Alertas ${newAlertState ? 'activadas' : 'desactivadas'} correctamente.`);

    } catch (err) {
      alert(`Error: ${err.message}`);
    }
  };

  const handleStartChat = async () => {
    if (!organization?.id) return;

    try {
      const response = await fetch(`${apiURL}/servers/join/by-organization/${organization.id}/`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${localStorage.getItem("access")}`,
        },
      });

      const data = await response.json();

      if (!response.ok && data?.detail !== "Ya estás unido al servidor.") {
        throw new Error(data?.detail || "No se pudo unir al servidor.");
      }

      // ✅ Ya unido, ahora redirige al chat
      window.location.href = `/messages`; // o `/chat/${organization.server.id}` si usas rutas específicas

    } catch (err) {
      alert(`Error al iniciar chat: ${err.message}`);
    }
  };

  useEffect(() => {
    const fetchOrganization = async () => {
      setLoading(true);
      setError(null);
      try {
        const response = await fetch(`${apiURL}/organizations/${id}/`);
        if (!response.ok) {
          throw new Error(
            `Error ${response.status}: No se pudo cargar la organización.`
          );
        }
        const data = await response.json();
        setOrganization(data);

      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchOrganization();
  }, [id, apiURL]);

  const renderContent = () => {
    if (loading) {
      return (
        <div className="center-content">
          <FaSpinner className="loading-spinner" />
          <p>Cargando...</p>
        </div>
      );
    }
    if (error) {
      return (
        <div className="center-content error-message">
          <p>{error}</p>
          <Link to="/events" className="back-link">
            <FaArrowLeft className="icon" /> Volver
          </Link>
        </div>
      );
    }
    if (!organization) {
      return (
        <div className="center-content">
          <p>Organización no encontrada.</p>
          <Link to="/events" className="back-link">
            <FaArrowLeft className="icon" /> Volver
          </Link>
        </div>
      );
    }
    return (
      <OrganizationContent
        organization={organization}
        eventAlerts={eventAlerts}
        onToggleEventAlerts={handleEventAlertsToggle}
        onStartChat={handleStartChat}
      />
    );
  };

  return (
    <>
      <NavarCompleto />
      <main className="organization-detail-container">{renderContent()}</main>
    </>
  );
};

export default OrganizationDetail;