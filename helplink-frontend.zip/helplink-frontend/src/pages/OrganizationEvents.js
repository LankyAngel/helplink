// src/pages/OrganizationEvents.js
import React, { useEffect, useState } from "react";
import {
  FaCalendarAlt,
  FaEdit,
  FaTrash,
  FaPlus,
  FaArrowLeft,
  FaMapMarkerAlt,
  FaClock,
  FaUsers,
  FaStar,
  FaSearch,
  FaFilter,
  FaSort,
  FaEye,
  FaTicketAlt,
  FaCalendarDay,
  FaCalendarWeek,
  FaChartLine,
  FaCheckCircle,
  FaExclamationTriangle,
  FaPause,
  FaTags,
} from "react-icons/fa";
import { getOrganizationDashboard, deleteEvent } from "../services/api";
import NavarCompleto from "../Components/NavarCompleto";
import { useNavigate } from "react-router-dom";
import "../assets/style/OrganizationEvents.css";

const OrganizationEvents = () => {
  const [events, setEvents] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [sortBy, setSortBy] = useState("date");
  const [sortOrder, setSortOrder] = useState("asc");
  const [showFilters, setShowFilters] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const navigate = useNavigate();

  const fetchEvents = async () => {
    const orgId = localStorage.getItem("organizationId");
    if (!orgId) return;

    try {
      const dashboardData = await getOrganizationDashboard(orgId);
      setEvents(dashboardData.active_events || []);
      setTimeout(() => setIsLoaded(true), 300);
    } catch (error) {
      console.error("Error fetching events:", error);
      setEvents([]);
      setTimeout(() => setIsLoaded(true), 300);
    }
  };

  const handleDelete = async (eventId) => {
    if (window.confirm("¿Estás seguro de eliminar este evento?")) {
      try {
        await deleteEvent(eventId);
        fetchEvents();
      } catch (error) {
        console.error("Error deleting event:", error);
      }
    }
  };

  const handleEdit = (eventId) => {
    navigate(`/organizationAdminPanel/events/edit/${eventId}`);
  };

  const handleView = (eventId) => {
    navigate(`/events/${eventId}`);
  };

  const handleCreateEvent = () => {
    navigate("/AddEvent");
  };

  const handleBack = () => {
    navigate("/organizationAdminPanel");
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("es-ES", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  };

  const formatTime = (timeString) => {
    if (!timeString) return "Sin hora";
    return timeString.slice(0, 5);
  };

  const getEventStatus = (event) => {
    const now = new Date();
    const eventDate = new Date(event.date);

    if (event.status === "cancelled") {
      return {
        text: "Cancelado",
        class: "cancelled",
        icon: FaExclamationTriangle,
      };
    }
    if (event.status === "draft") {
      return { text: "Borrador", class: "draft", icon: FaPause };
    }
    if (eventDate < now) {
      return { text: "Finalizado", class: "finished", icon: FaCheckCircle };
    }
    if (event.status === "published") {
      return { text: "Publicado", class: "published", icon: FaCheckCircle };
    }
    return { text: "Programado", class: "scheduled", icon: FaClock };
  };

  const getEventPriority = (index) => {
    if (index === 0)
      return {
        icon: FaStar,
        class: "organization-event-priority-1",
        text: "Destacado",
      };
    if (index === 1)
      return {
        icon: FaStar,
        class: "organization-event-priority-2",
        text: "Importante",
      };
    if (index === 2)
      return {
        icon: FaStar,
        class: "organization-event-priority-3",
        text: "Relevante",
      };
    return {
      icon: FaCalendarAlt,
      class: "organization-event-priority-default",
      text: "Regular",
    };
  };

  const filteredAndSortedEvents = events
    .filter((event) => {
      const matchesSearch =
        event.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        event.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (event.branch_name &&
          event.branch_name.toLowerCase().includes(searchTerm.toLowerCase()));

      const matchesStatus =
        statusFilter === "all" || event.status === statusFilter;
      const matchesCategory =
        categoryFilter === "all" || event.category === categoryFilter;

      return matchesSearch && matchesStatus && matchesCategory;
    })
    .sort((a, b) => {
      let aValue, bValue;

      switch (sortBy) {
        case "title":
          aValue = a.title.toLowerCase();
          bValue = b.title.toLowerCase();
          break;
        case "date":
          aValue = new Date(a.date);
          bValue = new Date(b.date);
          break;
        case "status":
          aValue = a.status;
          bValue = b.status;
          break;
        case "attendees":
          aValue = a.attendees_count || 0;
          bValue = b.attendees_count || 0;
          break;
        default:
          aValue = new Date(a.date);
          bValue = new Date(b.date);
      }

      if (sortOrder === "asc") {
        return aValue > bValue ? 1 : -1;
      } else {
        return aValue < bValue ? 1 : -1;
      }
    });

  const totalEvents = events.length;
  const publishedEvents = events.filter((e) => e.status === "published").length;
  const draftEvents = events.filter((e) => e.status === "draft").length;
  const totalAttendees = events.reduce(
    (sum, e) => sum + (e.attendees_count || 0),
    0
  );

  const categories = [
    ...new Set(events.map((e) => e.category).filter(Boolean)),
  ];

  useEffect(() => {
    fetchEvents();
  }, []);

  return (
    <div className="organization-event-container">
      <div className="organization-event-bg-decoration">
        <div className="organization-event-floating-shape organization-event-shape-1"></div>
        <div className="organization-event-floating-shape organization-event-shape-2"></div>
        <div className="organization-event-floating-shape organization-event-shape-3"></div>
      </div>

      <NavarCompleto login={true} />

      <div className={`organization-event-panel ${isLoaded ? "loaded" : ""}`}>
        <div className="organization-event-header">
          <div className="organization-event-header-content">
            <button
              onClick={handleBack}
              className="organization-event-back-btn"
            >
              <FaArrowLeft />
              Volver al Panel
            </button>

            <div className="organization-event-title-section">
              <h1>
                <FaCalendarAlt className="organization-event-title-icon" />
                <span className="organization-event-text-primary">
                  Gestión de
                </span>
                <span className="organization-event-text-gradient">
                  Eventos
                </span>
              </h1>
              <p className="organization-event-subtitle">
                Administra todos los eventos de tu organización
              </p>
            </div>

            <button
              onClick={handleCreateEvent}
              className="organization-event-create-btn"
            >
              <FaPlus />
              Nuevo Evento
            </button>
          </div>
        </div>

        <div className="organization-event-stats-grid">
          <div className="organization-event-stat-card primary">
            <div className="organization-event-stat-icon">
              <FaCalendarAlt />
            </div>
            <div className="organization-event-stat-info">
              <div className="organization-event-stat-number">
                {totalEvents}
              </div>
              <div className="organization-event-stat-label">Total Eventos</div>
            </div>
          </div>

          <div className="organization-event-stat-card success">
            <div className="organization-event-stat-icon">
              <FaCheckCircle />
            </div>
            <div className="organization-event-stat-info">
              <div className="organization-event-stat-number">
                {publishedEvents}
              </div>
              <div className="organization-event-stat-label">Publicados</div>
            </div>
          </div>

          <div className="organization-event-stat-card warning">
            <div className="organization-event-stat-icon">
              <FaPause />
            </div>
            <div className="organization-event-stat-info">
              <div className="organization-event-stat-number">
                {draftEvents}
              </div>
              <div className="organization-event-stat-label">Borradores</div>
            </div>
          </div>

          <div className="organization-event-stat-card info">
            <div className="organization-event-stat-icon">
              <FaUsers />
            </div>
            <div className="organization-event-stat-info">
              <div className="organization-event-stat-number">
                {totalAttendees}
              </div>
              <div className="organization-event-stat-label">
                Total Asistentes
              </div>
            </div>
          </div>
        </div>

        <div className="organization-event-controls">
          <div className="organization-event-search-section">
            <div className="organization-event-search-box">
              <FaSearch />
              <input
                type="text"
                placeholder="Buscar eventos por título, descripción o sucursal..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>

            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`organization-event-filter-toggle ${showFilters ? "active" : ""}`}
            >
              <FaFilter />
              Filtros
            </button>
          </div>

          {showFilters && (
            <div className="organization-event-filters">
              <div className="organization-event-filter-group">
                <label htmlFor="organization-event-filter-group">Estado:</label>
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                >
                  <option value="all">Todos</option>
                  <option value="published">Publicados</option>
                  <option value="draft">Borradores</option>
                  <option value="cancelled">Cancelados</option>
                </select>
              </div>

              {categories.length > 0 && (
                <div className="organization-event-filter-group">
                  <label htmlFor="organization-event-filter-group">
                    Categoría:
                  </label>
                  <select
                    value={categoryFilter}
                    onChange={(e) => setCategoryFilter(e.target.value)}
                  >
                    <option value="all">Todas</option>
                    {categories.map((category) => (
                      <option key={category} value={category}>
                        {category}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <div className="organization-event-filter-group">
                <label htmlFor="organization-event-filter-group">
                  Ordenar por:
                </label>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value)}
                >
                  <option value="date">Fecha</option>
                  <option value="title">Título</option>
                  <option value="status">Estado</option>
                  <option value="attendees">Asistentes</option>
                </select>
              </div>

              <button
                onClick={() =>
                  setSortOrder(sortOrder === "asc" ? "desc" : "asc")
                }
                className="organization-event-sort-order"
              >
                <FaSort />
                {sortOrder === "asc" ? "Ascendente" : "Descendente"}
              </button>
            </div>
          )}
        </div>

        <div className="organization-event-list">
          {filteredAndSortedEvents.length === 0 ? (
            <div className="organization-event-empty-state">
              <FaCalendarAlt />
              <h3>No hay eventos</h3>
              <p>
                {searchTerm ||
                statusFilter !== "all" ||
                categoryFilter !== "all"
                  ? "No se encontraron eventos con los filtros aplicados."
                  : "Aún no has creado ningún evento. ¡Crea tu primer evento para comenzar!"}
              </p>
              {!searchTerm &&
                statusFilter === "all" &&
                categoryFilter === "all" && (
                  <button
                    onClick={handleCreateEvent}
                    className="organization-event-create-first-btn"
                  >
                    <FaPlus />
                    Crear Primer Evento
                  </button>
                )}
            </div>
          ) : (
            <div className="organization-event-grid">
              {filteredAndSortedEvents.map((event, index) => {
                const priority = getEventPriority(index);
                const status = getEventStatus(event);
                const PriorityIcon = priority.icon;
                const StatusIcon = status.icon;

                return (
                  <div key={event.id} className="organization-event-card">
                    <div className="organization-event-card-header">
                      <div className="organization-event-card-meta">
                        <div
                          className={`organization-event-priority ${priority.class}`}
                        >
                          <PriorityIcon />
                          <span className="organization-event-priority-text">
                            {priority.text}
                          </span>
                        </div>
                        <div
                          className={`organization-event-status ${status.class}`}
                        >
                          <StatusIcon />
                          {status.text}
                        </div>
                      </div>

                      <h3 className="organization-event-card-title">
                        {event.title}
                      </h3>

                      <div className="organization-event-card-info">
                        <div className="organization-event-card-date">
                          <FaCalendarDay />
                          <span>{formatDate(event.date)}</span>
                        </div>

                        {event.time && (
                          <div className="organization-event-card-time">
                            <FaClock />
                            <span>{formatTime(event.time)}</span>
                          </div>
                        )}

                        {event.branch_name && (
                          <div className="organization-event-card-location">
                            <FaMapMarkerAlt />
                            <span>{event.branch_name}</span>
                          </div>
                        )}

                        {event.category && (
                          <div className="organization-event-card-category">
                            <FaTags />
                            <span>{event.category}</span>
                          </div>
                        )}
                      </div>

                      {event.description && (
                        <p className="organization-event-card-description">
                          {event.description.length > 120
                            ? `${event.description.substring(0, 120)}...`
                            : event.description}
                        </p>
                      )}
                    </div>

                    <div className="organization-event-card-actions">
                      <button
                        onClick={() => handleView(event.id)}
                        className="organization-event-action-btn view"
                        title="Ver detalles"
                      >
                        <FaEye />
                      </button>
                      <button
                        onClick={() => handleEdit(event.id)}
                        className="organization-event-action-btn edit"
                        title="Editar"
                      >
                        <FaEdit />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {filteredAndSortedEvents.length > 0 && (
          <div className="organization-event-bulk-actions">
            <button
              onClick={handleCreateEvent}
              className="organization-event-bulk-btn"
            >
              <FaPlus />
              Agregar Otro Evento
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default OrganizationEvents;
