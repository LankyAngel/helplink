module.exports = {
  env: {
    browser: true,
    es2021: true,
  },
  extends: [
    "react-app",
    "eslint:recommended",
    "plugin:react/recommended",
    "plugin:jsx-a11y/recommended",
    "prettier",
  ],
  plugins: ["react", "jsx-a11y"],
  rules: {
    "react/prop-types": "warn",
    "no-unused-vars": "warn",
    "no-console": "off",
  },
};
