# 💻 HELPLINK Frontend

Proyecto frontend del sistema **HELPLINK**, desarrollado en **React (JavaScript)**. Este repositorio contiene la interfaz web para voluntarios, organizaciones y administradores.

---

## 🚀 Requisitos

- Node.js 18 o superior
- npm (gestor de paquetes)
- Navegador moderno (Chrome, Firefox, etc.)

---

## ⚙️ Instalación local

1. Clona el repositorio:

```bash
git clone https://gitlab.com/tu_usuario/helplink-frontend.git
cd helplink-frontend
```

2. Instala las dependencias:

```bash
npm install
```

3. Crea un archivo `.env` basado en `.env.sample`:

```bash
cp .env.sample .env
```

4. Inicia el servidor de desarrollo:

```bash
npm start
```

---

## 📂 Estructura del proyecto

```
src/
├── components/       # Componentes reutilizables
├── pages/            # Páginas por ruta (ej: Login, Home)
├── services/         # Lógica para llamadas a API (ej: Axios)
├── hooks/            # Custom hooks
├── assets/           # Imágenes, íconos, etc.
├── App.js            # Componente principal
└── index.js          # Punto de entrada
```

---

## 🧼 Estilo de código

Este proyecto usa **ESLint** y **Prettier**.

- Linter: `npm run lint`
- Formateo: `npm run format`

---

## 🧠 Variables de entorno

Todas las variables van en el archivo `.env`, pero **no debe subirse**. Usa el `.env.sample` como plantilla.

```env
REACT_APP_API_URL=https://api.helplink.example.com
REACT_APP_ENV=development
REACT_APP_SYSTEM_NAME=HELPLINK Volunteer Platform
REACT_APP_SESSION_TIMEOUT=60
```

---

## 🔀 Flujo de trabajo con Git

### ✅ Regla #1: **NO se hace push directo al `main`**

Trabajamos con ramas `feature/` para mantener control del código.

### 🧩 ¿Cómo trabajar?

1. Crea una nueva rama a partir de `main`:

```bash
git checkout main
git pull
git checkout -b feature/nombre-de-tu-feature
```

2. Trabaja localmente y haz commits:

```bash
git add .
git commit -m "feat: agregué componente de login"
```

3. Sube tu rama al repositorio:

```bash
git push origin feature/nombre-de-tu-feature
```

4. Haz un **Merge Request** en GitLab y espera revisión.

---

## ❌ Archivos ignorados

- `.env`
- `node_modules/`
- Archivos temporales del editor

---

## 🧠 Tips adicionales

- Usa **PropTypes** para validar props.
- Nombra tus ramas de forma clara: `feature/login-page`, `feature/user-profile`, etc.
- Si tienes dudas: pregunta antes de subir cambios grandes.

---

## 📬 Contacto

Para dudas o colaboración, contacta al líder del frontend o abre un issue en el repo.