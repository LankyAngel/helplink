import json
from channels.generic.websocket import AsyncWebsocketConsumer

from urllib.parse import parse_qs

class ChatConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        # Sacamos el ID desde la URL del WebSocket
        query_string = parse_qs(self.scope["query_string"].decode())
        user_id = query_string.get("user", [None])[0]

        if not user_id:
            await self.close()
            return

        # Simulamos que ese es el usuario conectado
        self.user_id = user_id
        self.room_group_name = f"chat_{user_id}"

        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name
        )
        await self.accept()

    async def disconnect(self, close_code):
        await self.channel_layer.group_discard(
            self.room_group_name,
            self.channel_name
        )

    async def receive(self, text_data):
        try:
            data = json.loads(text_data)
            receiver_id = data.get("receiver_id")
            message = data.get("message")

            if not receiver_id or not message:
                return

            await self.channel_layer.group_send(
                f"chat_{receiver_id}",
                {
                    "type": "chat_message",
                    "message": message,
                    "sender_id": self.user_id
                }
            )
        except Exception as e:
            print("Error en receive:", e)

    async def chat_message(self, event):
        await self.send(text_data=json.dumps({
            "message": event["message"],
            "sender_id": event["sender_id"]
        }))

#=== Código funcional para producción ===

# class ChatConsumer(AsyncWebsocketConsumer):
#     async def connect(self):
#         # Verificamos que el usuario esté autenticado
#         if self.scope["user"].is_anonymous:
#             await self.close()
#             return

#         # Cada usuario se une a su propio grupo privado
#         self.room_group_name = f"chat_{self.scope['user'].id}"

#         await self.channel_layer.group_add(
#             self.room_group_name,
#             self.channel_name
#         )
#         await self.accept()

#     async def disconnect(self, close_code):
#         # Salir del grupo al desconectarse
#         await self.channel_layer.group_discard(
#             self.room_group_name,
#             self.channel_name
#         )

#     async def receive(self, text_data):
#         try:
#             data = json.loads(text_data)
#             receiver_id = data.get("receiver_id")
#             message = data.get("message")

#             if not receiver_id or not message:
#                 return  # mensaje mal formado, ignoramos

#             # Enviamos al grupo del receptor
#             await self.channel_layer.group_send(
#                 f"chat_{receiver_id}",
#                 {
#                     "type": "chat_message",
#                     "message": message,
#                     "sender_id": self.scope["user"].id
#                 }
#             )

#         except Exception as e:
#             print("Error en receive:", e)

#     async def chat_message(self, event):
#         # Enviamos el mensaje al cliente conectado
#         await self.send(text_data=json.dumps({
#             "message": event["message"],
#             "sender_id": event["sender_id"]
#         }))
