from rest_framework import serializers
from .models import *
from users.serializers import UserSerializer
from organizations.serializers import OrganizationSerializer

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = "__all__"

class EventSerializer(serializers.ModelSerializer):
    organization = OrganizationSerializer(read_only=True)

    class Meta:
        model = Event
        fields = "__all__"

class EventCategorySerializer(serializers.ModelSerializer):
    event = EventSerializer(read_only=True)
    category = CategorySerializer(read_only=True)

    class Meta:
        model = EventCategory
        fields = "__all__"

class EventLocationSerializer(serializers.ModelSerializer):
    event = EventSerializer(read_only=True)

    class Meta:
        model = EventLocation
        fields = "__all__"

class VolunteerEventSerializer(serializers.ModelSerializer):
    event = EventSerializer(read_only=True)
    user = UserSerializer(read_only=True)

    class Meta:
        model = VolunteerEvent
        fields = "__all__"

class FeedbackSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    event = EventSerializer(read_only=True)

    class Meta:
        model = Feedback
        fields = "__all__"

class TaskSerializer(serializers.ModelSerializer):
    event = EventSerializer(read_only=True)

    class Meta:
        model = Task
        fields = "__all__"
