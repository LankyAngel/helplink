from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework import status
from rest_framework.response import Response
from .models import *
from .serializers import*

# Create your views here.

class CategoryViewSet(viewsets.ModelViewSet):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [IsAuthenticated]

class EventViewSet(viewsets.ModelViewSet):
    queryset = Event.objects.all()
    serializer_class = EventSerializer
    permission_classes = [AllowAny]

class EventCategoryViewSet(viewsets.ModelViewSet):
    queryset = EventCategory.objects.all()
    serializer_class = EventCategorySerializer
    permission_classes = [AllowAny]

class EventLocationViewSet(viewsets.ModelViewSet):
    queryset = EventLocation.objects.all()
    serializer_class = EventLocationSerializer
    permission_classes = [AllowAny]

class VolunteerEventViewSet(viewsets.ModelViewSet):
    queryset = VolunteerEvent.objects.all()
    serializer_class = VolunteerEventSerializer
    permission_classes = [IsAuthenticated]

class FeedbackViewSet(viewsets.ModelViewSet):
    queryset = Feedback.objects.all()
    serializer_class = FeedbackSerializer
    permission_classes = [AllowAny]

class TaskViewSet(viewsets.ModelViewSet):
    queryset = Task.objects.all()
    serializer_class = TaskSerializer
    permission_classes = [IsAuthenticated]

# Specific endpoints

from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response

@api_view(["GET"])
@permission_classes([IsAuthenticated])
def participation_history(request):
    user = request.user
    participations = VolunteerEvent.objects.filter(user=user).select_related("event", "event__organization")

    data = [
        {
            "event": p.event.title,
            "date": p.event.event_date,
            "organization": p.event.organization.name
        }
        for p in participations
    ]
    return Response(data)

@api_view(["GET"])
@permission_classes([AllowAny]) 
def event_detail(request, pk):
    try:
        event = Event.objects.prefetch_related(
            "locations",
            "event_categories__category"
        ).select_related("branch").get(pk=pk)

        data = {
            "id": event.id,
            "title": event.title,
            "description": event.description,
            "banner": event.image.url if event.image else None,
            "event_date": event.event_date,
            "start_time": event.start_time,
            "status": event.status,
            "published_at": event.published_at,

            "branch": {
                "id": event.branch.id,
                "name": event.branch.name,
                "address": getattr(event.branch, "address", None),
                "phone": getattr(event.branch, "phone", None),
                "email": getattr(event.branch, "email", None),
                "logo": event.branch.logo.url if getattr(event.branch, "logo", None) else None
            },

            "categories": [
                {
                    "id": ec.category.id,
                    "name": ec.category.name
                }
                for ec in event.event_categories.all()
            ],

            "locations": [
                {
                    "id": loc.id,
                    "address": loc.address,
                    "latitude": loc.latitude,
                    "longitude": loc.longitude
                }
                for loc in event.locations.all()
            ]
        }

        return Response(data, status=status.HTTP_200_OK)
    except Event.DoesNotExist:
        return Response({"error": "Event not found"}, status=status.HTTP_404_NOT_FOUND)
