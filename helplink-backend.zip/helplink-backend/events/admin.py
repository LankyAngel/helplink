from django.contrib import admin
from django.utils.html import format_html
from .models import *

# Register your models here.

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "description")
    search_fields = ("name",)

@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    list_display = ("title", "branch", "status", "image_preview")
    search_fields = ("title",)
    list_filter = ("status", "branch")
    autocomplete_fields = ("branch",)

    def image_preview(self, obj):
        if obj.image:
            return format_html('<img src="{}" style="max-height: 100px;" />', obj.image.url)
        return "-"
    image_preview.short_description = "Banner"

@admin.register(EventCategory)
class EventCategoryAdmin(admin.ModelAdmin):
    list_display = ("event", "category")
    list_filter = ("event", "category")
    autocomplete_fields = ("event", "category")

@admin.register(EventLocation)
class EventLocationAdmin(admin.ModelAdmin):
    list_display = ("event", "address")
    search_fields = ("event_location__event",)
    autocomplete_fields = ("event",)

@admin.register(VolunteerEvent)
class VolunteerEventAdmin(admin.ModelAdmin):
    list_display = ("event", "user", "applied_at")
    autocomplete_fields = ("event", "user")

@admin.register(Feedback)
class FeedbackAdmin(admin.ModelAdmin):
    list_display = ("user", "event", "rating")
    search_fields = ("feedbak__event",)
    list_filter = ("rating",)
    autocomplete_fields = ("user", "event")

@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    list_display = ("title", "event", "assigned_at")
    search_fields = ("title",)
    list_filter = ("event",)
    autocomplete_fields = ("event",)