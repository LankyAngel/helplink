from django.db import models
from organizations.models import Branch
from datetime import date
from users.models import User
from django.core.validators import MinValueValidator, MaxValueValidator
from django.utils.text import slugify
import uuid
from .storages import MediaStorage

# Create your models here.

class Category(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()

    def __str__(self):
        return f"Label: {self.name}"

class EventStatus(models.TextChoices):
    PENDING = "pending", "Pendiente"
    PUBLISHED = "published", "Publicado"
    CANCELED = "canceled", "Cancelado"
    FINISHED = "finished", "Finalizado"

def event_banner_upload_path(instance, filename):
    org_name = slugify(instance.organization.name if instance.organization else "unknown")
    extension = filename.split('.')[-1]
    unique_filename = f"{uuid.uuid4()}.{extension}"
    return f"orgs/events_banners/{org_name}/{unique_filename}"

class Event(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(null=True, blank=True)
    image = models.ImageField(storage=MediaStorage(), upload_to=event_banner_upload_path, null=True, blank=True)
    branch = models.ForeignKey(Branch, on_delete=models.CASCADE, related_name="events")
    event_date = models.DateField()
    start_time = models.TimeField()
    status = models.CharField(max_length=20, choices=EventStatus.choices, default=EventStatus.PENDING)
    published_at = models.TimeField(auto_now_add=True)
    
    def auto_update_status(self):
        if self.event_date < date.today() and self.status != EventStatus.FINISHED:
            self.status = EventStatus.FINISHED
            self.save()
    
    def __str__(self):
        return f"{self.title} - {self.branch}"
    
class EventCategory(models.Model):
    event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name="event_categories")
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name="category_events")

    class Meta:
        unique_together = ("event", "category")

    def __str__(self):
        return f"{self.event} with categories: {self.category}"
    
class EventLocation(models.Model):
    event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name="locations")
    address = models.CharField(max_length=255)
    latitude = models.FloatField(null=True, blank=True)
    longitude = models.FloatField(null=True, blank=True)

    def save(self, *args, **kwargs):
        if self.address and (not self.latitude or not self.longitude):
            from .utils import geocode_address
            lat, lon = geocode_address(self.address)
            self.latitude = lat
            self.longitude = lon
        super().save(*args, **kwargs)

    def __str__(self):
        title = self.event.title if self.event else "Evento desconocido"
        return f"{title} - {self.address}"
    
class VolunteerEvent(models.Model):
    event = models.ForeignKey(Event, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)

    applied_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("event", "user")

    def __str__(self):
        return f"{self.user} en {self.event}"

class Rate(models.IntegerChoices):
    ONE = 1, "★☆☆☆☆"
    TWO = 2, "★★☆☆☆"
    THREE = 3, "★★★☆☆"
    FOUR = 4, "★★★★☆"
    FIVE = 5, "★★★★★"
    
class Feedback(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    event = models.ForeignKey(Event, on_delete=models.CASCADE)
    comment = models.TextField(null=True, blank=True)
    rating = models.IntegerField(null=True, blank=True, validators=[MinValueValidator(1), MaxValueValidator(5)], choices=Rate.choices)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("user", "event")

    def __str__(self):
        return f"{self.user} → {self.event}: {self.get_rating_display()}"
    
class Task(models.Model):
    event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name="event_task")
    title = models.CharField(max_length=150)
    description = models.TextField()
    assigned_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.title}, task of: {self.event}"
