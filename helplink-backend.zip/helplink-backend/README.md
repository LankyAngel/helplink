# 💡 HELPLINK Backend

Proyecto backend del sistema **HELPLINK**, desarrollado con Django, PostgreSQL y AWS S3.  
Incluye WebSockets en tiempo real con Redis y Channels.

---

## 🚀 Requisitos

- Python 3.10 o superior
- PostgreSQL (Railway o local)
- Redis (para WebSockets en tiempo real)
- Virtualenv (opcional pero recomendado)

---

## ⚙️ Instalación local

```bash
# Clona el repositorio
git clone https://gitlab.com/helplink1/helplink-backend.git
cd helplink-backend

# Crea y activa el entorno virtual
python -m venv venv
source venv/bin/activate

# Instala dependencias
pip install -r requirements.txt

# Crea el archivo .env
cp .env.sample .env

# (Opcional) Corre migraciones si usas BD local
python manage.py migrate

# Ejecuta el servidor
python manage.py runserver
```

---

## 📁 Estructura del proyecto

```
helplink_backend/
├── helplink_core/          # Configuración principal del proyecto
├── apps/                   # Todas las apps del sistema
├── .env.sample             # Variables de entorno de ejemplo
├── manage.py
└── README.md
```

---

## ⚠️ Notas importantes

- 🚫 **NO** ejecutar `migrate` directo contra Railway sin autorización.
- 🔀 Nuevas funcionalidades deben ir en ramas `feature/*`.
- 📁 Nunca subas tu `.env`. Usa el `.env.sample` como plantilla.
- ✅ Haz `pull` de `develop` antes de crear una nueva rama.

---

## 🔌 WebSockets (Chat y Notificaciones en Tiempo Real)

HELPLINK usa **Django Channels** con **Redis** para comunicación en tiempo real.

### ✅ Requisitos

```bash
sudo apt install redis
pip install channels channels_redis
```

### 🛠️ Configuración básica (`settings.py`)

```python
INSTALLED_APPS += ["channels"]

ASGI_APPLICATION = "helplink_core.asgi.application"

CHANNEL_LAYERS = {
    "default": {
        "BACKEND": "channels_redis.core.RedisChannelLayer",
        "CONFIG": {
            "hosts": [("127.0.0.1", 6379)],
        },
    },
}
```

### 🧠 `asgi.py`

```python
import os, django
from django.core.asgi import get_asgi_application
from channels.routing import ProtocolTypeRouter, URLRouter
from channels.auth import AuthMiddlewareStack
from messaging.routing import websocket_urlpatterns

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "helplink_core.settings")
django.setup()

application = ProtocolTypeRouter({
    "http": get_asgi_application(),
    "websocket": AuthMiddlewareStack(URLRouter(websocket_urlpatterns)),
})
```

### 🧩 `messaging/routing.py`

```python
from django.urls import re_path
from . import consumers

websocket_urlpatterns = [
    re_path(r"ws/chat/$", consumers.ChatConsumer.as_asgi()),
]
```

### 🧪 Prueba con Daphne

```bash
sudo systemctl start redis
daphne -p 8000 helplink_core.asgi:application
```

Prueba con [Weasel WebSocket](https://addons.mozilla.org/es/firefox/addon/weasel-websocket-client/) usando:

```
ws://localhost:8000/ws/chat/?user=1
```

Payload:
```json
{
  "receiver_id": 2,
  "message": "¡Hola desde el usuario 1!"
}
```

---

## ✅ Producción

- Usa `DEBUG=False`
- Configura `ALLOWED_HOSTS`, `CSRF_TRUSTED_ORIGINS`, `CORS_ALLOWED_ORIGINS`
- Ejecuta:

```bash
python manage.py collectstatic
```

- Usa Gunicorn o Daphne + NGINX para el deployment.

---

## 📬 Contacto

Proyecto desarrollado por estudiantes del TSU IGyDS – Grupo 8A.  
Para contribuciones, dudas o colaboración, abre un issue o contáctanos por GitLab.

---

---

## 🚀 Manual de Despliegue (Producción con Gunicorn + NGINX)

Este proyecto puede ser desplegado fácilmente en una instancia EC2 (o similar) usando **Gunicorn** como servidor WSGI y **NGINX** como proxy inverso.  
⚠️ En este entorno, WebSockets (Channels) están **desactivados temporalmente** y se usará solo el servidor HTTP clásico para revisión académica.

---

### 🧰 1. Requisitos del servidor

- Ubuntu 22.04
- Python 3.10+
- PostgreSQL remoto (ej. Railway)
- Gunicorn
- NGINX
- Certbot (opcional para HTTPS)
- `.env` configurado

---

### 🗂️ 2. Archivos clave que debes tener

- `requirements.txt`
- `.env` (configurado correctamente con AWS, DB y CORS/CSRF)
- `staticfiles/` (generado por `collectstatic`)
- `gunicorn.socket` y `gunicorn.service` si usas `systemd`

---

### ⚙️ 3. Comandos básicos en el servidor

```bash
# Activar entorno virtual
source venv/bin/activate

# Instalar dependencias
pip install -r requirements.txt

# Migraciones
python manage.py migrate

# Recolectar estáticos
python manage.py collectstatic

# Probar Gunicorn
gunicorn helplink_core.wsgi:application --bind 0.0.0.0:8000
```

---

### 🔧 4. Configuración de NGINX (ejemplo)

```nginx
server {
    listen 80;
    server_name erp.casapiaconstruction.com;

    location /static/ {
        alias /home/ubuntu/helplink-backend/staticfiles/;
    }

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

---

### 🛡️ 5. Consideraciones de Seguridad

- `DEBUG=False`
- `ALLOWED_HOSTS`, `CSRF_TRUSTED_ORIGINS`, `CORS_ALLOWED_ORIGINS` bien configurados
- `SECRET_KEY` nunca subido al repositorio
- Si usas HTTPS, configura Certbot (`sudo certbot --nginx`)

---

# 🌀 Configurar Gunicorn como servicio del sistema (systemd)

Este documento describe cómo levantar Gunicorn como servicio del sistema usando `systemd`, ideal para producción en servidores Linux como EC2.

---

## 📄 1. Crear archivo de servicio

Ubicación recomendada:

```
/etc/systemd/system/helplink.service
```

Contenido sugerido (ajusta rutas según tu proyecto):

```ini
[Unit]
Description=Gunicorn backend service for HELPLINK
After=network.target

[Service]
User=ubuntu
Group=www-data
WorkingDirectory=/home/ubuntu/helplink-backend
Environment="PATH=/home/ubuntu/helplink-backend/venv/bin"
ExecStart=/home/ubuntu/helplink-backend/venv/bin/gunicorn helplink_core.wsgi:application --workers 3 --bind unix:/home/ubuntu/helplink-backend/helplink.sock

[Install]
WantedBy=multi-user.target
```

---

## 🧪 2. Comandos para activar y administrar el servicio

```bash
# Recargar systemd
sudo systemctl daemon-reexec
sudo systemctl daemon-reload

# Habilitar al iniciar sistema
sudo systemctl enable helplink

# Iniciar servicio
sudo systemctl start helplink

# Reiniciar si hay cambios
sudo systemctl restart helplink

# Ver estado del servicio
sudo systemctl status helplink
```

---

## 🌐 3. Configurar NGINX para usar el socket de Gunicorn

En tu bloque de servidor (`/etc/nginx/sites-available/helplink`):

```nginx
location / {
    proxy_pass http://unix:/home/ubuntu/helplink-backend/helplink.sock;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
}
```

```bash
# Reinicia NGINX después de hacer cambios
sudo systemctl restart nginx
```

---

Con esto, Gunicorn se ejecuta como un servicio confiable, reiniciable y persistente usando systemd.

### 🚫 ¿Y los WebSockets?

Por ahora, **están deshabilitados** para simplificar la revisión académica.  
Puedes activarlos después reemplazando `gunicorn` por `daphne` y añadiendo configuración para ASGI + Redis.

---

🎉 ¡Tu deploy ya está listo para presentación y revisión!
