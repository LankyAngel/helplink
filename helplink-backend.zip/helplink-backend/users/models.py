from django.db import models
from django.contrib.auth.models import AbstractUser
from organizations.models import Organization
from django.utils.translation import gettext_lazy as _
from .storages import MediaStorage

# Create your models here.

class RoleChoices(models.TextChoices):
    SUPERADMIN = "superadmin", "Superadmin" # Los superusuarios de Django (pueden ver todo (literalmente))
    ORG_ADMIN = "organization_admin", "Administrador de la organización" # Ve y controla todo lo referente a su organización
    ORG_STAFF = "organization_staff", "Miembro de la organización"
    VOLUNTEER = "volunteer", "Voluntario"

class Role(models.Model):
    role = models.CharField(max_length=50, choices=RoleChoices.choices, unique=True)

    def __str__(self):
        return self.get_role_display()
    
class Achievement(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    image = models.ImageField(storage=MediaStorage(), upload_to='achievements/')

    def __str__(self):
        return f"Title: {self.name}"
    
class User(AbstractUser):
    first_name = models.CharField(max_length=80, help_text="You can enter both names")
    last_name = models.CharField(max_length=80, help_text="You can put both surnames")
    organization = models.ForeignKey(Organization, on_delete=models.SET_NULL, null=True, blank=True, related_name="members")
    email = models.EmailField(max_length=100, unique=True)
    phone_number = models.CharField(max_length=15, null=True, blank=True)
    role = models.ForeignKey(Role, on_delete=models.SET_NULL, null=True, blank=True)

    REQUIRED_FIELDS = ['email', 'first_name', 'last_name']

    def __str__(self):
        org = self.organization.name if self.organization else "No organization"
        return f"{self.first_name} {self.last_name} ({self.role}) - ({org})"
    
class UserAchievement(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="users")
    achievement = models.ForeignKey(Achievement, on_delete=models.CASCADE, related_name="achievements")

    unlocked_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("user", "achievement")

    def __str__(self):
        return f"{self.user} unlocked - {self.achievement} at {self.unlocked_at}!"
