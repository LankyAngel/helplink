from django.dispatch import receiver
from django_rest_passwordreset.signals import reset_password_token_created
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string

@receiver(reset_password_token_created)
def password_reset_token_created(sender, instance, reset_password_token, **kwargs):
    context = {
        "username": reset_password_token.user.username,
        "token": reset_password_token.key,
        "site_name": "HelpLink",
    }

    subject = "🔐 Recuperación de contraseña – HelpLink"
    from_email = "HelpLink <info.helplink25@gmail.com>"
    to_email = reset_password_token.user.email

    # Renderiza el correo con plantilla HTML
    html_message = render_to_string("emails/password_reset.html", context)

    # Mensaje alternativo (texto plano)
    plain_message = (
        f"Hola {context['username']},\n\n"
        f"Recibiste este mensaje porque solicitaste recuperar tu contraseña en {context['site_name']}.\n"
        f"Usa el siguiente token para continuar con el proceso:\n\n"
        f"{context['token']}\n\n"
        f"Si no solicitaste este cambio, puedes ignorar este mensaje.\n\n"
        f"— El equipo de HelpLink"
    )

    msg = EmailMultiAlternatives(subject, plain_message, from_email, [to_email])
    msg.attach_alternative(html_message, "text/html")
    msg.send()
    