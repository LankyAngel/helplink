from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.forms import UserChangeForm, UserCreationForm
from django.http import HttpResponse
from django.utils.html import format_html
import subprocess
import datetime
from .models import *

# Register your models here.

@admin.register(Role)
class RoleAdmin(admin.ModelAdmin):
    list_display = ("role",)
    search_fields = ("role",)

@admin.action(description="Descargar respaldo de la base de datos")
def backup_database(modeladmin, request, queryset):
    fecha = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    filename = f"backup_{fecha}.json"

    result = subprocess.run(
        ["python", "manage.py", "dumpdata", "--indent", "2"],
        capture_output=True,
        text=True
    )

    response = HttpResponse(result.stdout, content_type='application/json')
    response['Content-Disposition'] = f'attachment; filename={filename}'
    return response

@admin.register(Achievement)
class AchievementAdmin(admin.ModelAdmin):
    search_fields = ("name",)
    list_display = ("name", "image_preview")

    def image_preview(self, obj):
        if obj.image:
            return format_html('<img src="{}" style="max-height: 100px;" />', obj.image.url)
        return "-"
    image_preview.short_description = "Icon"
    
class CustomUserAdmin(UserAdmin):
    form = UserChangeForm
    add_form = UserCreationForm

    model = User
    list_display = ('username', 'email', 'is_staff', 'is_active')
    list_filter = ('is_staff', 'is_active', 'is_superuser')

    fieldsets = UserAdmin.fieldsets  # Usa los fieldsets del UserAdmin base
    add_fieldsets = UserAdmin.add_fieldsets

    search_fields = ('username', 'email')
    ordering = ('username',)

    fieldsets = (
        (None, {"fields": ("username", "email", "password", "phone_number", "organization", "role")}),
        ("Permissions", {"fields": ("is_staff", "is_active", "is_superuser", "groups", "user_permissions")}),
        ("Important dates", {"fields": ("last_login", "date_joined")}),
    )

    add_fieldsets = (
        (None, {
            "classes": ("wide",),
            "fields": ("username", "email", "password1", "password2", "is_staff", "is_active"),
        }),
    )

    actions = [backup_database]

admin.site.register(User, CustomUserAdmin)

@admin.register(UserAchievement)
class UserAchievementAdmin(admin.ModelAdmin):
    list_display = ("user", "achievement")
    list_filter = ("user",)
    autocomplete_fields = ("user", "achievement")
