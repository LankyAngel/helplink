from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer
from .models import *
from django.contrib.auth import get_user_model

class RoleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Role
        fields = "__all__"

class AchievementSerializer(serializers.ModelSerializer):
    class Meta:
        model = Achievement
        fields = "__all__"

class UserSerializer(serializers.ModelSerializer):
    organization = serializers.SerializerMethodField()
    global_role = RoleSerializer(source="role", read_only=True)
    has_phone_number = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = ["id", "username", "email", "first_name", "last_name", 
                  "phone_number", "global_role", "organization", "has_phone_number", "date_joined", "last_login"]
        
    def get_organization(self, obj):
        from organizations.serializers import OrganizationSerializer
        return OrganizationSerializer(obj.organization).data if obj.organization else None

    def get_has_phone_number(self, obj):
        return bool(obj.phone_number)
    
class UserAchievementSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    achievement = AchievementSerializer(read_only=True)

    class Meta:
        model = UserAchievement
        fields = "__all__"

User = get_user_model()

class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)

    class Meta:
        model = User
        fields = ['first_name', 'last_name', 'email', 'username', 'password', 'phone_number']

    def create(self, validated_data):
        # Busca el rol por nombre (ajusta si lo manejas por ID o código)
        volunteer_role = Role.objects.get(role=RoleChoices.VOLUNTEER)

        user = User(
            first_name=validated_data['first_name'],
            last_name=validated_data['last_name'],
            email=validated_data['email'],
            username=validated_data['username'],
            phone_number=validated_data.get('phone_number'),
            role=volunteer_role
        )
        user.set_password(validated_data['password'])
        user.save()
        return user

class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)

        organization = getattr(user.organization, "id", None) 
        organization_name = getattr(user.organization, "name", None)
        role_name = getattr(user.role, "role", None)
        is_org_admin = role_name == "organization_admin"
        branches = user.user_memberships.all()
        branch_roles = list(branches.values("branch__id", "branch__name", "role"))

        token["username"] = user.username
        token["org_code"] = organization
        token["org_name"] = organization_name
        token["role"] = role_name
        token["is_org_admin"] = is_org_admin
        token["branch_roles"] = branch_roles

        return token
    
    def validate(self, attrs):
        data = super().validate(attrs)

        organization = getattr(self.user.organization, "id", None)
        organization_name = getattr(self.user.organization, "name", None)
        role_name = getattr(self.user.role, "role", None)
        is_org_admin = role_name == "organization_admin"
        branches = self.user.user_memberships.all()
        branch_roles = list(branches.values("branch__id", "branch__name", "role"))

        data["username"] = self.user.username
        data["org_code"] = organization
        data["org_name"] = organization_name
        data["role"] = role_name
        data["is_org_admin"] = is_org_admin
        data["branch_roles"] = branch_roles

        return data
    