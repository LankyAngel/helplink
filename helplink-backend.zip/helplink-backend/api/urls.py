from django.urls import path, include
from rest_framework.routers import DefaultRouter
from users.views import RoleViewSet, UserViewSet, AchievementViewSet, UserAchievementViewSet, CustomTokenObtainPairView, register_user, user_achievements
from organizations.views import OrganizationViewSet, BranchViewSet, LegalContactViewSet, BranchMembershipViewSet
from events.views import CategoryViewSet, EventViewSet, EventCategoryViewSet, EventLocationViewSet, VolunteerEventViewSet, FeedbackViewSet, TaskViewSet, participation_history, event_detail

router = DefaultRouter()
router.register(r'roles', RoleViewSet, basename='roles')
router.register(r'users', UserViewSet, basename='users')
router.register(r'achievements', AchievementViewSet, basename='achievement')
router.register(r'categories', CategoryViewSet, basename='categories')
router.register(r'user-achievement', UserAchievementViewSet, basename='user-achievement')
router.register(r'organizations', OrganizationViewSet, basename='organizations')
router.register(r'branches', BranchViewSet, basename='branches')
router.register(r'branch-memberships', BranchMembershipViewSet, basename='branch-memberships')
router.register(r'legal-contact', LegalContactViewSet, basename='legal-contact')
router.register(r'events', EventViewSet, basename='events')
router.register(r'event-categories', EventCategoryViewSet, basename='event-categories')
router.register(r'event-locations', EventLocationViewSet, basename='event-locations')
router.register(r'tasks', TaskViewSet, basename='tasks')
router.register(r'voluntaries-events', VolunteerEventViewSet, basename='voluntaries-events')
router.register(r'feedback', FeedbackViewSet, basename='feedback')

urlpatterns = [
    path('token/', CustomTokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('password_reset/', include("django_rest_passwordreset.urls", namespace="password_reset")),
    path('register/', register_user, name='register_user'),
    path('volunteer/history', participation_history, name="volunteer_history"),
    path('user/achievements', user_achievements, name="user_achievement"),
    path('events/<int:pk>/summary/', event_detail, name='event-summary'),
]

urlpatterns += router.urls
