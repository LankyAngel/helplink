from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated, AllowAny
from .models import *
from .serializers import*

# Create your views here.

class OrganizationViewSet(viewsets.ModelViewSet):
    queryset = Organization.objects.all()
    serializer_class = OrganizationSerializer
    permission_classes = [AllowAny]

class BranchViewSet(viewsets.ModelViewSet):
    queryset = Branch.objects.all()
    serializer_class = BranchSerializer
    permission_classes = [AllowAny]

class LegalContactViewSet(viewsets.ModelViewSet):
    queryset = LegalContact.objects.all()
    serializer_class = LegalContactSerializer
    permission_classes = [IsAuthenticated]

class BranchMembershipViewSet(viewsets.ModelViewSet):
    queryset = BranchMembership.objects.all()
    serializer_class = BranchMembershipSerializer
    permission_classes = [IsAuthenticated]
