from django.contrib import admin
from django.utils.html import format_html
from .models import *

# Register your models here.

@admin.register(Organization)
class OrganizationAdmin(admin.ModelAdmin):
    list_display = ("name", "email", "status", "image_preview")
    readonly_fields = ("created_by",)
    search_fields = ("name",)

    def image_preview(self, obj):
        if obj.logo:
            return format_html('<img src="{}" style="max-height: 100px;" />', obj.logo.url)
        return "-"
    image_preview.short_description = "Logo"

@admin.register(Branch)
class BranchAdmin(admin.ModelAdmin):
    list_display = ( "name", "organization", "image_preview")
    search_fields = ("branch__name",)
    autocomplete_fields = ("organization",)

    def image_preview(self, obj):
        if obj.logo:
            return format_html('<img src="{}" style="max-height: 100px;" />', obj.logo.url)
        return "-"
    image_preview.short_description = "Logo"

@admin.register(LegalContact)
class LegalContactAdmin(admin.ModelAdmin):
    list_display = ("full_name", "organization")
    search_fields = ("legal_contact__name",)
    autocomplete_fields = ("organization",)

@admin.register(BranchMembership)
class BranchMembershipAdmin(admin.ModelAdmin):
    list_display = ("branch", "user", "role")
    list_filter = ("branch", "role", "user")
    autocomplete_fields = ("branch", "user")

