from rest_framework import serializers
from .models import *
from users.serializers import UserSerializer
from users.models import Role

class OrganizationSerializer(serializers.ModelSerializer):
    created_by = serializers.SerializerMethodField()
    has_multiple_branches = serializers.SerializerMethodField()

    class Meta:
        model = Organization
        fields = ["name", "email", "phone_number", "logo", "created_at", "created_by", "has_multiple_branches"]
        read_only_fields = ["status", "created_by"]

    def create(self, validated_data):
        # 1. Obtener el usuario autenticado
        user = self.context["request"].user
        
        # 2. Asignar quién creó la organización
        validated_data["created_by"] = user
        
        # 3. Crear la organización
        org = super().create(validated_data)

        # 4. Buscar el rol "organization_admin" en la tabla Role
        try:
            role_instance = Role.objects.get(role="organization_admin")
        except Role.DoesNotExist:
            raise serializers.ValidationError("Role 'organization_admin' no existe en la base de datos.")

        # 5. Asignar el rol y la organización al usuario
        user.role = role_instance
        user.organization = org
        user.save()

        return org
    
    def get_created_by(self, obj):
        if obj.created_by:
            return f"{obj.created_by.first_name} {obj.created_by.last_name}"
        return None

    def get_has_multiple_branches(self, obj):
        return obj.branches.count() > 1

class BranchSerializer(serializers.ModelSerializer):
    organization = OrganizationSerializer(read_only=True)

    class Meta:
        model = Branch
        fields = "__all__"
    
class LegalContactSerializer(serializers.ModelSerializer):
    organization = OrganizationSerializer(read_only=True)
    
    class Meta:
        model = LegalContact
        fields = "__all__"

class BranchMembershipSerializer(serializers.ModelSerializer):
    branch = BranchSerializer(read_only=True)
    user = UserSerializer(read_only=True)
    branch_role = serializers.CharField(source="role", read_only=True)

    class Meta:
        model = BranchMembership
        fields = '__all__'
