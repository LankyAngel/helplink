from django.db import models
from django.utils.text import slugify
import uuid
from .storages import MediaStorage

# Create your models here.

class OrganizationStatus(models.TextChoices):
    PENDING = "pending", "Pending Review"
    APPROVED = "approved", "Approved"
    REJECTED = "rejected", "Rejected"

def org_logo_upload_path(instance, filename):
    org_name = slugify(instance.name or "unknown")
    extension = filename.split('.')[-1]
    unique_filename = f"{uuid.uuid4()}.{extension}"
    return f"orgs/logos/{org_name}/{unique_filename}"

class Organization(models.Model):
    name = models.CharField(max_length=255)
    email = models.EmailField(max_length=255, unique=True)
    phone_number = models.CharField(max_length=15)
    logo = models.ImageField(storage=MediaStorage(), upload_to=org_logo_upload_path, null=True, blank=True)
    status = models.CharField(max_length=20, choices=OrganizationStatus.choices, default=OrganizationStatus.PENDING)   
    created_at = models.DateTimeField(auto_now_add=True)
    created_by = models.ForeignKey("users.User", on_delete=models.SET_NULL, null=True, related_name="created_organizations")

    def __str__(self):
        return f"{self.name}"

def branch_logo_upload_path(instance, filename):
    # Sanitizar nombre
    branch_name = slugify(instance.name or "unknown")

    # Obtener extensión del archivo original
    extension = filename.split('.')[-1]

    # Generar nombre único
    unique_filename = f"{uuid.uuid4()}.{extension}"

    # Ruta final
    return f"orgs/branch_logos/{branch_name}/{unique_filename}"
    
class Branch(models.Model):
    name = models.CharField(max_length=255, verbose_name="Branch name")
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE, related_name='branches')
    logo = models.ImageField(storage=MediaStorage(), upload_to=branch_logo_upload_path, null=True, blank=True)
    street = models.CharField(max_length=255)
    city = models.CharField(max_length=100, default="Tijuana")
    zip_code = models.CharField(max_length=10)

    class Meta:
        verbose_name_plural = "Branches"

    def __str__(self):
        return f"{self.organization} - Branch: {self.name}, {self.city}"
    
def license_upload_path(instance, filename):
    org_name = slugify(instance.organization.name if instance.organization else "unknown")
    extension = filename.split('.')[-1]
    unique_filename = f"{uuid.uuid4()}.{extension}"
    return f"licenses/{org_name}/{unique_filename}"

class LegalContact(models.Model):
    full_name = models.CharField(max_length=255)
    organization = models.ForeignKey(Organization, on_delete=models.CASCADE, related_name='legal_contact')
    email = models.EmailField(max_length=255)
    phone_number = models.CharField(max_length=15)
    position = models.CharField(max_length=100, verbose_name='Position or title')
    professional_license = models.FileField(storage=MediaStorage(), upload_to=license_upload_path)

    def __str__(self):
        return f"{self.full_name}"
    
class BranchRoleChoices(models.TextChoices):
    BRANCH_ADMIN = "branch_admin", "Administrador de la sucursal"
    STAFF = "staff", "Miembro de la sucursal"

class BranchMembership(models.Model):
    branch = models.ForeignKey(Branch, on_delete=models.CASCADE, related_name='branch_memberships')
    user = models.ForeignKey("users.User", on_delete=models.CASCADE, related_name='user_memberships')

    role = models.CharField(max_length=30, choices=BranchRoleChoices.choices)
    joined_at = models.DateField(auto_now_add=True)
    created_by = models.ForeignKey("users.User", on_delete=models.SET_NULL, null=True, blank=True, related_name='memberships_created')

    class Meta:
        unique_together = ("branch", "user")

    def __str__(self):
        return f"{self.user} - {self.role}, {self.branch}"
  