from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import Organization, Branch, OrganizationStatus

@receiver(post_save, sender=Organization)
def create_main_branch_on_approval(sender, instance, **kwargs):
    # Antes lo hacíamos con created=True
    if instance.status == OrganizationStatus.APPROVED and not instance.branches.exists():
        Branch.objects.create(
            name=f"{instance.name} (Sucursal Principal)",
            organization=instance,
            street="Pendiente",
            city="Tijuana",
            zip_code="00000"
        )

